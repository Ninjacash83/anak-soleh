/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { ActivityStreamProvider } from './context/ActivityStreamContext';
import { PublicNavbar } from './components/public/PublicNavbar';
import { PublicLandingPage } from './components/public/PublicLandingPage';
import { PublicFooter } from './components/public/PublicFooter';
import { PlatformHeader } from './components/layout/PlatformHeader';
import { BottomNav } from './components/layout/BottomNav';
import { LoginPage } from './components/auth/LoginPage';
import { Gerakan5000InfoModal } from './components/lks/Gerakan5000InfoModal';
import { PwaInstallPrompt } from './components/pwa/PwaInstallPrompt';
import { ScrollToTopButton } from './components/common/ScrollToTopButton';
import { SiswaDashboard } from './components/dashboards/SiswaDashboard';
import { OrangTuaDashboard } from './components/dashboards/OrangTuaDashboard';
import { DkmDashboard } from './components/dashboards/DkmDashboard';
import { GuruAgamaDashboard } from './components/dashboards/GuruAgamaDashboard';
import { AdminPemkotDashboard } from './components/dashboards/AdminPemkotDashboard';
import { SuperAdminDashboard } from './components/dashboards/SuperAdminDashboard';

function MainApp() {
  const {
    activeAppMode,
    setActiveAppMode,
    currentRole,
    isAuthenticated,
    isGerakan5000InfoOpen,
    setIsGerakan5000InfoOpen,
    appSettings
  } = useApp();

  const handleScrollToSection = (sectionId: string) => {
    setActiveAppMode('public');
    setTimeout(() => {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 50);
  };

  if (activeAppMode === 'login' || (activeAppMode === 'platform' && !isAuthenticated)) {
    return (
      <>
        <LoginPage />
        <Gerakan5000InfoModal
          isOpen={isGerakan5000InfoOpen}
          onClose={() => setIsGerakan5000InfoOpen(false)}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {activeAppMode === 'public' ? (
        // A. PUBLIC WEBSITE EXPERIENCE
        <>
          <PublicNavbar onScrollTo={handleScrollToSection} />
          <main className="flex-1">
            <PublicLandingPage
              onStartClick={() => {
                setActiveAppMode('login');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </main>
          <PublicFooter onScrollTo={handleScrollToSection} />
        </>
      ) : (
        // B. AUTHENTICATED PLATFORM EXPERIENCE
        <>
          <PlatformHeader />
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-7">
            {currentRole === 'siswa' && <SiswaDashboard />}
            {currentRole === 'orang_tua' && <OrangTuaDashboard />}
            {currentRole === 'dkm' && <DkmDashboard />}
            {currentRole === 'guru_agama' && <GuruAgamaDashboard />}
            {currentRole === 'admin_pemkot' && <AdminPemkotDashboard />}
            {currentRole === 'super_admin' && <SuperAdminDashboard />}
          </main>
          <footer className="hidden md:block border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-500">
            <p>
              {appSettings.appName} {appSettings.appBadge} &bull; Platform Ekosistem Pembentukan Karakter Siswa Kota Cimahi &bull; &ldquo;Me-Ramadhan-kan 11 Bulan Lainnya&rdquo;
            </p>
          </footer>
          <BottomNav />
        </>
      )}

      <Gerakan5000InfoModal
        isOpen={isGerakan5000InfoOpen}
        onClose={() => setIsGerakan5000InfoOpen(false)}
      />

      {/* PWA Mobile Install Banner Prompt */}
      <PwaInstallPrompt />

      {/* Global Scroll To Top Button */}
      <ScrollToTopButton />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <ActivityStreamProvider>
        <MainApp />
      </ActivityStreamProvider>
    </AppProvider>
  );
}
