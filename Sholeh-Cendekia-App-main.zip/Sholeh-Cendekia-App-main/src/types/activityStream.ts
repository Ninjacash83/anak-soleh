export type ActivityStreamType =
  | 'activity_record'
  | 'dkm_verification'
  | 'parent_confirmation'
  | 'lks_completion'
  | 'streak_milestone'
  | 'donation_5000'
  | 'system_update'
  | 'teacher_observation';

export interface ActivityStreamReaction {
  praise: number;
  barakallah: number;
  fire: number;
  masyaAllah: number;
  userReacted?: string[];
}

export interface ActivityStreamItem {
  id: string;
  type: ActivityStreamType;
  actorName: string;
  actorRole: 'siswa' | 'orang_tua' | 'dkm' | 'guru_agama' | 'admin_pemkot' | 'super_admin' | 'sistem';
  actorAvatar?: string;
  title: string;
  description: string;
  schoolName?: string;
  mosqueName?: string;
  kecamatan?: 'Cimahi Utara' | 'Cimahi Tengah' | 'Cimahi Selatan';
  timestamp: string; // ISO string or relative label
  pointsGained?: number;
  badge?: {
    label: string;
    color: 'emerald' | 'amber' | 'indigo' | 'rose' | 'teal' | 'purple' | 'blue';
  };
  reactions: ActivityStreamReaction;
  isLive?: boolean;
}

export type ActivityStreamFilter = 'all' | 'my_school' | 'my_mosque' | 'accomplishments' | 'infak' | 'verifications';
