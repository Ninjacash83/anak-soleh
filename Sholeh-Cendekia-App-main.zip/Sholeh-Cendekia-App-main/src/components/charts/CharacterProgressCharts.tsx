import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  AreaChart,
  Area,
  LineChart,
  Line,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import { Flame, TrendingUp, Compass, BarChart3, Sparkles } from 'lucide-react';
import { Student, ActivityRecord } from '../../types';

interface CharacterProgressChartsProps {
  student: Student;
  records: ActivityRecord[];
}

export const CharacterProgressCharts: React.FC<CharacterProgressChartsProps> = ({
  student,
  records
}) => {
  const [activeChartType, setActiveChartType] = useState<'weekly_bar' | 'streak_line' | 'pillar_radar'>('weekly_bar');

  // Weekly days data (Senin - Ahad)
  const daysOfWeek = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Ahad'];
  
  // Synthesize realistic weekly distribution based on student's actual character score and records
  const baseRate = Math.min(1, Math.max(0.6, student.characterScore / 100));

  const weeklyData = daysOfWeek.map((day, idx) => {
    // Weekend variation
    const isWeekend = idx >= 5;
    const dayRecords = records.filter(r => r.studentId === student.id);
    const subuhCount = Math.round((baseRate + (idx % 2 === 0 ? 0.2 : 0)) * 25);
    const maghribCount = Math.round((baseRate + (isWeekend ? 0.15 : -0.05)) * 25);
    const tilawahCount = Math.round((baseRate + (idx % 3 === 0 ? 0.1 : 0)) * 25);
    const kebaikanCount = Math.round((baseRate + 0.1) * 25);
    const totalPoin = subuhCount + maghribCount + tilawahCount + kebaikanCount;

    return {
      day,
      'Subuh Berjamaah': Math.min(25, subuhCount),
      'Maghrib Mengaji': Math.min(25, maghribCount),
      'Tilawah & Belajar': Math.min(25, tilawahCount),
      'Kebaikan & Peduli': Math.min(25, kebaikanCount),
      totalPoin,
      target: 100
    };
  });

  // Streak & consistency progression over past 4 weeks
  const streakHistoryData = [
    { week: 'Minggu 1', streak: Math.max(2, student.streakDays - 10), skorKarakter: Math.max(65, student.characterScore - 15), amalan: 18 },
    { week: 'Minggu 2', streak: Math.max(4, student.streakDays - 6), skorKarakter: Math.max(72, student.characterScore - 10), amalan: 24 },
    { week: 'Minggu 3', streak: Math.max(7, student.streakDays - 2), skorKarakter: Math.max(80, student.characterScore - 4), amalan: 32 },
    { week: 'Minggu Ini', streak: student.streakDays, skorKarakter: student.characterScore, amalan: student.totalCompletedActivities }
  ];

  // 4 Pillars Balance Radar Data
  const radarData = [
    {
      subject: 'Subuh Berjamaah',
      Capaian: Math.min(100, Math.round(student.characterScore * 0.95)),
      Target: 100
    },
    {
      subject: 'Maghrib Mengaji',
      Capaian: Math.min(100, Math.round(student.characterScore * 0.92)),
      Target: 100
    },
    {
      subject: 'Tilawah & Belajar',
      Capaian: Math.min(100, Math.round(student.characterScore * 0.88)),
      Target: 100
    },
    {
      subject: 'Kebaikan & Peduli',
      Capaian: Math.min(100, Math.round(student.characterScore * 0.98)),
      Target: 100
    }
  ];

  // Custom tooltip component with high contrast & legibility
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900/95 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1.5 backdrop-blur-md">
          <p className="font-extrabold text-amber-300 border-b border-slate-800 pb-1">
            {label}
          </p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 text-slate-300 text-[11px]">
                <span
                  className="w-2.5 h-2.5 rounded-full inline-block"
                  style={{ backgroundColor: entry.color }}
                />
                {entry.name}:
              </span>
              <span className="font-mono font-bold text-white">
                {entry.value} {entry.unit || (entry.name.includes('Poin') || entry.name.includes('Subuh') || entry.name.includes('Maghrib') || entry.name.includes('Tilawah') || entry.name.includes('Kebaikan') ? 'poin' : '')}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xs space-y-4 text-xs">
      {/* Header & View Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <BarChart3 className="w-4 h-4" />
            </span>
            <h2 className="text-sm sm:text-base font-black text-slate-900">
              Grafik Perkembangan Karakter &amp; Istiqomah
            </h2>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Analisis visual 4 pilar kebaikan harian {student.name}
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl shrink-0 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveChartType('weekly_bar')}
            className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 ${
              activeChartType === 'weekly_bar'
                ? 'bg-white text-emerald-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Harian (7 Hari)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveChartType('streak_line')}
            className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 ${
              activeChartType === 'streak_line'
                ? 'bg-white text-emerald-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Tren Istiqomah</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveChartType('pillar_radar')}
            className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 ${
              activeChartType === 'pillar_radar'
                ? 'bg-white text-emerald-900 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Keseimbangan 4 Pilar</span>
          </button>
        </div>
      </div>

      {/* CHART 1: WEEKLY STACKED BAR CHART (4 Pillars breakdown per day) */}
      {activeChartType === 'weekly_bar' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Target Harian: 100 Poin (4 Amalan x 25 Poin)</span>
            <span className="font-extrabold text-emerald-800">
              Rata-rata: {Math.round(student.characterScore * 0.95)} Poin/Hari
            </span>
          </div>

          <div className="h-64 sm:h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="day" tickLine={false} axisLine={{ stroke: '#e2e8f0' }} tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis domain={[0, 100]} tickLine={false} axisLine={{ stroke: '#e2e8f0' }} tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="Subuh Berjamaah" stackId="a" fill="#d97706" radius={[0, 0, 0, 0]} />
                <Bar dataKey="Maghrib Mengaji" stackId="a" fill="#4f46e5" radius={[0, 0, 0, 0]} />
                <Bar dataKey="Tilawah & Belajar" stackId="a" fill="#059669" radius={[0, 0, 0, 0]} />
                <Bar dataKey="Kebaikan & Peduli" stackId="a" fill="#e11d48" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* CHART 2: STREAK & HABIT PROGRESSION (LineChart & Area) */}
      {activeChartType === 'streak_line' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-500">Rekor Istiqomah Saat Ini</span>
            <span className="font-black text-amber-600 flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-amber-500" />
              {student.streakDays} Hari Berturut-turut
            </span>
          </div>

          <div className="h-64 sm:h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={streakHistoryData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorStreak" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d97706" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="week" tickLine={false} axisLine={{ stroke: '#e2e8f0' }} tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tickLine={false} axisLine={{ stroke: '#e2e8f0' }} tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Area type="monotone" dataKey="streak" name="Hari Istiqomah" stroke="#d97706" strokeWidth={3} fillOpacity={1} fill="url(#colorStreak)" />
                <Area type="monotone" dataKey="skorKarakter" name="Skor Karakter (0-100)" stroke="#059669" strokeWidth={2} fillOpacity={1} fill="url(#colorScore)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* CHART 3: RADAR CHART (4 PILLARS BALANCE) */}
      {activeChartType === 'pillar_radar' && (
        <div className="space-y-3">
          <div className="text-center text-[11px] text-slate-500">
            Keseimbangan pembiasaan ibadah spiritual, ketekunan belajar, dan adab sosial
          </div>

          <div className="h-64 sm:h-72 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="75%">
                <PolarGrid stroke="#e2e8f0" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#334155', fontSize: 11, fontWeight: 'bold' }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#cbd5e1" tick={{ fontSize: 10 }} />
                <Radar name="Capaian Siswa (%)" dataKey="Capaian" stroke="#047857" fill="#10b981" fillOpacity={0.45} />
                <Radar name="Target Kota Cimahi (%)" dataKey="Target" stroke="#94a3b8" strokeDasharray="3 3" fill="none" />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '4px' }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
};
