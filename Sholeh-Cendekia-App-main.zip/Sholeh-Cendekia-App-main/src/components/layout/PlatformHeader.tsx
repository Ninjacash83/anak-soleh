import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NotificationDrawer } from '../notifications/NotificationDrawer';
import {
  Globe,
  LogOut,
  GraduationCap,
  Users,
  Building2,
  BookOpen,
  ShieldCheck,
  Bell,
  Sliders
} from 'lucide-react';

export const PlatformHeader: React.FC = () => {
  const {
    currentUser,
    currentRole,
    activeTab,
    setActiveTab,
    setActiveAppMode,
    logout,
    notifications,
    appSettings
  } = useApp();

  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState(false);

  const roleMeta = {
    siswa: { label: 'Siswa', color: 'bg-emerald-100 text-emerald-800 border-emerald-300', icon: GraduationCap },
    orang_tua: { label: 'Orang Tua', color: 'bg-teal-100 text-teal-800 border-teal-300', icon: Users },
    dkm: { label: 'DKM / Masjid', color: 'bg-blue-100 text-blue-800 border-blue-300', icon: Building2 },
    guru_agama: { label: 'Guru Agama', color: 'bg-indigo-100 text-indigo-800 border-indigo-300', icon: BookOpen },
    admin_pemkot: { label: 'Pemkot Cimahi', color: 'bg-purple-100 text-purple-800 border-purple-300', icon: ShieldCheck },
    super_admin: { label: 'Super Admin', color: 'bg-amber-100 text-amber-900 border-amber-300', icon: Sliders }
  };

  const currentMeta = roleMeta[currentRole] || roleMeta.siswa;
  const RoleIcon = currentMeta.icon;

  // Desktop navigation tabs
  const navTabsByRole = {
    siswa: [
      { id: 'beranda', label: 'Beranda' },
      { id: 'buku_kendali', label: 'Buku Kendali' },
      { id: 'belajar', label: 'Belajar & LKS' },
      { id: 'prestasi', label: 'Prestasi' },
      { id: 'profil', label: 'Profil Saya' }
    ],
    orang_tua: [
      { id: 'beranda', label: 'Beranda' },
      { id: 'anak', label: 'Data Anak' },
      { id: 'buku_kendali', label: 'Buku Kendali' },
      { id: 'progress', label: 'Progress Karakter' },
      { id: 'profil', label: 'Profil Keluarga' }
    ],
    dkm: [
      { id: 'beranda', label: 'Beranda' },
      { id: 'siswa', label: 'Daftar Jamaah Santri' },
      { id: 'verifikasi', label: 'Verifikasi Kegiatan' },
      { id: 'rekap', label: 'Rekap Jamaah' },
      { id: 'profil', label: 'Profil DKM' }
    ],
    guru_agama: [
      { id: 'beranda', label: 'Beranda' },
      { id: 'siswa', label: 'Daftar Siswa Sekolah' },
      { id: 'pembinaan', label: 'Catatan Pembinaan' },
      { id: 'progress', label: 'Progress Portofolio' },
      { id: 'profil', label: 'Profil Guru' }
    ],
    admin_pemkot: [
      { id: 'dashboard', label: 'Dashboard Eksekutif' },
      { id: 'program', label: 'Pilar Program' },
      { id: 'wilayah', label: 'Kecamatan & Wilayah' },
      { id: 'ekosistem', label: 'Jejaring Ekosistem' },
      { id: 'profil', label: 'Profil Pemkot' }
    ],
    super_admin: [
      { id: 'dashboard', label: 'Dashboard CMS' },
      { id: 'branding', label: 'Identitas & Logo' },
      { id: 'konten', label: 'Kelola Konten' },
      { id: 'users', label: 'Pengguna' },
      { id: 'master', label: 'Master Data' }
    ]
  };

  const desktopTabs = navTabsByRole[currentRole] || navTabsByRole.siswa;

  // Filter unread notifications relevant to current user role
  const userNotifications = notifications.filter(n => {
    if (n.targetRoles && n.targetRoles.length > 0) {
      return n.targetRoles.includes(currentRole);
    }
    return true;
  });

  const unreadCount = userNotifications.filter(n => !n.isRead).length;

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-18">
            {/* Brand Logo & Title */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setActiveTab(
                    currentRole === 'super_admin' || currentRole === 'admin_pemkot'
                      ? 'dashboard'
                      : 'beranda'
                  );
                }}
                className="flex items-center gap-2.5 text-left group cursor-pointer"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden bg-emerald-950 flex items-center justify-center text-white font-black text-lg shadow-sm border border-emerald-700/40 group-hover:scale-105 transition-all p-0.5 shrink-0">
                  {appSettings.logoImageUrl ? (
                    <img
                      src={appSettings.logoImageUrl}
                      alt={appSettings.appName}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  ) : (
                    <span>{appSettings.logoText || 'SC'}</span>
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-slate-900 tracking-tight text-sm sm:text-base">
                      {appSettings.appName}
                    </span>
                    <span className="px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[10px] font-black tracking-wider uppercase border border-amber-300">
                      {appSettings.appBadge}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium hidden sm:block">
                    Ekosistem Karakter Siswa Kota Cimahi
                  </p>
                </div>
              </button>
            </div>

            {/* Desktop Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1">
              {desktopTabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-emerald-800 text-white shadow-2xs font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>

            {/* Right Header Actions */}
            <div className="flex items-center gap-2 sm:gap-2.5">
              {/* Website Publik link */}
              <button
                onClick={() => {
                  setActiveAppMode('public');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-emerald-800 p-2 sm:px-2.5 sm:py-1.5 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
                title="Lihat Website Publik & Info Program"
                aria-label="Website Publik"
              >
                <Globe className="w-4 h-4 text-emerald-700" />
                <span className="hidden sm:inline">Website Publik</span>
              </button>

              {/* Notification Interactive Bell Button with Badge */}
              <button
                onClick={() => setIsNotificationDrawerOpen(true)}
                className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 active:scale-95 transition-all cursor-pointer"
                title="Buka Pusat Notifikasi"
                aria-label="Notifikasi"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 ? (
                  <span className="absolute top-1 right-1 px-1.5 py-0.2 min-w-[18px] h-[18px] rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center border-2 border-white shadow-xs animate-bounce">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                ) : (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500/80" />
                )}
              </button>

              {/* Current User Pill & Logout */}
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                {currentUser && (
                  <div className="flex items-center gap-2">
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-8 h-8 rounded-full object-cover border border-slate-300"
                    />
                    <div className="hidden sm:block text-left">
                      <p className="text-xs font-bold text-slate-900 truncate max-w-[130px]">
                        {currentUser.name}
                      </p>
                      <div className="flex items-center gap-1">
                        <span className={`inline-flex items-center gap-1 px-1.5 py-0.2 text-[9px] font-bold rounded border ${currentMeta.color}`}>
                          <RoleIcon className="w-2.5 h-2.5" />
                          {currentMeta.label}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => {
                    logout();
                    setActiveAppMode('login');
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:text-rose-700 hover:bg-rose-50 border border-slate-200 transition-colors cursor-pointer"
                  title="Ganti Akun / Keluar"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Ganti Akun</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Interactive Notification Drawer / Popover */}
      <NotificationDrawer
        isOpen={isNotificationDrawerOpen}
        onClose={() => setIsNotificationDrawerOpen(false)}
      />
    </>
  );
};
