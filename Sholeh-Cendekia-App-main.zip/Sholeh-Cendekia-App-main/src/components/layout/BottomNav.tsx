import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Home,
  BookCheck,
  GraduationCap,
  Award,
  User,
  Users,
  TrendingUp,
  CheckSquare,
  BarChart3,
  HeartHandshake,
  LayoutDashboard,
  CalendarCheck,
  MapPin,
  Building2,
  Sliders,
  Sparkles,
  BookOpen
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { currentRole, activeTab, setActiveTab } = useApp();

  // Navigation configurations for each role (strictly max 5 items, professional Lucide icons)
  const navItemsByRole = {
    siswa: [
      { id: 'beranda', label: 'Beranda', icon: Home },
      { id: 'buku_kendali', label: 'Buku Kendali', icon: BookCheck },
      { id: 'belajar', label: 'Belajar', icon: GraduationCap },
      { id: 'prestasi', label: 'Prestasi', icon: Award },
      { id: 'profil', label: 'Profil', icon: User }
    ],
    orang_tua: [
      { id: 'beranda', label: 'Beranda', icon: Home },
      { id: 'anak', label: 'Anak', icon: Users },
      { id: 'buku_kendali', label: 'Buku Kendali', icon: BookCheck },
      { id: 'progress', label: 'Progress', icon: TrendingUp },
      { id: 'profil', label: 'Profil', icon: User }
    ],
    dkm: [
      { id: 'beranda', label: 'Beranda', icon: Home },
      { id: 'siswa', label: 'Siswa', icon: Users },
      { id: 'verifikasi', label: 'Verifikasi', icon: CheckSquare },
      { id: 'rekap', label: 'Rekap', icon: BarChart3 },
      { id: 'profil', label: 'Profil', icon: User }
    ],
    guru_agama: [
      { id: 'beranda', label: 'Beranda', icon: Home },
      { id: 'siswa', label: 'Siswa', icon: Users },
      { id: 'pembinaan', label: 'Pembinaan', icon: HeartHandshake },
      { id: 'progress', label: 'Progress', icon: TrendingUp },
      { id: 'profil', label: 'Profil', icon: User }
    ],
    admin_pemkot: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'program', label: 'Program', icon: CalendarCheck },
      { id: 'wilayah', label: 'Wilayah', icon: MapPin },
      { id: 'ekosistem', label: 'Ekosistem', icon: Building2 },
      { id: 'profil', label: 'Profil', icon: User }
    ],
    super_admin: [
      { id: 'dashboard', label: 'Dashboard', icon: Sliders },
      { id: 'branding', label: 'Identitas', icon: Sparkles },
      { id: 'konten', label: 'Konten LKS', icon: BookOpen },
      { id: 'users', label: 'Pengguna', icon: Users },
      { id: 'master', label: 'Master', icon: Building2 }
    ]
  };

  const items = navItemsByRole[currentRole] || navItemsByRole.siswa;

  return (
    <nav
      aria-label="Navigasi Bawah"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 shadow-[0_-4px_12px_rgba(0,0,0,0.06)]"
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        {items.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-150 cursor-pointer ${
                isActive
                  ? 'text-emerald-700 font-bold scale-105'
                  : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <div
                className={`p-1 rounded-lg transition-colors ${
                  isActive ? 'bg-emerald-50 text-emerald-700' : 'text-slate-500'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              </div>
              <span className={`text-[10px] tracking-tight leading-tight mt-0.5 ${isActive ? 'font-black' : ''}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
