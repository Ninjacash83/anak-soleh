import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ActivityCategory } from '../../types';
import { getTodayDateString, formatIndonesianDate } from '../../utils/dateUtils';
import { HomeCarousel } from '../home/HomeCarousel';
import { BukuKendaliTable } from '../buku-kendali/BukuKendaliTable';
import { LksLibraryView } from '../lks/LksLibraryView';
import { CharacterProgressCharts } from '../charts/CharacterProgressCharts';
import { RealtimeActivityStream } from '../stream/RealtimeActivityStream';
import { RaporKarakterModal } from '../rapor/RaporKarakterModal';
import { PushNotificationManager } from '../notifications/PushNotificationManager';
import {
  Sunrise,
  Moon,
  BookOpen,
  Heart,
  CheckCircle2,
  Flame,
  Award,
  PlusCircle,
  ArrowRight,
  Building2,
  GraduationCap,
  Users,
  HeartHandshake,
  LogOut,
  X,
  FileText,
  Printer
} from 'lucide-react';

export const SiswaDashboard: React.FC = () => {
  const {
    currentStudent,
    records,
    achievements,
    activeTab,
    setActiveTab,
    addActivityRecord,
    setIsGerakan5000InfoOpen,
    logout
  } = useApp();

  const [quickRecordPillar, setQuickRecordPillar] = useState<{
    category: ActivityCategory;
    title: string;
    defaultTitle: string;
  } | null>(null);
  const [quickDesc, setQuickDesc] = useState('');
  const [quickCompanion, setQuickCompanion] = useState<'Orang Tua' | 'Ayah' | 'Ibu' | 'Guru Mengaji' | 'Mandiri'>('Orang Tua');
  const [articleModal, setArticleModal] = useState<'nasehat' | 'berita' | null>(null);
  const [isRaporOpen, setIsRaporOpen] = useState(false);

  if (!currentStudent) {
    return (
      <div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-xs text-slate-600">
        Data profil siswa tidak ditemukan untuk akun ini.
      </div>
    );
  }

  const today = getTodayDateString();
  const studentRecords = records.filter(r => r.studentId === currentStudent.id);
  const todayRecords = studentRecords.filter(r => r.date === today);

  const pillars: {
    category: ActivityCategory;
    title: string;
    defaultTitle: string;
    schedule: string;
    icon: React.ReactNode;
  }[] = [
    {
      category: 'subuh_berjamaah',
      title: 'Subuh Berjamaah',
      defaultTitle: `Sholat Subuh Berjamaah di ${currentStudent.mosqueName}`,
      schedule: '04.30 – 05.15 WIB',
      icon: <Sunrise className="w-5 h-5 text-amber-600" />
    },
    {
      category: 'maghrib_mengaji',
      title: 'Maghrib Mengaji',
      defaultTitle: `Mengaji Ba'da Maghrib di ${currentStudent.mosqueName}`,
      schedule: '18.15 – 19.15 WIB',
      icon: <Moon className="w-5 h-5 text-indigo-600" />
    },
    {
      category: 'tilawah_belajar',
      title: 'Tilawah & Belajar',
      defaultTitle: 'Tadarus Al-Qur’an & Belajar Mandiri',
      schedule: 'Harian Pagi / Malam',
      icon: <BookOpen className="w-5 h-5 text-emerald-700" />
    },
    {
      category: 'kebaikan_kepedulian',
      title: 'Kebaikan & Kepedulian',
      defaultTitle: 'Membantu Orang Tua & Infak Kebaikan',
      schedule: 'Sepanjang Hari',
      icon: <Heart className="w-5 h-5 text-rose-600" />
    }
  ];

  const handleQuickRecordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickRecordPillar) return;

    addActivityRecord({
      studentId: currentStudent.id,
      category: quickRecordPillar.category,
      title: quickRecordPillar.defaultTitle,
      description: quickDesc.trim() || `Melaksanakan ${quickRecordPillar.title} dengan tertib.`,
      companion: quickCompanion
    });

    setQuickDesc('');
    setQuickRecordPillar(null);
  };

  const activeDaysThisWeek = Math.min(7, Math.max(1, currentStudent.streakDays % 8 || 6));

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* ==================== TAB 1: BERANDA (MOBILE HOME HIERARCHY) ==================== */}
      {activeTab === 'beranda' && (
        <div className="space-y-6">
          {/* 1. HEADER: Greeting, Student Name, Class, Avatar */}
          <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-2xs flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <img
                src={currentStudent.avatar}
                alt={currentStudent.name}
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-cover border border-slate-200 shrink-0"
              />
              <div className="min-w-0">
                <p className="text-[11px] font-semibold text-emerald-800">
                  Assalamualaikum, Anak Sholeh!
                </p>
                <h1 className="text-lg sm:text-2xl font-black text-slate-900 truncate">
                  {currentStudent.name}
                </h1>
                <p className="text-xs text-slate-500 truncate">
                  {currentStudent.grade} &middot; {currentStudent.schoolName} &middot; {currentStudent.mosqueName}
                </p>
              </div>
            </div>

            <div className="hidden sm:flex items-center gap-4 shrink-0 text-right">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Istiqomah
                </span>
                <span className="text-lg font-black text-amber-600 inline-flex items-center gap-1">
                  <Flame className="w-4 h-4 fill-amber-500" />
                  {currentStudent.streakDays} Hari
                </span>
              </div>
              <div className="pl-4 border-l border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Skor Karakter
                </span>
                <span className="text-lg font-black text-[#0d5435]">
                  {currentStudent.characterScore}
                </span>
              </div>
              <div className="pl-4 border-l border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsRaporOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer hover:scale-105"
                >
                  <FileText className="w-4 h-4 text-slate-950" />
                  <span>Cetak Rapor 📄</span>
                </button>
              </div>
            </div>
          </div>

          {/* 2. CAROUSEL (5 Content Slides) */}
          <HomeCarousel onOpenArticle={type => setArticleModal(type)} />

          {/* 3. TODAY'S BUKU KENDALI (4 Core Activities) */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                  Buku Kendali Hari Ini
                </h2>
                <p className="text-[11px] text-slate-500">
                  {formatIndonesianDate(today)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('buku_kendali')}
                className="text-xs font-bold text-emerald-800 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Riwayat Lengkap</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {pillars.map(p => {
                const rec = todayRecords.find(r => r.category === p.category);
                const isDone = !!rec;

                return (
                  <div
                    key={p.category}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                      isDone
                        ? 'bg-emerald-50/50 border-emerald-300'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="w-9 h-9 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center">
                          {p.icon}
                        </div>
                        <span
                          className={`text-[11px] font-bold ${
                            isDone ? 'text-emerald-800' : 'text-slate-400'
                          }`}
                        >
                          {isDone ? `Tercatat · ${rec.time}` : 'Belum Dicatat'}
                        </span>
                      </div>

                      <div>
                        <h3 className="font-extrabold text-sm text-slate-900">
                          {p.title}
                        </h3>
                        <p className="text-[11px] text-slate-500">
                          {isDone ? rec.title : p.schedule}
                        </p>
                      </div>
                    </div>

                    {isDone ? (
                      <div className="pt-2 border-t border-emerald-200/70 flex items-center justify-between text-[11px]">
                        <span className={rec.dkmVerified ? 'text-emerald-800 font-bold' : 'text-slate-500'}>
                          {rec.dkmVerified ? 'Diverifikasi DKM' : 'Menunggu DKM'}
                        </span>
                        <span className={rec.parentConfirmed ? 'text-blue-800 font-bold' : 'text-slate-500'}>
                          {rec.parentConfirmed ? 'Ortu OK' : 'Menunggu Ortu'}
                        </span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() =>
                          setQuickRecordPillar({
                            category: p.category,
                            title: p.title,
                            defaultTitle: p.defaultTitle
                          })
                        }
                        className="w-full py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>Catat Sekarang</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* 4. PROGRESS MINGGU INI & RECHARTS GRAPHICAL CHARTS */}
          <section className="space-y-4">
            <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-extrabold text-slate-900">
                    Ringkasan Istiqomah Minggu Ini
                  </h2>
                  <p className="text-xs text-slate-500">
                    Konsistensi pelaksanaan 4 pilar kebaikan harian
                  </p>
                </div>
                <span className="text-sm font-black text-[#0d5435]">
                  {activeDaysThisWeek} / 7 Hari Aktif
                </span>
              </div>

              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-600 rounded-full transition-all"
                  style={{ width: `${Math.round((activeDaysThisWeek / 7) * 100)}%` }}
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 pt-1">
                <span>Rekor Istiqomah: <strong className="text-slate-900">{currentStudent.streakDays} hari berturut-turut</strong></span>
                <span>Total Amalan Tercatat: <strong className="text-slate-900">{currentStudent.totalCompletedActivities} kegiatan</strong></span>
              </div>
            </div>

            {/* Recharts Visual Progress Widget */}
            <CharacterProgressCharts
              student={currentStudent}
              records={studentRecords}
            />
          </section>

          {/* REAL-TIME ACTIVITY STREAM & ACCOMPLISHMENTS */}
          <section className="space-y-3">
            <RealtimeActivityStream
              title="Stream Aktivitas &amp; Prestasi Real-Time Siswa Cimahi"
            />
          </section>

          {/* PUSH NOTIFICATION MANAGER */}
          <section>
            <PushNotificationManager />
          </section>

          {/* DEDICATED STUDENT SEDEKAH SUBUH & INFAK CARD (Menggiring kebaikan & berkah) */}
          <section className="rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-950 p-5 sm:p-6 text-white shadow-lg space-y-3 border border-emerald-800/60 relative overflow-hidden">
            <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1.5 max-w-lg">
                <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                  <HeartHandshake className="w-3.5 h-3.5 text-slate-950" />
                  <span>Sedekah Subuh &amp; Gerakan Peduli Santri</span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-white leading-tight">
                  Yuk Sisihkan Rp1.000 – Rp5.000 Hari Ini!
                </h3>
                <p className="text-xs text-emerald-100/90 leading-relaxed font-medium">
                  &ldquo;Sedekah di waktu subuh didoakan oleh malaikat.&rdquo; Infakmu membantu teman santri mendapatkan LKS gratis dan memuliakan guru ngaji masjid kita di Cimahi.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsGerakan5000InfoOpen(true)}
                className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm shadow-md transition-all shrink-0 flex items-center justify-center gap-2 cursor-pointer hover:scale-105 active:scale-95"
              >
                <HeartHandshake className="w-4 h-4 text-emerald-950" />
                <span>Salurkan Sedekah Sekarang</span>
              </button>
            </div>
          </section>

          {/* 5. LKS / BELAJAR (KEY ENTRY POINT) */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                  LKS &amp; Materi Belajar ({currentStudent.jenjang})
                </h2>
                <p className="text-xs text-slate-500">
                  Kerjakan langsung di HP atau download PDF untuk dicetak
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('belajar')}
                className="text-xs font-bold text-emerald-800 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Buka Pustaka LKS</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <LksLibraryView
              studentId={currentStudent.id}
              defaultJenjang={currentStudent.jenjang}
              compact
            />
          </section>

          {/* 6. PRESTASI */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
                  Prestasi &amp; Lencana Karakter
                </h2>
                <p className="text-xs text-slate-500">
                  Apresiasi ketekunan ibadah dan belajar siswa
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('prestasi')}
                className="text-xs font-bold text-emerald-800 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Semua Prestasi</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {achievements.map(ach => (
                <div
                  key={ach.id}
                  className={`p-4 rounded-2xl border space-y-2 ${
                    ach.isUnlocked
                      ? 'bg-white border-emerald-200'
                      : 'bg-slate-50 border-slate-200 opacity-80'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <Award
                      className={`w-5 h-5 ${
                        ach.isUnlocked ? 'text-amber-500' : 'text-slate-400'
                      }`}
                    />
                    <span className="text-[11px] font-semibold text-slate-500">
                      {ach.criteria}
                    </span>
                  </div>
                  <h3 className="font-extrabold text-xs text-slate-900">
                    {ach.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {ach.description}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* 7. BERITA & NASEHAT ANAK SHOLEH */}
          <section className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-2">
              <span className="text-[11px] font-bold text-emerald-800 uppercase">
                Nasehat Anak Sholeh Hari Ini
              </span>
              <h3 className="text-sm font-extrabold text-slate-900">
                Menjaga Kebiasaan Baik Selepas Ramadhan
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Amalan yang paling dicintai Allah adalah amalan yang dilakukan secara terus-menerus (istiqomah) meskipun sedikit. Mulailah hari dengan Subuh berjamaah dan senyum bakti kepada Ayah serta Bunda.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-2">
              <span className="text-[11px] font-bold text-blue-800 uppercase">
                Kabar Gerakan Kota Cimahi
              </span>
              <h3 className="text-sm font-extrabold text-slate-900">
                Sinergi 342 Masjid &amp; 128 Sekolah di Kota Cimahi
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Ribuan siswa SD, SMP, dan SMA di Cimahi Utara, Tengah, dan Selatan kini aktif mencatat Buku Kendali Anak Sholeh bersama orang tua dan guru mengaji.
              </p>
            </div>
          </section>
        </div>
      )}

      {/* ==================== TAB 2: BUKU KENDALI ==================== */}
      {activeTab === 'buku_kendali' && (
        <div className="space-y-4">
          <BukuKendaliTable filterStudentId={currentStudent.id} />
        </div>
      )}

      {/* ==================== TAB 3: BELAJAR (LKS LIBRARY) ==================== */}
      {activeTab === 'belajar' && (
        <LksLibraryView
          studentId={currentStudent.id}
          defaultJenjang={currentStudent.jenjang}
        />
      )}

      {/* ==================== TAB 4: PRESTASI ==================== */}
      {activeTab === 'prestasi' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                Capaian &amp; Lencana Karakter {currentStudent.name}
              </h2>
              <p className="text-xs text-slate-500">
                Rekor Istiqomah: {currentStudent.streakDays} Hari &middot; Skor Karakter: {currentStudent.characterScore}/100
              </p>
            </div>
            <div className="text-xs font-bold text-emerald-800">
              Total Kegiatan Selesai: {currentStudent.totalCompletedActivities} Amalan
            </div>
          </div>

          {/* Visual Analytics in Prestasi Tab */}
          <CharacterProgressCharts
            student={currentStudent}
            records={studentRecords}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {achievements.map(ach => (
              <div
                key={ach.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Award
                      className={`w-6 h-6 ${
                        ach.isUnlocked ? 'text-amber-500' : 'text-slate-400'
                      }`}
                    />
                    <div>
                      <h3 className="font-extrabold text-sm text-slate-900">{ach.title}</h3>
                      <p className="text-[11px] text-slate-500">{ach.category} &middot; {ach.criteria}</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-800">
                    {ach.progressPercent}%
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{ach.description}</p>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full"
                    style={{ width: `${ach.progressPercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================== TAB 5: PROFIL ==================== */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 space-y-6 text-xs">
          <div className="flex items-center gap-4">
            <img
              src={currentStudent.avatar}
              alt={currentStudent.name}
              className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
            />
            <div>
              <h2 className="text-lg font-extrabold text-slate-900">{currentStudent.name}</h2>
              <p className="text-slate-500">
                {currentStudent.grade} &middot; {currentStudent.schoolName}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-400 font-bold uppercase text-[10px] flex items-center gap-1">
                <GraduationCap className="w-3.5 h-3.5" /> Sekolah &amp; Guru Agama
              </span>
              <p className="font-bold text-slate-900">{currentStudent.schoolName}</p>
              <p className="text-slate-600">Guru PAI: {currentStudent.teacherName}</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-400 font-bold uppercase text-[10px] flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5" /> Masjid Binaan (DKM)
              </span>
              <p className="font-bold text-slate-900">{currentStudent.mosqueName}</p>
              <p className="text-slate-600">Kecamatan: {currentStudent.kecamatan}</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-400 font-bold uppercase text-[10px] flex items-center gap-1">
                <Users className="w-3.5 h-3.5" /> Orang Tua Pendamping
              </span>
              <p className="font-bold text-slate-900">{currentStudent.parentName}</p>
              <p className="text-slate-600">Kontak: {currentStudent.parentPhone}</p>
            </div>

            <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-1.5">
              <span className="text-emerald-800 font-bold uppercase text-[10px] flex items-center gap-1">
                <HeartHandshake className="w-3.5 h-3.5" /> Keberlanjutan Ekosistem
              </span>
              <p className="font-bold text-slate-900">Gerakan Cimahi Pintar 5.000</p>
              <button
                type="button"
                onClick={() => setIsGerakan5000InfoOpen(true)}
                className="text-emerald-800 font-bold hover:underline cursor-pointer"
              >
                Pelajari cara gerakan ini menjaga LKS tetap gratis &rarr;
              </button>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 flex justify-end">
            <button
              type="button"
              onClick={logout}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl border border-rose-200 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar / Ganti Akun</span>
            </button>
          </div>
        </div>
      )}

      {/* Quick Record Modal from Home */}
      {quickRecordPillar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-slate-200 shadow-2xl text-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-slate-900">
                Catat Buku Kendali Hari Ini
              </h3>
              <button
                type="button"
                onClick={() => setQuickRecordPillar(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleQuickRecordSubmit} className="space-y-3.5">
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 font-bold text-emerald-950">
                {quickRecordPillar.defaultTitle}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Didampingi Oleh</label>
                <select
                  value={quickCompanion}
                  onChange={e => setQuickCompanion(e.target.value as typeof quickCompanion)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="Orang Tua">Orang Tua</option>
                  <option value="Ayah">Ayah</option>
                  <option value="Ibu">Ibu</option>
                  <option value="Guru Mengaji">Guru Mengaji / DKM</option>
                  <option value="Mandiri">Mandiri</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Catatan Singkat</label>
                <textarea
                  rows={2}
                  value={quickDesc}
                  onChange={e => setQuickDesc(e.target.value)}
                  placeholder="Contoh: Hadir tepat waktu dan mengikuti doa bersama..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setQuickRecordPillar(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 text-white font-bold rounded-xl cursor-pointer"
                >
                  Simpan ke Buku Kendali
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Article / News Detail Modal from Carousel */}
      {articleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 border border-slate-200 shadow-2xl text-xs space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-800 uppercase">
                {articleModal === 'nasehat' ? 'Nasehat Anak Sholeh' : 'Kabar Sholeh Cendekia Cimahi'}
              </span>
              <button
                type="button"
                onClick={() => setArticleModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <h3 className="text-base font-extrabold text-slate-900">
              {articleModal === 'nasehat'
                ? 'Anak Sholeh Dibentuk dari Kebiasaan Kecil yang Istiqomah'
                : 'Kolaborasi Masjid, Sekolah, dan Keluarga di Kota Cimahi'}
            </h3>
            <p className="text-slate-600 leading-relaxed">
              {articleModal === 'nasehat'
                ? 'Kebiasaan bangun pagi untuk Sholat Subuh Berjamaah, membaca Al-Qur’an selepas Maghrib, mengulang pelajaran dengan LKS, serta membantu orang tua di rumah adalah pondasi utama lahirnya generasi yang sholeh dan cendekia. Jangan meremehkan kebaikan sekecil apa pun.'
                : 'Melalui gerakan Me-Ramadhan-kan 11 Bulan Lainnya, siswa di Kota Cimahi mendapatkan pendampingan terpadu dari orang tua di rumah, verifikasi DKM di masjid, dan pembinaan guru agama di sekolah.'}
            </p>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setArticleModal(null)}
                className="px-4 py-2 bg-emerald-700 text-white font-bold rounded-xl cursor-pointer"
              >
                Mengerti &amp; Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rapor Karakter Printable Modal */}
      {isRaporOpen && (
        <RaporKarakterModal
          student={currentStudent}
          records={records}
          onClose={() => setIsRaporOpen(false)}
        />
      )}
    </div>
  );
};
