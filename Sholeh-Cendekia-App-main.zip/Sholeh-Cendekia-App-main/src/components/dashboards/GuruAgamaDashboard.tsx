import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BukuKendaliTable } from '../buku-kendali/BukuKendaliTable';
import { ObservationNote } from '../../types';
import { formatShortIndonesianDate } from '../../utils/dateUtils';
import { RealtimeActivityStream } from '../stream/RealtimeActivityStream';
import {
  GraduationCap,
  Search,
  MessageSquare,
  Download,
  Send,
  Flame,
  LogOut,
  X
} from 'lucide-react';

export const GuruAgamaDashboard: React.FC = () => {
  const {
    currentUser,
    currentTeacher,
    schoolStudents,
    observations,
    addTeacherObservation,
    activeTab,
    setActiveTab,
    logout
  } = useApp();

  const [selectedStudentForNote, setSelectedStudentForNote] = useState<string | null>(null);
  const [noteAspect, setNoteAspect] = useState<ObservationNote['aspect']>('Adab & Karakter');
  const [noteContent, setNoteContent] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  if (!currentTeacher) {
    return (
      <div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-xs text-slate-600">
        Data profil Guru Agama / Sekolah tidak ditemukan untuk akun ini.
      </div>
    );
  }

  // Strictly scoped to this school's students
  const schoolObservations = observations.filter(
    o => o.schoolId === currentTeacher.schoolId
  );

  const filteredStudents = schoolStudents.filter(
    s =>
      !searchTerm.trim() ||
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.grade.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const avgCharacterScore = Math.round(
    schoolStudents.reduce((acc, curr) => acc + curr.characterScore, 0) /
      (schoolStudents.length || 1)
  );

  const handleNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentForNote || !noteContent.trim()) return;

    addTeacherObservation(
      selectedStudentForNote,
      noteAspect,
      noteContent.trim(),
      'guru_agama',
      currentTeacher.name
    );

    setSelectedStudentForNote(null);
    setNoteContent('');
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* School & Teacher Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-purple-700 text-white flex items-center justify-center shrink-0">
            <GraduationCap className="w-7 h-7" />
          </div>
          <div>
            <p className="text-[11px] font-bold text-purple-800">
              Guru Agama ({currentTeacher.subject}) &middot; {currentTeacher.schoolName}
            </p>
            <h1 className="text-lg sm:text-2xl font-black text-slate-900">
              {currentTeacher.name}
            </h1>
            <p className="text-xs text-slate-500">
              Pembinaan Karakter &amp; Portofolio Sikap Siswa {currentTeacher.schoolName}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200 self-start sm:self-auto text-center">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Siswa Sekolah Ini
            </span>
            <span className="text-lg font-black text-purple-700">{schoolStudents.length}</span>
          </div>
          <div className="pl-4 border-l border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Rata-Rata Karakter
            </span>
            <span className="text-lg font-black text-[#0d5435]">{avgCharacterScore}/100</span>
          </div>
        </div>

        {/* REAL-TIME ACTIVITY STREAM */}
        <RealtimeActivityStream
          title={`Umpan Aktivitas Real-Time Siswa ${currentTeacher.schoolName} & Kota Cimahi`}
        />
      </div>

      {/* ==================== TAB 1: BERANDA ==================== */}
      {activeTab === 'beranda' && (
        <div className="space-y-6">
          {/* School Students Overview */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">
                  Siswa Binaan {currentTeacher.schoolName}
                </h2>
                <p className="text-slate-500">
                  Hanya menampilkan siswa yang terdaftar di {currentTeacher.schoolName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('siswa')}
                className="text-purple-700 font-bold hover:underline cursor-pointer"
              >
                Detail Siswa &rarr;
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {schoolStudents.map(s => (
                <div
                  key={s.id}
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={s.avatar}
                      alt={s.name}
                      className="w-11 h-11 rounded-xl object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <h3 className="font-bold text-slate-900 truncate">{s.name}</h3>
                      <p className="text-[11px] text-slate-500 truncate">
                        {s.grade} &middot; Masjid: {s.mosqueName} &middot; Karakter: {s.characterScore}/100
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedStudentForNote(s.id)}
                    className="px-3 py-1.5 bg-white hover:bg-purple-50 text-purple-700 font-bold rounded-lg border border-purple-200 shrink-0 cursor-pointer"
                  >
                    Catat Sikap
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* School-Scoped Buku Kendali */}
          <BukuKendaliTable filterSchoolId={currentTeacher.schoolId} readOnly />
        </div>
      )}

      {/* ==================== TAB 2: SISWA ==================== */}
      {activeTab === 'siswa' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Daftar Siswa {currentTeacher.schoolName} ({filteredStudents.length})
              </h2>
              <p className="text-slate-500">
                Pemantauan perkembangan ibadah, mengaji, dan karakter siswa sekolah
              </p>
            </div>
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Cari siswa atau kelas..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {filteredStudents.map(student => (
              <div
                key={student.id}
                className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <img
                      src={student.avatar}
                      alt={student.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-purple-800">
                          {student.grade}
                        </span>
                        <span className="text-[11px] font-black text-amber-600 inline-flex items-center gap-1">
                          <Flame className="w-3.5 h-3.5 fill-amber-500" />
                          {student.streakDays} Hari
                        </span>
                      </div>
                      <h3 className="font-extrabold text-sm text-slate-900 mt-0.5 truncate">
                        {student.name}
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        Masjid Binaan: {student.mosqueName} &middot; Wali: {student.parentName}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-500">Skor Karakter PAI</span>
                      <span className="font-extrabold text-[#0d5435]">{student.characterScore}/100</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-600 rounded-full"
                        style={{ width: `${student.characterScore}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setSelectedStudentForNote(student.id)}
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Catat Observasi Sikap</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================== TAB 3: PEMBINAAN ==================== */}
      {activeTab === 'pembinaan' && (
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-4 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Catatan Pembinaan &amp; Observasi Karakter ({currentTeacher.schoolName})
              </h2>
              <p className="text-slate-500">
                Sinergi catatan Guru Agama dan DKM Masjid untuk siswa {currentTeacher.schoolName}
              </p>
            </div>
            {schoolStudents.length > 0 && (
              <button
                type="button"
                onClick={() => setSelectedStudentForNote(schoolStudents[0].id)}
                className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Tulis Catatan Baru</span>
              </button>
            )}
          </div>

          <div className="space-y-3">
            {schoolObservations.map(obs => (
              <div
                key={obs.id}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                  <div>
                    <span className="font-bold text-slate-900">{obs.studentName}</span>
                    <span> &middot; {obs.aspect} &middot; {formatShortIndonesianDate(obs.date)}</span>
                  </div>
                  <span>Oleh: {obs.authorName}</span>
                </div>
                <p className="text-slate-700 italic leading-relaxed">
                  &ldquo;{obs.content}&rdquo;
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================== TAB 4: PROGRESS (RAPOR PAI) ==================== */}
      {activeTab === 'progress' && (
        <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-4 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Laporan Portofolio Sikap Beragama ({currentTeacher.schoolName})
              </h2>
              <p className="text-slate-500">
                Rekapitulasi capaian Buku Kendali dan karakter siswa untuk penilaian PAI sekolah
              </p>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Cetak Laporan Sekolah</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-[10px] font-bold uppercase text-slate-400">
                  <th className="py-2.5 px-3">Nama Siswa</th>
                  <th className="py-2.5 px-3">Kelas</th>
                  <th className="py-2.5 px-3">Masjid Binaan</th>
                  <th className="py-2.5 px-3 text-center">Istiqomah</th>
                  <th className="py-2.5 px-3 text-center">Skor Karakter</th>
                  <th className="py-2.5 px-3 text-center">Predikat PAI</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {schoolStudents.map(s => {
                  const predikat =
                    s.characterScore >= 90 ? 'A (Sangat Baik)' : 'B (Baik)';
                  return (
                    <tr key={s.id}>
                      <td className="py-3 px-3 font-bold text-slate-900">{s.name}</td>
                      <td className="py-3 px-3 text-slate-600">{s.grade}</td>
                      <td className="py-3 px-3 text-slate-600">{s.mosqueName}</td>
                      <td className="py-3 px-3 text-center font-bold text-amber-600">{s.streakDays} Hari</td>
                      <td className="py-3 px-3 text-center font-black text-[#0d5435]">{s.characterScore}</td>
                      <td className="py-3 px-3 text-center font-bold text-emerald-800">{predikat}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== TAB 5: PROFIL ==================== */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 space-y-5 text-xs">
          <div className="flex items-center gap-4">
            <img
              src={currentUser?.avatar}
              alt={currentTeacher.name}
              className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
            />
            <div>
              <h2 className="text-lg font-extrabold text-slate-900">{currentTeacher.name}</h2>
              <p className="text-slate-500">
                {currentTeacher.subject} &middot; {currentTeacher.schoolName}
              </p>
              <p className="text-slate-500">Kontak: {currentTeacher.phone}</p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 flex justify-end">
            <button
              type="button"
              onClick={logout}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl border border-rose-200 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar / Ganti Akun</span>
            </button>
          </div>
        </div>
      )}

      {/* Modal Input Catatan Guru Agama */}
      {selectedStudentForNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-slate-200 shadow-2xl text-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-slate-900">
                Catat Observasi Sikap ({currentTeacher.schoolName})
              </h3>
              <button
                type="button"
                onClick={() => setSelectedStudentForNote(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleNoteSubmit} className="space-y-3.5">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Pilih Siswa Sekolah</label>
                <select
                  value={selectedStudentForNote}
                  onChange={e => setSelectedStudentForNote(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  {schoolStudents.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.grade})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Aspek Karakter</label>
                <select
                  value={noteAspect}
                  onChange={e => setNoteAspect(e.target.value as ObservationNote['aspect'])}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="Adab & Karakter">Adab &amp; Karakter</option>
                  <option value="Sholat & Ibadah">Sholat &amp; Ketertiban Ibadah</option>
                  <option value="Makhraj & Tilawah">Makhraj &amp; Tilawah</option>
                  <option value="Kepedulian Sosial">Kepedulian Sosial</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Catatan Pembinaan</label>
                <textarea
                  required
                  rows={3}
                  value={noteContent}
                  onChange={e => setNoteContent(e.target.value)}
                  placeholder="Tuliskan observasi perkembangan karakter siswa di sekolah..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedStudentForNote(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-700 text-white font-bold rounded-xl cursor-pointer"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
