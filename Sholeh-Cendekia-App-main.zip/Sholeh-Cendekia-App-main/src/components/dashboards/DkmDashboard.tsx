import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BukuKendaliTable } from '../buku-kendali/BukuKendaliTable';
import { ObservationNote } from '../../types';
import { formatShortIndonesianDate } from '../../utils/dateUtils';
import { RealtimeActivityStream } from '../stream/RealtimeActivityStream';
import {
  Building2,
  CheckCircle2,
  CheckSquare,
  MessageSquare,
  LogOut,
  Users,
  Printer,
  X
} from 'lucide-react';

export const DkmDashboard: React.FC = () => {
  const {
    currentUser,
    currentMosque,
    mosqueStudents,
    mosqueRecords,
    verifyActivityDKM,
    addTeacherObservation,
    activeTab,
    setActiveTab,
    logout
  } = useApp();

  const [selectedStudentForNote, setSelectedStudentForNote] = useState<string | null>(null);
  const [noteAspect, setNoteAspect] = useState<ObservationNote['aspect']>('Makhraj & Tilawah');
  const [noteText, setNoteText] = useState('');

  if (!currentMosque) {
    return (
      <div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-xs text-slate-600">
        Data profil DKM / Masjid tidak ditemukan untuk akun ini.
      </div>
    );
  }

  // Strictly scoped to this mosque's students only
  const pendingRecords = mosqueRecords.filter(r => !r.dkmVerified);

  const handleSendNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentForNote || !noteText.trim()) return;

    addTeacherObservation(
      selectedStudentForNote,
      noteAspect,
      noteText.trim(),
      'dkm',
      currentUser?.name || currentMosque.dkmLeader
    );

    setSelectedStudentForNote(null);
    setNoteText('');
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Mosque Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-blue-700 text-white flex items-center justify-center shrink-0">
            <Building2 className="w-7 h-7" />
          </div>
          <div>
            <p className="text-[11px] font-bold text-blue-800">
              DKM &amp; Guru Mengaji &middot; Wilayah {currentMosque.kecamatan}
            </p>
            <h1 className="text-lg sm:text-2xl font-black text-slate-900">
              {currentMosque.name}
            </h1>
            <p className="text-xs text-slate-500">
              {currentMosque.address} &middot; Pembina: {currentMosque.dkmLeader}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200 self-start sm:self-auto text-center">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Perlu Verifikasi
            </span>
            <span className="text-lg font-black text-amber-600">{pendingRecords.length}</span>
          </div>
          <div className="pl-4 border-l border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Siswa Masjid Ini
            </span>
            <span className="text-lg font-black text-blue-700">{mosqueStudents.length}</span>
          </div>
        </div>
      </div>

      {/* ==================== TAB 1: BERANDA ==================== */}
      {activeTab === 'beranda' && (
        <div className="space-y-6">
          {/* Mosque-Scoped Pending Verification Queue */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-4 text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-blue-700" />
                  Antrean Verifikasi Jamaah Siswa ({currentMosque.name})
                </h2>
                <p className="text-slate-500">
                  Hanya menampilkan siswa yang terdaftar di {currentMosque.name}
                </p>
              </div>

              {pendingRecords.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    pendingRecords.forEach(r =>
                      verifyActivityDKM(
                        r.id,
                        `Diverifikasi hadir di ${currentMosque.name}.`,
                        currentMosque.dkmLeader
                      )
                    );
                  }}
                  className="px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl self-start sm:self-auto cursor-pointer"
                >
                  Verifikasi Semua ({pendingRecords.length})
                </button>
              )}
            </div>

            {pendingRecords.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500">
                <CheckCircle2 className="w-7 h-7 text-emerald-600 mx-auto mb-1.5" />
                <p className="font-bold text-slate-800">
                  Seluruh kegiatan siswa jamaah {currentMosque.name} telah diverifikasi.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {pendingRecords.map(rec => (
                  <div
                    key={rec.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-[11px] text-slate-500">
                        <span className="font-bold text-slate-900">{rec.studentName}</span>
                        <span> &middot; {rec.schoolName} &middot; {formatShortIndonesianDate(rec.date)} {rec.time} WIB</span>
                      </div>
                      <h3 className="font-bold text-slate-900 mt-0.5">{rec.title}</h3>
                      <p className="text-slate-600">{rec.description}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        verifyActivityDKM(
                          rec.id,
                          `Alhamdulillah hadir dan mengikuti kegiatan di ${currentMosque.name} dengan baik.`,
                          currentMosque.dkmLeader
                        )
                      }
                      className="px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl shrink-0 self-start sm:self-auto cursor-pointer"
                    >
                      Verifikasi 1-Klik
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Registered Mosque Students Quick Overview */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-extrabold text-slate-900">
                Siswa Binaan Terdaftar di {currentMosque.name}
              </h2>
              <button
                type="button"
                onClick={() => setActiveTab('siswa')}
                className="text-blue-700 font-bold hover:underline cursor-pointer"
              >
                Kelola Siswa &rarr;
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {mosqueStudents.map(s => (
                <div
                  key={s.id}
                  className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={s.avatar}
                      alt={s.name}
                      className="w-10 h-10 rounded-xl object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <h3 className="font-bold text-slate-900 truncate">{s.name}</h3>
                      <p className="text-[11px] text-slate-500 truncate">
                        {s.grade} &middot; {s.schoolName} &middot; Istiqomah {s.streakDays} Hari
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedStudentForNote(s.id)}
                    className="px-3 py-1.5 bg-white hover:bg-blue-50 text-blue-700 font-bold rounded-lg border border-blue-200 shrink-0 cursor-pointer"
                  >
                    Catatan
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* REAL-TIME ACTIVITY STREAM */}
          <RealtimeActivityStream
            title={`Umpan Aktivitas Real-Time Jamaah ${currentMosque.name} & Kota Cimahi`}
          />
        </div>
      )}

      {/* ==================== TAB 2: SISWA ==================== */}
      {activeTab === 'siswa' && (
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-4 text-xs">
          <div>
            <h2 className="text-base font-extrabold text-slate-900">
              Daftar Siswa Jamaah {currentMosque.name} ({mosqueStudents.length} Siswa)
            </h2>
            <p className="text-slate-500">
              Beri catatan bimbingan tajwid, makhraj, atau adab di masjid yang terhubung langsung ke Orang Tua &amp; Guru Agama.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mosqueStudents.map(s => (
              <div
                key={s.id}
                className="p-4 rounded-2xl border border-slate-200 space-y-3 flex flex-col justify-between"
              >
                <div className="flex items-start gap-3">
                  <img
                    src={s.avatar}
                    alt={s.name}
                    className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                  />
                  <div className="min-w-0 flex-1">
                    <h3 className="font-extrabold text-sm text-slate-900">{s.name}</h3>
                    <p className="text-slate-500">
                      {s.grade} &middot; {s.schoolName}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Orang Tua: {s.parentName} ({s.parentPhone})
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <span className="text-[11px] text-slate-500">
                    Istiqomah: <strong className="text-slate-900">{s.streakDays} Hari</strong> &middot; Skor: <strong className="text-emerald-800">{s.characterScore}</strong>
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedStudentForNote(s.id)}
                    className="px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Kirim Catatan Pembinaan</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================== TAB 3: VERIFIKASI ==================== */}
      {activeTab === 'verifikasi' && (
        <BukuKendaliTable filterMosqueId={currentMosque.id} />
      )}

      {/* ==================== TAB 4: REKAP ==================== */}
      {activeTab === 'rekap' && (
        <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-4 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Rekapitulasi Kehadiran Jamaah Siswa ({currentMosque.name})
              </h2>
              <p className="text-slate-500">
                Data kehadiran Subuh Berjamaah &amp; Maghrib Mengaji siswa binaan masjid
              </p>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Rekap Masjid</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-[10px] font-bold uppercase text-slate-400">
                  <th className="py-2.5 px-3">Nama Siswa</th>
                  <th className="py-2.5 px-3">Kelas &amp; Sekolah</th>
                  <th className="py-2.5 px-3">Orang Tua</th>
                  <th className="py-2.5 px-3 text-center">Istiqomah</th>
                  <th className="py-2.5 px-3 text-center">Total Amalan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {mosqueStudents.map(s => (
                  <tr key={s.id}>
                    <td className="py-3 px-3 font-bold text-slate-900">{s.name}</td>
                    <td className="py-3 px-3 text-slate-600">{s.grade} &middot; {s.schoolName}</td>
                    <td className="py-3 px-3 text-slate-600">{s.parentName}</td>
                    <td className="py-3 px-3 text-center font-bold text-amber-600">{s.streakDays} Hari</td>
                    <td className="py-3 px-3 text-center font-bold text-emerald-800">{s.totalCompletedActivities}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== TAB 5: PROFIL ==================== */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 space-y-5 text-xs">
          <div className="flex items-center gap-4">
            <img
              src={currentUser?.avatar}
              alt={currentMosque.dkmLeader}
              className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
            />
            <div>
              <h2 className="text-lg font-extrabold text-slate-900">{currentMosque.name}</h2>
              <p className="text-slate-500">Ketua Pembina: {currentMosque.dkmLeader}</p>
              <p className="text-slate-500">{currentMosque.address} ({currentMosque.kecamatan})</p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 flex justify-end">
            <button
              type="button"
              onClick={logout}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl border border-rose-200 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar / Ganti Akun</span>
            </button>
          </div>
        </div>
      )}

      {/* Modal Input Catatan Pembinaan DKM */}
      {selectedStudentForNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-slate-200 shadow-2xl text-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-slate-900">
                Catatan Pembinaan DKM ({currentMosque.name})
              </h3>
              <button
                type="button"
                onClick={() => setSelectedStudentForNote(null)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-600">
              Siswa: <strong>{mosqueStudents.find(s => s.id === selectedStudentForNote)?.name}</strong>
            </p>

            <form onSubmit={handleSendNote} className="space-y-3.5">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Aspek Pembinaan</label>
                <select
                  value={noteAspect}
                  onChange={e => setNoteAspect(e.target.value as ObservationNote['aspect'])}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="Makhraj & Tilawah">Makhraj &amp; Tilawah Al-Qur’an</option>
                  <option value="Sholat & Ibadah">Sholat Berjamaah &amp; Dzikir</option>
                  <option value="Adab & Karakter">Adab di Masjid</option>
                  <option value="Kepedulian Sosial">Kepedulian &amp; Kebersihan Masjid</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Pesan Pembinaan</label>
                <textarea
                  required
                  rows={3}
                  value={noteText}
                  onChange={e => setNoteText(e.target.value)}
                  placeholder="Tuliskan perkembangan mengaji atau kehadiran siswa untuk orang tua..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedStudentForNote(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-700 text-white font-bold rounded-xl cursor-pointer"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
