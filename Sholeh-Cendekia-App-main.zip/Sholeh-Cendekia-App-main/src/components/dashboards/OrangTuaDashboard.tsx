import React from 'react';
import { useApp } from '../../context/AppContext';
import { BukuKendaliTable } from '../buku-kendali/BukuKendaliTable';
import { CharacterProgressCharts } from '../charts/CharacterProgressCharts';
import { RealtimeActivityStream } from '../stream/RealtimeActivityStream';
import { RaporKarakterModal } from '../rapor/RaporKarakterModal';
import { formatShortIndonesianDate, getTodayDateString } from '../../utils/dateUtils';
import {
  Users,
  HeartHandshake,
  MessageSquare,
  Flame,
  Award,
  CheckCircle2,
  LogOut,
  ChevronRight,
  FileText,
  Printer
} from 'lucide-react';

export const OrangTuaDashboard: React.FC = () => {
  const {
    currentUser,
    currentParent,
    parentChildren,
    selectedChild,
    setSelectedChildId,
    records,
    observations,
    achievements,
    activeTab,
    setActiveTab,
    confirmActivityParent,
    setIsGerakan5000InfoOpen,
    logout
  } = useApp();

  const [isRaporOpen, setIsRaporOpen] = React.useState(false);

  if (!currentParent || !selectedChild) {
    return (
      <div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-xs text-slate-600">
        Data profil orang tua atau anak belum terhubung.
      </div>
    );
  }

  const today = getTodayDateString();
  const childRecords = records.filter(r => r.studentId === selectedChild.id);
  const childObservations = observations.filter(o => o.studentId === selectedChild.id);
  const unconfirmedRecords = childRecords.filter(r => !r.parentConfirmed);
  const todayChildRecords = childRecords.filter(r => r.date === today);

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Child Selector Header Bar (Always visible when parent has > 1 child) */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <img
            src={currentUser?.avatar}
            alt={currentParent.name}
            className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shrink-0"
          />
          <div>
            <p className="text-[11px] font-bold text-orange-700">
              Pendamping Keluarga &middot; {currentParent.address}
            </p>
            <h1 className="text-lg sm:text-xl font-black text-slate-900">
              {currentParent.name}
            </h1>
            <p className="text-xs text-slate-500">
              Ananda Terpilih: <strong className="text-slate-900">{selectedChild.name}</strong> ({selectedChild.grade} &middot; {selectedChild.schoolName})
            </p>
          </div>
        </div>

        {/* Child Switcher */}
        {parentChildren.length > 1 && (
          <div className="flex flex-col sm:items-end gap-1.5">
            <span className="text-[10px] font-bold uppercase text-slate-400">
              Pilih Anak ({parentChildren.length} Siswa Terdaftar):
            </span>
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
              {parentChildren.map(child => {
                const isSelected = child.id === selectedChild.id;
                return (
                  <button
                    key={child.id}
                    type="button"
                    onClick={() => setSelectedChildId(child.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                      isSelected
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <img
                      src={child.avatar}
                      alt={child.name}
                      className="w-5 h-5 rounded-full object-cover"
                    />
                    <span>{child.name.split(' ')[0]} ({child.grade})</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ==================== TAB 1: BERANDA ==================== */}
      {activeTab === 'beranda' && (
        <div className="space-y-6">
          {/* Snapshot Metrics for Selected Child */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="bg-white p-4 rounded-2xl border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Istiqomah
              </span>
              <span className="text-lg sm:text-2xl font-black text-amber-600 inline-flex items-center gap-1 mt-0.5">
                <Flame className="w-4 h-4 fill-amber-500" />
                {selectedChild.streakDays} Hari
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Skor Karakter
              </span>
              <span className="text-lg sm:text-2xl font-black text-[#0d5435] block mt-0.5">
                {selectedChild.characterScore}
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">
                Perlu Konfirmasi
              </span>
              <span className="text-lg sm:text-2xl font-black text-orange-600 block mt-0.5">
                {unconfirmedRecords.length}
              </span>
            </div>

            <button
              type="button"
              onClick={() => setIsRaporOpen(true)}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 p-4 rounded-2xl border border-amber-300 flex flex-col items-center justify-center transition-all cursor-pointer shadow-sm hover:scale-102"
            >
              <FileText className="w-5 h-5 text-slate-950 mb-0.5" />
              <span className="text-xs font-black">Cetak Rapor Anak 📄</span>
            </button>
          </div>

          {/* Quick Confirmation Queue */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-extrabold text-slate-900">
                  Konfirmasi Kegiatan Ananda ({selectedChild.name})
                </h2>
                <p className="text-slate-500">
                  Kegiatan yang telah dicatat oleh ananda hôm ini ({todayChildRecords.length} tercatat hari ini)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('buku_kendali')}
                className="text-emerald-800 font-bold hover:underline cursor-pointer"
              >
                Buka Buku Kendali &rarr;
              </button>
            </div>

            {unconfirmedRecords.length === 0 ? (
              <div className="p-5 rounded-xl bg-slate-50 text-center text-slate-500">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
                Seluruh kegiatan {selectedChild.name} sudah Bunda/Ayah konfirmasi.
              </div>
            ) : (
              <div className="space-y-2.5">
                {unconfirmedRecords.map(rec => (
                  <div
                    key={rec.id}
                    className="p-3.5 rounded-xl bg-orange-50/50 border border-orange-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-[11px] text-slate-500">
                        <span className="font-bold text-slate-800">{rec.title}</span>
                        <span> &middot; {formatShortIndonesianDate(rec.date)} &middot; {rec.time} WIB</span>
                      </div>
                      <p className="text-slate-600 mt-0.5">{rec.description}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        confirmActivityParent(
                          rec.id,
                          `Alhamdulillah, Bunda konfirmasi kegiatan ${selectedChild.name}. Semoga istiqomah.`
                        )
                      }
                      className="px-3.5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shrink-0 self-start sm:self-auto flex items-center gap-1.5 cursor-pointer"
                    >
                      <HeartHandshake className="w-3.5 h-3.5" />
                      <span>Konfirmasi 1-Klik</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Catatan dari Guru Agama & Ustadz DKM */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-3 text-xs">
            <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-emerald-700" />
              Catatan Pembinaan Guru Agama &amp; DKM untuk {selectedChild.name}
            </h2>
            {childObservations.length === 0 ? (
              <p className="text-slate-500">Belum ada catatan observasi untuk anak ini.</p>
            ) : (
              <div className="space-y-2.5">
                {childObservations.map(obs => (
                  <div
                    key={obs.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1"
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span className="font-bold text-slate-900">
                        {obs.authorName} ({obs.authorRole === 'dkm' ? 'DKM Masjid' : 'Guru Agama'})
                      </span>
                      <span>
                        {obs.aspect} &middot; {formatShortIndonesianDate(obs.date)}
                      </span>
                    </div>
                    <p className="text-slate-700 italic leading-relaxed">
                      &ldquo;{obs.content}&rdquo;
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* REAL-TIME ACTIVITY STREAM */}
          <RealtimeActivityStream
            title={`Umpan Aktivitas Real-Time Komunitas & Teman ${selectedChild.name}`}
          />

          {/* Nudge Banner: Gerakan 5.000 untuk Orang Tua */}
          <div className="rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-950 p-5 sm:p-6 text-white shadow-lg space-y-3 border border-emerald-800/60 relative overflow-hidden">
            <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1.5 max-w-lg">
                <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                  <HeartHandshake className="w-3.5 h-3.5 text-slate-950" />
                  <span>Dukungan Orang Tua &bull; Gerakan 5.000 / Bulan</span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-white leading-tight">
                  Investasi Jariyah untuk Membina Karakter Buah Hati
                </h3>
                <p className="text-xs text-emerald-100/90 leading-relaxed font-medium">
                  Dengan partisipasi Rp5.000/bulan (atau sukarela), Ayah &amp; Bunda ikut memastikan ketersediaan LKS gratis untuk seluruh anak Cimahi dan mendukung para ustadz di masjid.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsGerakan5000InfoOpen(true)}
                className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm shadow-md transition-all shrink-0 flex items-center justify-center gap-2 cursor-pointer hover:scale-105 active:scale-95"
              >
                <HeartHandshake className="w-4 h-4 text-emerald-950" />
                <span>Salurkan Dukungan Rp5.000</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 2: ANAK ==================== */}
      {activeTab === 'anak' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200">
            <h2 className="text-base font-extrabold text-slate-900">
              Daftar Anak dalam Pendampingan Keluarga
            </h2>
            <p className="text-xs text-slate-500">
              Pilih anak untuk melihat detail Buku Kendali dan progres pembiasaan masing-masing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {parentChildren.map(child => {
              const isSelected = child.id === selectedChild.id;
              return (
                <div
                  key={child.id}
                  className={`p-5 rounded-2xl border transition-all space-y-4 ${
                    isSelected
                      ? 'bg-white border-emerald-600 ring-2 ring-emerald-600/15'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <img
                      src={child.avatar}
                      alt={child.name}
                      className="w-14 h-14 rounded-2xl object-cover border border-slate-200"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base font-extrabold text-slate-900 truncate">
                        {child.name}
                      </h3>
                      <p className="text-slate-500">
                        {child.grade} &middot; {child.schoolName}
                      </p>
                      <p className="text-slate-500 text-[11px]">
                        Masjid Binaan: {child.mosqueName} &middot; Guru PAI: {child.teacherName}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block">Istiqomah</span>
                      <span className="font-black text-amber-600 text-sm">{child.streakDays} Hari</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block">Karakter</span>
                      <span className="font-black text-[#0d5435] text-sm">{child.characterScore}/100</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block">Total Amalan</span>
                      <span className="font-black text-slate-900 text-sm">{child.totalCompletedActivities}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedChildId(child.id);
                      setActiveTab('buku_kendali');
                    }}
                    className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>Lihat Buku Kendali {child.name.split(' ')[0]}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================== TAB 3: BUKU KENDALI ==================== */}
      {activeTab === 'buku_kendali' && (
        <BukuKendaliTable filterStudentId={selectedChild.id} />
      )}

      {/* ==================== TAB 4: PROGRESS ==================== */}
      {activeTab === 'progress' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-4">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Perkembangan 4 Pilar Karakter: {selectedChild.name}
              </h2>
              <p className="text-xs text-slate-500">
                Berdasarkan catatan Buku Kendali yang dikonfirmasi orang tua dan diverifikasi {selectedChild.mosqueName}
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-2xl font-black text-amber-600 block">86%</span>
                <span className="text-xs font-bold text-slate-900 mt-1 block">Subuh Berjamaah</span>
                <span className="text-[11px] text-slate-500 block">{selectedChild.mosqueName}</span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-2xl font-black text-indigo-700 block">80%</span>
                <span className="text-xs font-bold text-slate-900 mt-1 block">Maghrib Mengaji</span>
                <span className="text-[11px] text-slate-500 block">Halaqah Al-Qur’an</span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-2xl font-black text-emerald-800 block">88%</span>
                <span className="text-xs font-bold text-slate-900 mt-1 block">Tilawah &amp; Belajar</span>
                <span className="text-[11px] text-slate-500 block">LKS &amp; Tadarus</span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-2xl font-black text-rose-700 block">92%</span>
                <span className="text-xs font-bold text-slate-900 mt-1 block">Kebaikan &amp; Peduli</span>
                <span className="text-[11px] text-slate-500 block">Bakti Keluarga</span>
              </div>
            </div>
          </div>

          {/* Graphical Analytics with Recharts */}
          <CharacterProgressCharts
            student={selectedChild}
            records={childRecords}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {achievements.map(ach => (
              <div key={ach.id} className="bg-white rounded-2xl p-4 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-amber-500" />
                    {ach.title}
                  </span>
                  <span className="font-bold text-emerald-800">{ach.progressPercent}%</span>
                </div>
                <p className="text-slate-600">{ach.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================== TAB 5: PROFIL ==================== */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 space-y-5 text-xs">
          <div className="flex items-center gap-4">
            <img
              src={currentUser?.avatar}
              alt={currentParent.name}
              className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
            />
            <div>
              <h2 className="text-lg font-extrabold text-slate-900">{currentParent.name}</h2>
              <p className="text-slate-500">{currentParent.email} &middot; {currentParent.phone}</p>
              <p className="text-slate-500">{currentParent.address}</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="font-bold text-emerald-950">Gerakan Cimahi Pintar 5.000</p>
              <p className="text-[11px] text-slate-600">
                Dukung ketersediaan LKS gratis dan pembinaan masjid bagi seluruh anak Kota Cimahi.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsGerakan5000InfoOpen(true)}
              className="px-4 py-2 bg-emerald-700 text-white font-bold rounded-xl shrink-0 cursor-pointer"
            >
              Informasi Gerakan
            </button>
          </div>

          <div className="pt-2 border-t border-slate-200 flex justify-end">
            <button
              type="button"
              onClick={logout}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl border border-rose-200 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar / Ganti Akun</span>
            </button>
          </div>
        </div>
      )}

      {/* Rapor Karakter Printable Modal */}
      {isRaporOpen && selectedChild && (
        <RaporKarakterModal
          student={selectedChild}
          records={records}
          onClose={() => setIsRaporOpen(false)}
        />
      )}
    </div>
  );
};
