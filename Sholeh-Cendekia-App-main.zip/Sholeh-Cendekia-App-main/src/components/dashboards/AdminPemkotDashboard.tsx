import React from 'react';
import { useApp } from '../../context/AppContext';
import { RealtimeActivityStream } from '../stream/RealtimeActivityStream';
import {
  ShieldCheck,
  MapPin,
  Download,
  HeartHandshake,
  LogOut,
  RotateCcw
} from 'lucide-react';

export const AdminPemkotDashboard: React.FC = () => {
  const {
    currentUser,
    cityMetrics,
    partners,
    schools,
    mosques,
    teachers,
    activeTab,
    setIsGerakan5000InfoOpen,
    resetDemoData,
    logout
  } = useApp();

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-[#0d5435] text-white flex items-center justify-center shrink-0">
            <ShieldCheck className="w-7 h-7 text-amber-300" />
          </div>
          <div>
            <p className="text-[11px] font-bold text-emerald-800">
              Pusat Komando Ekosistem &middot; Pemerintah Kota Cimahi
            </p>
            <h1 className="text-lg sm:text-2xl font-black text-slate-900">
              Monitoring Agregat Kota Cimahi
            </h1>
            <p className="text-xs text-slate-500">
              Koordinasi Lintas Dinas (Disdik, Kesra) &bull; Data Agregat Tanpa Ekspos Privasi Siswa
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => window.print()}
          className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 self-start sm:self-auto shrink-0 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Ekspor Laporan Kota</span>
        </button>
      </div>

      {/* ==================== TAB 1: DASHBOARD ==================== */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* 6 Aggregated Citywide KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Total Siswa</span>
              <p className="text-xl font-black text-slate-900">
                {cityMetrics.coverage.totalStudents.toLocaleString('id-ID')}
              </p>
              <span className="text-[11px] text-emerald-800 font-semibold block">
                {cityMetrics.coverage.activeStudents.toLocaleString('id-ID')} Aktif
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Sekolah</span>
              <p className="text-xl font-black text-slate-900">{cityMetrics.coverage.schoolsCount}</p>
              <span className="text-[11px] text-slate-500 block">SD, SMP, SMA/K</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Masjid / DKM</span>
              <p className="text-xl font-black text-blue-700">{cityMetrics.coverage.mosquesCount}</p>
              <span className="text-[11px] text-slate-500 block">Titik Pembinaan</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Guru Agama</span>
              <p className="text-xl font-black text-purple-700">{cityMetrics.coverage.teachersCount}</p>
              <span className="text-[11px] text-slate-500 block">Pembina PAI</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Akun Orang Tua</span>
              <p className="text-xl font-black text-orange-600">
                {cityMetrics.coverage.parentsCount.toLocaleString('id-ID')}
              </p>
              <span className="text-[11px] text-slate-500 block">Keluarga</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Partisipasi Kota</span>
              <p className="text-xl font-black text-[#0d5435]">{cityMetrics.participation.overallRate}%</p>
              <span className="text-[11px] text-emerald-800 font-semibold block">Target 85%</span>
            </div>
          </div>

          {/* 4 Pillars Aggregated Participation */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-4">
            <h2 className="text-sm font-extrabold text-slate-900">
              Capaian Agregat 4 Pilar Pembiasaan Se-Kota Cimahi
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between font-bold">
                  <span>1. Subuh Berjamaah</span>
                  <span className="text-amber-700">{cityMetrics.participation.subuhBerjamaah}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-600 rounded-full"
                    style={{ width: `${cityMetrics.participation.subuhBerjamaah}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500">Kehadiran jamaah di 342 masjid</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between font-bold">
                  <span>2. Maghrib Mengaji</span>
                  <span className="text-indigo-700">{cityMetrics.participation.maghribMengaji}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 rounded-full"
                    style={{ width: `${cityMetrics.participation.maghribMengaji}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500">Halaqah Al-Qur’an ba’da maghrib</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between font-bold">
                  <span>3. Tilawah &amp; Belajar</span>
                  <span className="text-emerald-800">{cityMetrics.participation.tilawahBelajar}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full"
                    style={{ width: `${cityMetrics.participation.tilawahBelajar}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500">Penyelesaian LKS &amp; tadarus mandiri</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between font-bold">
                  <span>4. Kebaikan &amp; Peduli</span>
                  <span className="text-rose-700">{cityMetrics.participation.kebaikanKepedulian}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-rose-600 rounded-full"
                    style={{ width: `${cityMetrics.participation.kebaikanKepedulian}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-500">Bakti orang tua &amp; kepedulian sosial</p>
              </div>
            </div>
          </div>

          {/* REAL-TIME STREAM FOR PEMKOT COMMAND CENTER */}
          <RealtimeActivityStream
            title="Stream Pusat Komando: Aktivitas &amp; Prestasi Real-Time Se-Kota Cimahi"
          />
        </div>
      )}

      {/* ==================== TAB 2: PROGRAM ==================== */}
      {activeTab === 'program' && (
        <div className="space-y-6 text-xs">
          {/* Schools Institutional Table */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3">
            <h2 className="text-sm font-extrabold text-slate-900">
              Data Satuan Pendidikan Terintegrasi ({schools.length} Sekolah Percontohan)
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-[10px] font-bold uppercase text-slate-400">
                    <th className="py-2 px-3">Nama Sekolah</th>
                    <th className="py-2 px-3">Jenjang</th>
                    <th className="py-2 px-3">Kecamatan</th>
                    <th className="py-2 px-3 text-right">Populasi Siswa</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {schools.map(sch => (
                    <tr key={sch.id}>
                      <td className="py-2.5 px-3 font-bold text-slate-900">{sch.name}</td>
                      <td className="py-2.5 px-3 text-slate-600">{sch.level}</td>
                      <td className="py-2.5 px-3 text-slate-600">{sch.kecamatan}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                        {sch.totalStudents.toLocaleString('id-ID')} Siswa
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mosques & Religious Teachers Institutional Table */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3">
              <h2 className="text-sm font-extrabold text-slate-900">
                Masjid / DKM Titik Pembinaan
              </h2>
              <div className="space-y-2.5">
                {mosques.map(m => (
                  <div key={m.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                    <div>
                      <p className="font-bold text-slate-900">{m.name}</p>
                      <p className="text-[11px] text-slate-500">{m.kecamatan} &middot; {m.dkmLeader}</p>
                    </div>
                    <span className="font-bold text-blue-700">{m.activeStudentsCount} Siswa Aktif</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3">
              <h2 className="text-sm font-extrabold text-slate-900">
                Koordinator Guru Agama Sekolah
              </h2>
              <div className="space-y-2.5">
                {teachers.map(t => (
                  <div key={t.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                    <div>
                      <p className="font-bold text-slate-900">{t.name}</p>
                      <p className="text-[11px] text-slate-500">{t.schoolName} &middot; {t.subject}</p>
                    </div>
                    <span className="text-[11px] text-purple-800 font-bold">Aktif</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 3: WILAYAH ==================== */}
      {activeTab === 'wilayah' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {cityMetrics.areas.map(area => (
            <div
              key={area.kecamatan}
              className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-700" />
                  <h3 className="text-base font-extrabold text-slate-900">{area.kecamatan}</h3>
                </div>
                <span className="font-black text-[#0d5435] text-sm">
                  {area.participationRate}%
                </span>
              </div>

              <div className="space-y-2 text-slate-600">
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span>Siswa Terdaftar</span>
                  <strong className="text-slate-900">{area.students.toLocaleString('id-ID')}</strong>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span>Masjid / DKM Aktif</span>
                  <strong className="text-slate-900">{area.mosques} Masjid</strong>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span>Sekolah Terintegrasi</span>
                  <strong className="text-slate-900">{area.schools} Sekolah</strong>
                </div>
              </div>

              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-600 rounded-full"
                  style={{ width: `${area.participationRate}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ==================== TAB 4: EKOSISTEM ==================== */}
      {activeTab === 'ekosistem' && (
        <div className="space-y-6 text-xs">
          {/* Gerakan Cimahi Pintar 5.000 Sustainability */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold uppercase text-emerald-800">
                  Mekanisme Keberlanjutan
                </span>
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                  {cityMetrics.sustainability.programName}
                </h2>
                <p className="text-slate-600 mt-0.5">
                  {cityMetrics.sustainability.description}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsGerakan5000InfoOpen(true)}
                className="px-4 py-2 bg-emerald-700 text-white font-bold rounded-xl shrink-0 self-start sm:self-auto flex items-center gap-1.5 cursor-pointer"
              >
                <HeartHandshake className="w-4 h-4" />
                <span>Detail Transparansi</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Partisipasi Terkumpul
                </span>
                <span className="text-lg font-black text-[#0d5435]">
                  Rp {cityMetrics.sustainability.fundsCollected.toLocaleString('id-ID')}
                </span>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Jumlah Partisipan
                </span>
                <span className="text-lg font-black text-blue-800">
                  {cityMetrics.sustainability.totalContributors.toLocaleString('id-ID')} Warga
                </span>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Mitra Pengelola
                </span>
                <span className="text-sm font-extrabold text-slate-900 block mt-0.5">
                  BAZNAS Kota Cimahi
                </span>
              </div>
            </div>
          </div>

          {/* Strategic Partners */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3">
            <h2 className="text-sm font-extrabold text-slate-900">
              Mitra Kolaborasi Lima Simpul Ekosistem
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {partners.map(p => (
                <div key={p.name} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-[10px] font-bold text-emerald-800 uppercase">{p.badge}</span>
                  <h3 className="font-bold text-slate-900">{p.name}</h3>
                  <p className="text-[11px] text-slate-500 leading-relaxed">{p.role}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 5: PROFIL ==================== */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 space-y-5 text-xs">
          <div className="flex items-center gap-4">
            <img
              src={currentUser?.avatar}
              alt={currentUser?.name}
              className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
            />
            <div>
              <h2 className="text-lg font-extrabold text-slate-900">{currentUser?.name}</h2>
              <p className="text-slate-500">{currentUser?.emailOrPhone}</p>
              <p className="text-slate-500">{currentUser?.entityName}</p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
            <button
              type="button"
              onClick={resetDemoData}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset Data Demo ke Awal</span>
            </button>

            <button
              type="button"
              onClick={logout}
              className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl border border-rose-200 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar / Ganti Akun</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
