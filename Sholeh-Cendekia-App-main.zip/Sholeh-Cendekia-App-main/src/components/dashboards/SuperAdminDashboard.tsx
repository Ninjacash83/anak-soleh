import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole, LearningMaterial, CarouselSlide, ActivityCategory } from '../../types';
import { RealtimeActivityStream } from '../stream/RealtimeActivityStream';
import {
  Sliders,
  Sparkles,
  BookOpen,
  CalendarCheck,
  HeartHandshake,
  Users,
  Building2,
  GraduationCap,
  Save,
  Plus,
  Trash2,
  Edit,
  CheckCircle2,
  RefreshCw,
  Image,
  ShieldAlert,
  Globe,
  Lock,
  Mail,
  Phone,
  QrCode,
  CreditCard
} from 'lucide-react';

export const SuperAdminDashboard: React.FC = () => {
  const {
    appSettings,
    updateAppSettings,
    carouselSlides,
    updateCarouselSlide,
    addCarouselSlide,
    deleteCarouselSlide,
    learningMaterials,
    updateLearningMaterial,
    addLearningMaterial,
    deleteLearningMaterial,
    pillarsConfig,
    updatePillarConfig,
    gerakan5000Config,
    updateGerakan5000Config,
    users,
    updateUser,
    addUser,
    deleteUser,
    schools,
    updateSchool,
    addSchool,
    deleteSchool,
    mosques,
    updateMosque,
    addMosque,
    deleteMosque,
    resetDemoData
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<
    'branding' | 'website' | 'carousel' | 'lks' | 'pillars' | 'gerakan5000' | 'users' | 'master'
  >('branding');

  const [savedSuccess, setSavedSuccess] = useState('');

  // Form states for Branding
  const [brandingForm, setBrandingForm] = useState(appSettings);

  // Form states for Carousel slide editing
  const [editingSlide, setEditingSlide] = useState<CarouselSlide | null>(null);

  // Form states for LKS editing
  const [editingMaterial, setEditingMaterial] = useState<LearningMaterial | null>(null);
  const [newMaterialModal, setNewMaterialModal] = useState(false);

  // Form states for User editing
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [newUserModal, setNewUserModal] = useState(false);

  // Form states for School & Mosque
  const [newSchoolName, setNewSchoolName] = useState('');
  const [newSchoolLevel, setNewSchoolLevel] = useState<'SD' | 'SMP' | 'SMA'>('SD');
  const [newSchoolKecamatan, setNewSchoolKecamatan] = useState<'Cimahi Utara' | 'Cimahi Tengah' | 'Cimahi Selatan'>('Cimahi Tengah');
  const [newMosqueName, setNewMosqueName] = useState('');
  const [newMosqueLeader, setNewMosqueLeader] = useState('');
  const [newMosqueKecamatan, setNewMosqueKecamatan] = useState<'Cimahi Utara' | 'Cimahi Tengah' | 'Cimahi Selatan'>('Cimahi Tengah');

  const showNotification = (msg: string) => {
    setSavedSuccess(msg);
    setTimeout(() => setSavedSuccess(''), 3000);
  };

  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    updateAppSettings(brandingForm);
    showNotification('Pengaturan Identitas & Logo Aplikasi berhasil disimpan!');
  };

  const handleSaveSlide = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSlide) return;
    updateCarouselSlide(editingSlide.id, editingSlide);
    setEditingSlide(null);
    showNotification('Slide Carousel berhasil diperbarui!');
  };

  const handleSaveMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMaterial) return;
    updateLearningMaterial(editingMaterial.id, editingMaterial);
    setEditingMaterial(null);
    showNotification('Materi & Soal LKS berhasil diperbarui!');
  };

  const handleCreateNewMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMaterial) return;
    addLearningMaterial(editingMaterial);
    setNewMaterialModal(false);
    setEditingMaterial(null);
    showNotification('Materi LKS baru berhasil ditambahkan!');
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    updateUser(editingUser.id, editingUser);
    setEditingUser(null);
    showNotification('Data pengguna berhasil diperbarui!');
  };

  const handleCreateNewUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    addUser(editingUser);
    setNewUserModal(false);
    setEditingUser(null);
    showNotification('Pengguna baru berhasil didaftarkan!');
  };

  const handleAddSchool = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSchoolName.trim()) return;
    addSchool({
      name: newSchoolName.trim(),
      level: newSchoolLevel,
      kecamatan: newSchoolKecamatan,
      address: `Jl. Raya ${newSchoolName.trim()}, Cimahi`,
      totalStudents: 350
    });
    setNewSchoolName('');
    showNotification('Sekolah binaan baru berhasil ditambahkan!');
  };

  const handleAddMosque = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMosqueName.trim()) return;
    addMosque({
      name: newMosqueName.trim(),
      kecamatan: newMosqueKecamatan,
      address: `Jl. Pemukiman ${newMosqueName.trim()}, Cimahi`,
      dkmLeader: newMosqueLeader.trim() || 'Ustadz DKM Binaan',
      activeStudentsCount: 65
    });
    setNewMosqueName('');
    setNewMosqueLeader('');
    showNotification('Masjid DKM binaan baru berhasil ditambahkan!');
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 text-slate-900">
      {/* Top Banner Super Admin */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-teal-950 rounded-3xl p-5 sm:p-7 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4 border border-emerald-900/50">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider">
            <Sliders className="w-3.5 h-3.5" />
            <span>Pusat Kendali Super Admin (CMS)</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight">
            Manajemen Konten, Menu, Logo &amp; Pengaturan Aplikasi
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100 max-w-2xl leading-relaxed">
            Kelola identitas merek, slide carousel, modul LKS, pilar kebiasaan, pengaturan Gerakan 5.000, serta hak akses pengguna di seluruh ekosistem Cimahi.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              if (window.confirm('Reset seluruh data aplikasi ke pengaturan bawaan awal?')) {
                resetDemoData();
                showNotification('Data berhasil di-reset ke bawaan awal.');
              }
            }}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold border border-white/20 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Data Awal</span>
          </button>
        </div>
      </div>

      {/* Save Notification Toast */}
      {savedSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-900 font-bold text-xs flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>{savedSuccess}</span>
        </div>
      )}

      {/* REAL-TIME ACTIVITY STREAM MONITORING */}
      <RealtimeActivityStream
        compact
        maxItems={5}
        title="Monitoring Real-Time System Stream &amp; Pencapaian Kota"
      />

      {/* Super Admin Sub-Tabs */}
      <div className="bg-white rounded-2xl p-2 border border-slate-200 shadow-2xs flex items-center gap-1.5 overflow-x-auto text-xs font-extrabold">
        {[
          { id: 'branding', label: '1. Logo & Identitas', icon: Sparkles },
          { id: 'website', label: '2. Konten Website Publik', icon: Globe },
          { id: 'carousel', label: '3. Slide Carousel', icon: Image },
          { id: 'lks', label: '4. Modul & LKS', icon: BookOpen },
          { id: 'pillars', label: '5. 4 Pilar Program', icon: CalendarCheck },
          { id: 'gerakan5000', label: '6. Gerakan 5.000', icon: HeartHandshake },
          { id: 'users', label: '7. Akun Pengguna', icon: Users },
          { id: 'master', label: '8. Sekolah & Masjid', icon: Building2 }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-3 py-2 rounded-xl flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-emerald-800 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ================= SUBTAB 1: BRANDING & IDENTITAS ================= */}
      {activeSubTab === 'branding' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base sm:text-lg font-black text-slate-900">
              Pengaturan Identitas Aplikasi &amp; Teks Logo
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Ubah nama platform, teks inisial logo, tagline kota, dan kontak pengelola resmi.
            </p>
          </div>

          <form onSubmit={handleSaveBranding} className="space-y-6 max-w-3xl">
            {/* Logo Image & Mobile Icon Selector */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                    Logo Utama Platform &amp; Ikon Aplikasi HP (PWA)
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Gambar logo ini akan digunakan di header, login, dan ikon otomatis saat dipasang di Home HP.
                  </p>
                </div>
                <div className="w-12 h-12 rounded-2xl overflow-hidden border-2 border-emerald-600/40 bg-emerald-950 shadow-md shrink-0 p-0.5">
                  <img
                    src={brandingForm.logoImageUrl || '/pwa-512x512.png'}
                    alt="Logo Preview"
                    className="w-full h-full object-cover rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    URL Gambar Logo / Icon (Custom Upload)
                  </label>
                  <input
                    type="text"
                    value={brandingForm.logoImageUrl || ''}
                    onChange={e => setBrandingForm({ ...brandingForm, logoImageUrl: e.target.value })}
                    placeholder="/pwa-512x512.png atau https://..."
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Pilih Logo Bawaan (Preset)
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setBrandingForm({ ...brandingForm, logoImageUrl: '/pwa-512x512.png', logoText: 'SC' })}
                      className="px-3 py-2 rounded-xl bg-white hover:bg-emerald-50 border border-slate-300 hover:border-emerald-500 text-[11px] font-bold text-slate-800 flex items-center gap-1.5 cursor-pointer"
                    >
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                      <span>Default Masagi Green</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setBrandingForm({ ...brandingForm, logoImageUrl: '/app-logo.png', logoText: 'SC' })}
                      className="px-3 py-2 rounded-xl bg-white hover:bg-emerald-50 border border-slate-300 hover:border-emerald-500 text-[11px] font-bold text-slate-800 flex items-center gap-1.5 cursor-pointer"
                    >
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                      <span>Sholeh Cendekia</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Utama Aplikasi
                </label>
                <input
                  type="text"
                  value={brandingForm.appName}
                  onChange={e => setBrandingForm({ ...brandingForm, appName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Badge Wilayah / Kota
                </label>
                <input
                  type="text"
                  value={brandingForm.appBadge}
                  onChange={e => setBrandingForm({ ...brandingForm, appBadge: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Teks Inisial Logo (1-3 Huruf)
                </label>
                <input
                  type="text"
                  maxLength={3}
                  value={brandingForm.logoText}
                  onChange={e => setBrandingForm({ ...brandingForm, logoText: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Warna Aksen Utama (Hex Code)
                </label>
                <input
                  type="text"
                  value={brandingForm.primaryColor}
                  onChange={e => setBrandingForm({ ...brandingForm, primaryColor: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Tagline Utama Platform
              </label>
              <input
                type="text"
                value={brandingForm.appTagline}
                onChange={e => setBrandingForm({ ...brandingForm, appTagline: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Judul Hero Visi Program
              </label>
              <input
                type="text"
                value={brandingForm.visionTitle}
                onChange={e => setBrandingForm({ ...brandingForm, visionTitle: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Deskripsi Visi Program
              </label>
              <textarea
                rows={2}
                value={brandingForm.visionSubtitle}
                onChange={e => setBrandingForm({ ...brandingForm, visionSubtitle: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Email Kontak Pengelola
                </label>
                <input
                  type="email"
                  value={brandingForm.contactEmail}
                  onChange={e => setBrandingForm({ ...brandingForm, contactEmail: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Telepon / Hotline Pengelola
                </label>
                <input
                  type="text"
                  value={brandingForm.contactPhone}
                  onChange={e => setBrandingForm({ ...brandingForm, contactPhone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>
            </div>

            <div className="pt-3">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-md cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Perubahan Identitas</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ================= SUBTAB 2: KONTEN WEBSITE PUBLIK ================= */}
      {activeSubTab === 'website' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <Globe className="w-5 h-5 text-emerald-700" />
              <span>Manajemen Konten &amp; Teks Website Publik</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Kelola headline hero, slogan utama, deskripsi narasi, angka statistik capaian kota, serta mode halaman pembuka saat pengguna mengakses aplikasi dari HP/Desktop.
            </p>
          </div>

          <form onSubmit={handleSaveBranding} className="space-y-6 max-w-4xl">
            {/* 1. Pengaturan Mode Pembuka Aplikasi (Landing Page Routing) */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center gap-2 text-xs font-black text-slate-900">
                <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                <span>Mode Halaman Pembuka untuk Pengunjung Baru</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Tentukan halaman apa yang pertama kali dilihat saat seseorang membuka tautan aplikasi di HP / browser:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <label
                  className={`p-3.5 rounded-xl border cursor-pointer flex items-start gap-3 transition-all ${
                    (brandingForm.defaultLandingMode || 'public') === 'public'
                      ? 'bg-emerald-50/80 border-emerald-500 shadow-2xs'
                      : 'bg-white border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <input
                    type="radio"
                    name="defaultLandingMode"
                    value="public"
                    checked={(brandingForm.defaultLandingMode || 'public') === 'public'}
                    onChange={() => setBrandingForm({ ...brandingForm, defaultLandingMode: 'public' })}
                    className="mt-0.5 text-emerald-700 focus:ring-emerald-600"
                  />
                  <div>
                    <div className="text-xs font-black text-slate-900">1. Buka Website Publik (Rekomendasi)</div>
                    <div className="text-[11px] text-slate-500 leading-relaxed mt-0.5">
                      Pengunjung melihat visi gerakan, 4 pilar, carousel, modul LKS, dan info program sebelum login.
                    </div>
                  </div>
                </label>

                <label
                  className={`p-3.5 rounded-xl border cursor-pointer flex items-start gap-3 transition-all ${
                    brandingForm.defaultLandingMode === 'login'
                      ? 'bg-emerald-50/80 border-emerald-500 shadow-2xs'
                      : 'bg-white border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <input
                    type="radio"
                    name="defaultLandingMode"
                    value="login"
                    checked={brandingForm.defaultLandingMode === 'login'}
                    onChange={() => setBrandingForm({ ...brandingForm, defaultLandingMode: 'login' })}
                    className="mt-0.5 text-emerald-700 focus:ring-emerald-600"
                  />
                  <div>
                    <div className="text-xs font-black text-slate-900">2. Langsung Halaman Login</div>
                    <div className="text-[11px] text-slate-500 leading-relaxed mt-0.5">
                      Pengunjung langsung disajikan form masuk peran/dashboard (tersedia tombol cepat menuju website).
                    </div>
                  </div>
                </label>
              </div>
            </div>

            {/* 2. Hero Section Website */}
            <div className="space-y-4">
              <h3 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-2">
                A. Bagian Utama Hero (Beranda Website)
              </h3>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kicker / Kategori Atas Hero
                </label>
                <input
                  type="text"
                  value={brandingForm.heroKicker || ''}
                  onChange={e => setBrandingForm({ ...brandingForm, heroKicker: e.target.value })}
                  placeholder="Gerakan Pembinaan Karakter Anak Kota Cimahi"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Headline Utama Hero
                </label>
                <input
                  type="text"
                  value={brandingForm.heroHeadline || ''}
                  onChange={e => setBrandingForm({ ...brandingForm, heroHeadline: e.target.value })}
                  placeholder="Setiap Orang Tua Mendambakan Anak Sholeh & Cendekia"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Slogan / Kutipan Emosional
                  </label>
                  <input
                    type="text"
                    value={brandingForm.heroSubquote || ''}
                    onChange={e => setBrandingForm({ ...brandingForm, heroSubquote: e.target.value })}
                    placeholder="“Me-Ramadhan-kan 11 Bulan Lainnya”"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 italic font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Teks Tombol Aksi CTA
                  </label>
                  <input
                    type="text"
                    value={brandingForm.heroButtonText || ''}
                    onChange={e => setBrandingForm({ ...brandingForm, heroButtonText: e.target.value })}
                    placeholder="Masuk ke Platform Ekosistem"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Deskripsi Narasi Program di Hero
                </label>
                <textarea
                  rows={3}
                  value={brandingForm.heroDescription || ''}
                  onChange={e => setBrandingForm({ ...brandingForm, heroDescription: e.target.value })}
                  placeholder="Menjaga konsistensi sholat Subuh berjamaah, mengaji ba’da Maghrib..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 leading-relaxed"
                />
              </div>
            </div>

            {/* 3. Statistik Capaian Kota Cimahi */}
            <div className="space-y-4">
              <h3 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-2">
                B. Angka Capaian &amp; Statistik Publik Kota
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    1. Siswa Terhubung
                  </label>
                  <input
                    type="text"
                    value={brandingForm.statStudentsCount || ''}
                    onChange={e => setBrandingForm({ ...brandingForm, statStudentsCount: e.target.value })}
                    placeholder="1.240+"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-black text-center"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    2. Masjid DKM Aktif
                  </label>
                  <input
                    type="text"
                    value={brandingForm.statMosquesCount || ''}
                    onChange={e => setBrandingForm({ ...brandingForm, statMosquesCount: e.target.value })}
                    placeholder="48"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-black text-center"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    3. Sekolah Terpadu
                  </label>
                  <input
                    type="text"
                    value={brandingForm.statSchoolsCount || ''}
                    onChange={e => setBrandingForm({ ...brandingForm, statSchoolsCount: e.target.value })}
                    placeholder="24"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-black text-center"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    4. Tingkat Verifikasi
                  </label>
                  <input
                    type="text"
                    value={brandingForm.statVerificationRate || ''}
                    onChange={e => setBrandingForm({ ...brandingForm, statVerificationRate: e.target.value })}
                    placeholder="92%"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-emerald-800 font-black text-center"
                  />
                </div>
              </div>
            </div>

            {/* 4. Pesan Keberlanjutan Gerakan 5.000 di Website */}
            <div className="space-y-4">
              <h3 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-2">
                C. Pesan Keberlanjutan &amp; Gotong Royong Rp5.000
              </h3>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Headline Gerakan Keberlanjutan
                </label>
                <input
                  type="text"
                  value={brandingForm.gerakan5000Headline || ''}
                  onChange={e => setBrandingForm({ ...brandingForm, gerakan5000Headline: e.target.value })}
                  placeholder="Partisipasi masyarakat untuk mendukung keberlanjutan ekosistem."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Deskripsi Narasi Gotong Royong
                </label>
                <textarea
                  rows={2}
                  value={brandingForm.gerakan5000Description || ''}
                  onChange={e => setBrandingForm({ ...brandingForm, gerakan5000Description: e.target.value })}
                  placeholder="Gotong royong sukarela Rp5.000 warga Kota Cimahi..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs text-slate-900 leading-relaxed"
                />
              </div>
            </div>

            <div className="pt-3 flex items-center justify-between border-t border-slate-100">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-md cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Konten Website Publik</span>
              </button>

              <span className="text-[11px] text-slate-500 italic">
                *Perubahan langsung tampil di halaman depan website publik.
              </span>
            </div>
          </form>
        </div>
      )}

      {/* ================= SUBTAB 2: CAROUSEL SLIDES ================= */}
      {activeSubTab === 'carousel' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                Manajemen Slide Banner Carousel
              </h2>
              <p className="text-xs text-slate-500">
                Ubah gambar ilustrasi, teks headline, isi pesan, dan link tombol aksi setiap slide.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {carouselSlides.map(slide => (
              <div
                key={slide.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3.5">
                  <img
                    src={slide.imageUrl}
                    alt={slide.headline}
                    className="w-20 h-14 rounded-xl object-cover border border-slate-300 shrink-0"
                  />
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {slide.kicker}
                    </span>
                    <h3 className="font-extrabold text-sm text-slate-900 mt-0.5">{slide.headline}</h3>
                    <p className="text-xs text-slate-600 line-clamp-1">{slide.content}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end md:self-auto">
                  <button
                    onClick={() => setEditingSlide(slide)}
                    className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Edit className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Edit Slide</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Edit Slide Modal */}
          {editingSlide && (
            <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
              <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-xs sm:text-sm">
                <h3 className="font-black text-base text-slate-900">
                  Edit Slide Carousel: {editingSlide.kicker}
                </h3>
                <form onSubmit={handleSaveSlide} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Kicker / Kategori Atas
                    </label>
                    <input
                      type="text"
                      value={editingSlide.kicker}
                      onChange={e => setEditingSlide({ ...editingSlide, kicker: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Headline Utama
                    </label>
                    <input
                      type="text"
                      value={editingSlide.headline}
                      onChange={e => setEditingSlide({ ...editingSlide, headline: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Isi Ringkasan Konten
                    </label>
                    <textarea
                      rows={2}
                      value={editingSlide.content}
                      onChange={e => setEditingSlide({ ...editingSlide, content: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Label Tombol Aksi (CTA)
                    </label>
                    <input
                      type="text"
                      value={editingSlide.ctaLabel}
                      onChange={e => setEditingSlide({ ...editingSlide, ctaLabel: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                      required
                    />
                  </div>

                  <div className="pt-3 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingSlide(null)}
                      className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-emerald-800 text-white font-black text-xs flex items-center gap-1.5 shadow-md"
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Slide</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= SUBTAB 3: MODUL & LKS ================= */}
      {activeSubTab === 'lks' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                Kelola Modul &amp; LKS Pembelajaran
              </h2>
              <p className="text-xs text-slate-500">
                Tambah materi LKS baru, ubah soal pilihan ganda, checklist ibadah, atau unduhan PDF.
              </p>
            </div>

            <button
              onClick={() => {
                setEditingMaterial({
                  id: '',
                  title: '',
                  type: 'lks',
                  jenjang: 'SD',
                  kelas: 'Kelas 5',
                  subject: 'PAI & Karakter',
                  tema: 'Amalan Sholeh',
                  category: 'PAI',
                  estimatedTime: '20 Menit',
                  durationOrPages: '4 Halaman',
                  description: '',
                  source: 'Kurikulum Karakter Sholeh Cendekia',
                  thumbnail: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=400&auto=format&fit=crop&q=80',
                  digitalAvailable: true,
                  pdfAvailable: true,
                  summaryContent: '',
                  checklistItems: ['Melaksanakan sholat tepat waktu', 'Membantu orang tua di rumah']
                });
                setNewMaterialModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Modul LKS Baru</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {learningMaterials.map(mat => (
              <div
                key={mat.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-black text-[10px]">
                      {mat.jenjang} &bull; {mat.kelas}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-bold text-[10px]">
                      {mat.subject}
                    </span>
                  </div>
                  <h3 className="font-extrabold text-sm text-slate-900">{mat.title}</h3>
                  <p className="text-xs text-slate-600 line-clamp-2">{mat.description}</p>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 font-medium">
                    {mat.mcQuestions?.length || 0} Soal PG &bull; {mat.checklistItems?.length || 0} Checklist
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setEditingMaterial(mat)}
                      className="p-1.5 rounded-lg bg-white border border-slate-300 text-emerald-800 hover:bg-slate-100 text-xs font-bold flex items-center gap-1"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Hapus materi "${mat.title}"?`)) {
                          deleteLearningMaterial(mat.id);
                          showNotification('Materi berhasil dihapus.');
                        }
                      }}
                      className="p-1.5 rounded-lg bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-bold flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Edit/Create Material Modal */}
          {(editingMaterial && !newMaterialModal) && (
            <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
              <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-xs sm:text-sm">
                <h3 className="font-black text-base text-slate-900">
                  Edit Materi LKS: {editingMaterial.title}
                </h3>
                <form onSubmit={handleSaveMaterial} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Judul Modul LKS
                    </label>
                    <input
                      type="text"
                      value={editingMaterial.title}
                      onChange={e => setEditingMaterial({ ...editingMaterial, title: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Jenjang</label>
                      <select
                        value={editingMaterial.jenjang}
                        onChange={e => setEditingMaterial({ ...editingMaterial, jenjang: e.target.value as any })}
                        className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                      >
                        <option value="SD">SD</option>
                        <option value="SMP">SMP</option>
                        <option value="SMA">SMA</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Kelas</label>
                      <input
                        type="text"
                        value={editingMaterial.kelas}
                        onChange={e => setEditingMaterial({ ...editingMaterial, kelas: e.target.value })}
                        className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Mata Pelajaran</label>
                      <input
                        type="text"
                        value={editingMaterial.subject}
                        onChange={e => setEditingMaterial({ ...editingMaterial, subject: e.target.value })}
                        className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Deskripsi Singkat</label>
                    <textarea
                      rows={2}
                      value={editingMaterial.description}
                      onChange={e => setEditingMaterial({ ...editingMaterial, description: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Ringkasan Materi Pelajaran</label>
                    <textarea
                      rows={3}
                      value={editingMaterial.summaryContent || ''}
                      onChange={e => setEditingMaterial({ ...editingMaterial, summaryContent: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>

                  <div className="pt-3 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingMaterial(null)}
                      className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-emerald-800 text-white font-black text-xs flex items-center gap-1.5 shadow-md"
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Materi</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* New Material Modal */}
          {newMaterialModal && editingMaterial && (
            <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
              <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-xs sm:text-sm">
                <h3 className="font-black text-base text-slate-900">
                  Tambah Modul LKS Baru
                </h3>
                <form onSubmit={handleCreateNewMaterial} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Judul Modul LKS
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Modul Adab Menuntut Ilmu &amp; Sholat Dhuha"
                      value={editingMaterial.title}
                      onChange={e => setEditingMaterial({ ...editingMaterial, title: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Jenjang</label>
                      <select
                        value={editingMaterial.jenjang}
                        onChange={e => setEditingMaterial({ ...editingMaterial, jenjang: e.target.value as any })}
                        className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                      >
                        <option value="SD">SD</option>
                        <option value="SMP">SMP</option>
                        <option value="SMA">SMA</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Kelas</label>
                      <input
                        type="text"
                        value={editingMaterial.kelas}
                        onChange={e => setEditingMaterial({ ...editingMaterial, kelas: e.target.value })}
                        className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Mata Pelajaran</label>
                      <input
                        type="text"
                        value={editingMaterial.subject}
                        onChange={e => setEditingMaterial({ ...editingMaterial, subject: e.target.value })}
                        className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Deskripsi Singkat</label>
                    <textarea
                      rows={2}
                      value={editingMaterial.description}
                      onChange={e => setEditingMaterial({ ...editingMaterial, description: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                      required
                    />
                  </div>

                  <div className="pt-3 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setNewMaterialModal(false);
                        setEditingMaterial(null);
                      }}
                      className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-emerald-800 text-white font-black text-xs flex items-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Buat Materi LKS</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= SUBTAB 4: 4 PILAR PROGRAM ================= */}
      {activeSubTab === 'pillars' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base sm:text-lg font-black text-slate-900">
              Konfigurasi 4 Pilar Pembiasaan Karakter
            </h2>
            <p className="text-xs text-slate-500">
              Atur jadwal waktu acuan, judul amalan standar, dan poin karakter per pilar.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {pillarsConfig.map(p => (
              <div key={p.category} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-sm text-slate-900">{p.title}</h3>
                  <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                    {p.points} Poin
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <label className="font-bold text-slate-700 block mb-0.5">Jadwal Waktu</label>
                    <input
                      type="text"
                      value={p.schedule}
                      onChange={e => updatePillarConfig(p.category, { schedule: e.target.value })}
                      className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-0.5">Judul Amalan Standar</label>
                    <input
                      type="text"
                      value={p.defaultTitle}
                      onChange={e => updatePillarConfig(p.category, { defaultTitle: e.target.value })}
                      className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-0.5">Deskripsi Panduan</label>
                    <textarea
                      rows={2}
                      value={p.description}
                      onChange={e => updatePillarConfig(p.category, { description: e.target.value })}
                      className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => showNotification(`Pengaturan pilar "${p.title}" disimpan!`)}
                  className="w-full py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan Pilar</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= SUBTAB 5: GERAKAN 5.000 & METODE PEMBAYARAN ================= */}
      {activeSubTab === 'gerakan5000' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base sm:text-lg font-black text-slate-900">
              Konfigurasi Pembayaran Donasi, Transfer Bank &amp; QRIS
            </h2>
            <p className="text-xs text-slate-500">
              Atur rekening penampung transfer bank (BSI &amp; BJB Syariah), NMID QRIS, nominal donasi, dan kalimat ajakan (trigger) untuk Siswa &amp; Orang Tua.
            </p>
          </div>

          <form
            onSubmit={e => {
              e.preventDefault();
              showNotification('Pengaturan Pembayaran & Gerakan 5.000 berhasil disimpan!');
            }}
            className="space-y-6 max-w-3xl"
          >
            {/* Section 1: Nominal & Minimal Donasi */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <h3 className="font-extrabold text-xs text-slate-900 uppercase tracking-wider">
                1. Pengaturan Nominal Donasi
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nominal Standar Gerakan (Rp)
                  </label>
                  <input
                    type="number"
                    value={gerakan5000Config.nominal}
                    onChange={e => updateGerakan5000Config({ nominal: parseInt(e.target.value) || 5000 })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nominal Minimal Infak Pelajar (Rp)
                  </label>
                  <input
                    type="number"
                    value={gerakan5000Config.minNominal || 2000}
                    onChange={e => updateGerakan5000Config({ minNominal: parseInt(e.target.value) || 2000 })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Section 2: QRIS Digital */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <h3 className="font-extrabold text-xs text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <QrCode className="w-4 h-4 text-emerald-700" />
                2. Konfigurasi QRIS (Semua E-Wallet &amp; M-Banking)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    NMID QRIS
                  </label>
                  <input
                    type="text"
                    value={gerakan5000Config.qrisNmid}
                    onChange={e => updateGerakan5000Config({ qrisNmid: e.target.value })}
                    placeholder="Contoh: ID102026CIMAHIPINTAR"
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Merchant QRIS
                  </label>
                  <input
                    type="text"
                    value={gerakan5000Config.qrisMerchantName || 'SHOLEH CENDEKIA CIMAHI - BAZNAS & DMI'}
                    onChange={e => updateGerakan5000Config({ qrisMerchantName: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  URL Gambar QRIS (Opsional untuk tampilan QR kustom)
                </label>
                <input
                  type="text"
                  value={gerakan5000Config.qrisImageUrl || ''}
                  onChange={e => updateGerakan5000Config({ qrisImageUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs bg-white"
                />
              </div>
            </div>

            {/* Section 3: Transfer Bank 1 & Bank 2 */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <h3 className="font-extrabold text-xs text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-emerald-700" />
                3. Rekening Transfer Bank Resmi
              </h3>

              {/* Bank 1 */}
              <div className="p-3.5 bg-white rounded-xl border border-slate-200 space-y-3">
                <span className="font-bold text-xs text-emerald-900 block">Rekening Utama (Bank 1)</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Nama Bank</label>
                    <input
                      type="text"
                      value={gerakan5000Config.bankName}
                      onChange={e => updateGerakan5000Config({ bankName: e.target.value })}
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Nomor Rekening</label>
                    <input
                      type="text"
                      value={gerakan5000Config.bankAccountNumber || gerakan5000Config.vaNumber}
                      onChange={e =>
                        updateGerakan5000Config({
                          bankAccountNumber: e.target.value,
                          vaNumber: e.target.value
                        })
                      }
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs font-bold font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Atas Nama (A.N.)</label>
                    <input
                      type="text"
                      value={gerakan5000Config.accountHolder}
                      onChange={e => updateGerakan5000Config({ accountHolder: e.target.value })}
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Bank 2 */}
              <div className="p-3.5 bg-white rounded-xl border border-slate-200 space-y-3">
                <span className="font-bold text-xs text-teal-900 block">Rekening Alternatif (Bank 2)</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Nama Bank</label>
                    <input
                      type="text"
                      value={gerakan5000Config.secondaryBankName || 'Bank BJB Syariah'}
                      onChange={e => updateGerakan5000Config({ secondaryBankName: e.target.value })}
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Nomor Rekening</label>
                    <input
                      type="text"
                      value={gerakan5000Config.secondaryBankAccountNumber || '5220 2000 5000'}
                      onChange={e => updateGerakan5000Config({ secondaryBankAccountNumber: e.target.value })}
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs font-bold font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Atas Nama (A.N.)</label>
                    <input
                      type="text"
                      value={gerakan5000Config.secondaryBankAccountHolder || 'GERAKAN CIMAHI PINTAR 5000'}
                      onChange={e => updateGerakan5000Config({ secondaryBankAccountHolder: e.target.value })}
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs font-bold"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Section 4: Kalimat Ajakan & Trigger Orang Tua / Siswa */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <h3 className="font-extrabold text-xs text-slate-900 uppercase tracking-wider">
                4. Teks Trigger Ajakan Donasi (Orang Tua &amp; Siswa)
              </h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Judul Pemicu Orang Tua
                  </label>
                  <input
                    type="text"
                    value={gerakan5000Config.ortuTriggerHeadline || 'Investasi Akhlak & Kebiasaan Mulia untuk Buah Hati'}
                    onChange={e => updateGerakan5000Config({ ortuTriggerHeadline: e.target.value })}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Pesan Pemicu Orang Tua
                  </label>
                  <textarea
                    rows={2}
                    value={gerakan5000Config.ortuTriggerMessage || ''}
                    onChange={e => updateGerakan5000Config({ ortuTriggerMessage: e.target.value })}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Judul Pemicu Siswa (Sedekah Subuh)
                  </label>
                  <input
                    type="text"
                    value={gerakan5000Config.siswaTriggerHeadline || 'Sedekah Subuh & Berbagi Kebaikan Hari Ini'}
                    onChange={e => updateGerakan5000Config({ siswaTriggerHeadline: e.target.value })}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Instruksi / Transparansi Penyaluran Dana
                  </label>
                  <textarea
                    rows={2}
                    value={gerakan5000Config.donationInstruction}
                    onChange={e => updateGerakan5000Config({ donationInstruction: e.target.value })}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Total Recap */}
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1 text-xs">
              <span className="font-extrabold text-emerald-900 block">Status Rekapitulasi Partisipasi Warga &amp; Santri:</span>
              <p className="text-emerald-800">
                Total Partisipan: <strong>{gerakan5000Config.totalDonors.toLocaleString('id-ID')} Donatur</strong> &bull; Total Dana Terkumpul: <strong>Rp {gerakan5000Config.collectedFunds.toLocaleString('id-ID')}</strong>
              </p>
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-2 shadow-md cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Semua Pengaturan Pembayaran &amp; Gerakan 5.000</span>
            </button>
          </form>
        </div>
      )}

      {/* ================= SUBTAB 6: AKUN PENGGUNA ================= */}
      {activeSubTab === 'users' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                Manajemen Pengguna &amp; Hak Akses
              </h2>
              <p className="text-xs text-slate-500">
                Kelola daftar akun resmi, ubah peran, atur kata sandi, dan entitas terkait.
              </p>
            </div>

            <button
              onClick={() => {
                setEditingUser({
                  id: '',
                  name: '',
                  emailOrPhone: '',
                  password: 'password123',
                  role: 'siswa',
                  avatar: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=240&auto=format&fit=crop&q=80',
                  entityId: 'std-1',
                  entityName: 'SDN Cimahi 1',
                  title: 'Siswa Aktif'
                });
                setNewUserModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Daftarkan Pengguna Baru</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-y border-slate-200 text-slate-600 font-extrabold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-3">Pengguna</th>
                  <th className="py-3 px-3">Email / ID</th>
                  <th className="py-3 px-3">Peran Akses</th>
                  <th className="py-3 px-3">Entitas Terhubung</th>
                  <th className="py-3 px-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 flex items-center gap-2.5">
                      <img
                        src={u.avatar}
                        alt={u.name}
                        className="w-8 h-8 rounded-full object-cover border border-slate-300 shrink-0"
                      />
                      <div>
                        <p className="font-extrabold text-slate-900">{u.name}</p>
                        <p className="text-[10px] text-slate-500">{u.title}</p>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-700">{u.emailOrPhone}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded font-black text-[10px] uppercase tracking-wider bg-slate-100 text-slate-800 border border-slate-200">
                        {u.role.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-600 font-medium">{u.entityName}</td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingUser(u)}
                          className="px-2 py-1 rounded bg-white border border-slate-300 text-emerald-800 hover:bg-slate-100 font-bold text-[11px]"
                        >
                          Edit
                        </button>
                        {u.role !== 'super_admin' && (
                          <button
                            onClick={() => {
                              if (window.confirm(`Hapus akun ${u.name}?`)) {
                                deleteUser(u.id);
                                showNotification('Akun berhasil dihapus.');
                              }
                            }}
                            className="px-2 py-1 rounded bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 font-bold text-[11px]"
                          >
                            Hapus
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Edit User Modal */}
          {editingUser && !newUserModal && (
            <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
              <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs sm:text-sm">
                <h3 className="font-black text-base text-slate-900">
                  Edit Pengguna: {editingUser.name}
                </h3>
                <form onSubmit={handleSaveUser} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Lengkap</label>
                    <input
                      type="text"
                      value={editingUser.name}
                      onChange={e => setEditingUser({ ...editingUser, name: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Email / ID Login</label>
                    <input
                      type="text"
                      value={editingUser.emailOrPhone}
                      onChange={e => setEditingUser({ ...editingUser, emailOrPhone: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Kata Sandi</label>
                    <input
                      type="text"
                      value={editingUser.password || 'password123'}
                      onChange={e => setEditingUser({ ...editingUser, password: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Peran Akses</label>
                    <select
                      value={editingUser.role}
                      onChange={e => setEditingUser({ ...editingUser, role: e.target.value as UserRole })}
                      className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                    >
                      <option value="siswa">Siswa / Santri</option>
                      <option value="orang_tua">Orang Tua / Wali</option>
                      <option value="dkm">DKM / Guru Mengaji</option>
                      <option value="guru_agama">Guru Agama (PAI)</option>
                      <option value="admin_pemkot">Pemkot Cimahi</option>
                      <option value="super_admin">Super Admin</option>
                    </select>
                  </div>

                  <div className="pt-3 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingUser(null)}
                      className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-emerald-800 text-white font-black text-xs flex items-center gap-1.5 shadow-md"
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Pengguna</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* New User Modal */}
          {newUserModal && editingUser && (
            <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
              <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs sm:text-sm">
                <h3 className="font-black text-base text-slate-900">
                  Daftarkan Pengguna Baru
                </h3>
                <form onSubmit={handleCreateNewUser} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Nama Lengkap</label>
                    <input
                      type="text"
                      placeholder="Nama pengguna baru"
                      value={editingUser.name}
                      onChange={e => setEditingUser({ ...editingUser, name: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Email / ID Login</label>
                    <input
                      type="text"
                      placeholder="user@example.com"
                      value={editingUser.emailOrPhone}
                      onChange={e => setEditingUser({ ...editingUser, emailOrPhone: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Kata Sandi</label>
                    <input
                      type="text"
                      value={editingUser.password}
                      onChange={e => setEditingUser({ ...editingUser, password: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Peran Akses</label>
                    <select
                      value={editingUser.role}
                      onChange={e => setEditingUser({ ...editingUser, role: e.target.value as UserRole })}
                      className="w-full p-2 rounded-xl border border-slate-300 text-xs font-bold"
                    >
                      <option value="siswa">Siswa / Santri</option>
                      <option value="orang_tua">Orang Tua / Wali</option>
                      <option value="dkm">DKM / Guru Mengaji</option>
                      <option value="guru_agama">Guru Agama (PAI)</option>
                      <option value="admin_pemkot">Pemkot Cimahi</option>
                      <option value="super_admin">Super Admin</option>
                    </select>
                  </div>

                  <div className="pt-3 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setNewUserModal(false);
                        setEditingUser(null);
                      }}
                      className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-emerald-800 text-white font-black text-xs flex items-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Buat Akun</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= SUBTAB 7: SEKOLAH & MASJID ================= */}
      {activeSubTab === 'master' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base sm:text-lg font-black text-slate-900">
              Master Data Sekolah &amp; DKM Masjid Kota Cimahi
            </h2>
            <p className="text-xs text-slate-500">
              Kelola daftar satuan pendidikan dan masjid binaan gerakan Maghrib Mengaji &amp; Subuh Berjamaah.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Sekolah */}
            <div className="space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-emerald-700" />
                <span>Daftar Sekolah Binaan ({schools.length})</span>
              </h3>

              <form onSubmit={handleAddSchool} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Nama Sekolah (misal: SDN Cimahi 5)"
                  value={newSchoolName}
                  onChange={e => setNewSchoolName(e.target.value)}
                  className="flex-1 p-2 rounded-xl border border-slate-300 text-xs"
                  required
                />
                <select
                  value={newSchoolLevel}
                  onChange={e => setNewSchoolLevel(e.target.value as any)}
                  className="p-2 rounded-xl border border-slate-300 text-xs font-bold"
                >
                  <option value="SD">SD</option>
                  <option value="SMP">SMP</option>
                  <option value="SMA">SMA</option>
                </select>
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-emerald-800 text-white font-bold text-xs rounded-xl hover:bg-emerald-700"
                >
                  Tambah
                </button>
              </form>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {schools.map(s => (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-slate-900">{s.name}</p>
                      <p className="text-[10px] text-slate-500">{s.kecamatan} &bull; {s.level}</p>
                    </div>
                    <button
                      onClick={() => {
                        if (window.confirm(`Hapus ${s.name}?`)) {
                          deleteSchool(s.id);
                          showNotification('Sekolah dihapus.');
                        }
                      }}
                      className="text-rose-600 hover:text-rose-800 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Masjid */}
            <div className="space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-teal-700" />
                <span>Daftar Masjid DKM Binaan ({mosques.length})</span>
              </h3>

              <form onSubmit={handleAddMosque} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Nama Masjid (misal: Masjid Al-Falah)"
                    value={newMosqueName}
                    onChange={e => setNewMosqueName(e.target.value)}
                    className="flex-1 p-2 rounded-xl border border-slate-300 text-xs"
                    required
                  />
                  <select
                    value={newMosqueKecamatan}
                    onChange={e => setNewMosqueKecamatan(e.target.value as any)}
                    className="p-2 rounded-xl border border-slate-300 text-xs font-bold"
                  >
                    <option value="Cimahi Utara">Utara</option>
                    <option value="Cimahi Tengah">Tengah</option>
                    <option value="Cimahi Selatan">Selatan</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Ketua DKM / Pembina Mengaji"
                    value={newMosqueLeader}
                    onChange={e => setNewMosqueLeader(e.target.value)}
                    className="flex-1 p-2 rounded-xl border border-slate-300 text-xs"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-teal-800 text-white font-bold text-xs rounded-xl hover:bg-teal-700"
                  >
                    Tambah Masjid
                  </button>
                </div>
              </form>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {mosques.map(m => (
                  <div
                    key={m.id}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-slate-900">{m.name}</p>
                      <p className="text-[10px] text-slate-500">{m.kecamatan} &bull; Ketua: {m.dkmLeader}</p>
                    </div>
                    <button
                      onClick={() => {
                        if (window.confirm(`Hapus ${m.name}?`)) {
                          deleteMosque(m.id);
                          showNotification('Masjid dihapus.');
                        }
                      }}
                      className="text-rose-600 hover:text-rose-800 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
