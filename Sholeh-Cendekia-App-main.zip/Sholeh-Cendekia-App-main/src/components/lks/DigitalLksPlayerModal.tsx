import React, { useState } from 'react';
import { LearningMaterial, LksSubmission } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  X,
  CheckCircle2,
  HelpCircle,
  FileCheck,
  Sparkles,
  Award,
  ArrowRight,
  RotateCcw
} from 'lucide-react';

interface DigitalLksPlayerModalProps {
  material: LearningMaterial | null;
  isOpen: boolean;
  onClose: () => void;
}

export const DigitalLksPlayerModal: React.FC<DigitalLksPlayerModalProps> = ({
  material,
  isOpen,
  onClose
}) => {
  const { currentStudent, submitDigitalLks, lksSubmissions } = useApp();

  const [selectedAnswers, setSelectedAnswers] = useState<{ [qId: string]: number }>({});
  const [shortAnswer, setShortAnswer] = useState('');
  const [checkedList, setCheckedList] = useState<boolean[]>(() =>
    material?.checklistItems ? new Array(material.checklistItems.length).fill(false) : []
  );
  const [submitted, setSubmitted] = useState(false);
  const [computedScore, setComputedScore] = useState<number | null>(null);

  if (!isOpen || !material) return null;

  const existingSubmission = lksSubmissions.find(
    s => s.materialId === material.id && s.studentId === currentStudent?.id
  );

  const mcQuestions = material.mcQuestions || [];
  const checklistItems = material.checklistItems || [];

  const handleOptionSelect = (qId: string, optIdx: number) => {
    setSelectedAnswers(prev => ({ ...prev, [qId]: optIdx }));
  };

  const handleChecklistToggle = (index: number) => {
    setCheckedList(prev => {
      const next = [...prev];
      next[index] = !next[index];
      return next;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentStudent) return;

    let score = 80;
    if (mcQuestions.length > 0) {
      let correct = 0;
      mcQuestions.forEach(q => {
        if (selectedAnswers[q.id] === q.correctIndex) {
          correct += 1;
        }
      });
      score = Math.round((correct / mcQuestions.length) * 100);
    }

    const submission: LksSubmission = {
      materialId: material.id,
      studentId: currentStudent.id,
      completedAt: new Date().toISOString(),
      score: score,
      shortAnswerText: shortAnswer,
      checkedItems: checkedList
    };

    submitDigitalLks(submission, material.title);
    setComputedScore(score);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-700 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-200 text-[10px] font-extrabold uppercase tracking-wider">
                Mode Digital HP
              </span>
              <span className="text-xs text-emerald-100 font-medium">
                {material.jenjang} • {material.kelas} • {material.subject}
              </span>
            </div>
            <h2 className="text-base sm:text-lg font-black mt-0.5">{material.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto p-5 sm:p-6 space-y-6 flex-1 text-slate-900 text-xs sm:text-sm">
          {submitted ? (
            /* Results Screen */
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
                <Award className="w-10 h-10" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xl font-black text-slate-900">
                  Alhamdulillah, LKS Selesai Dikerjakan!
                </h3>
                <p className="text-slate-600 max-w-sm mx-auto">
                  Jawaban kamu telah tersimpan ke portofolio siswa dan terhubung dengan penilaian Guru Agama & DKM.
                </p>
              </div>

              {computedScore !== null && (
                <div className="inline-block p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
                  <span className="text-xs font-bold text-emerald-800 block">NILAI DIGITAL</span>
                  <span className="text-4xl font-black text-emerald-700">{computedScore}</span>
                  <span className="text-xs text-emerald-600 block mt-0.5">/ 100 Poin</span>
                </div>
              )}

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
                <button
                  onClick={() => {
                    setSubmitted(false);
                  }}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-50 flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Ulangi Pengerjaan</span>
                </button>
                <button
                  onClick={onClose}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-2 shadow-md"
                >
                  <span>Tutup & Simpan</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            /* Form Player */
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Summary / Instruction */}
              {material.summaryContent && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 space-y-1.5">
                  <h4 className="font-extrabold flex items-center gap-1.5 text-xs text-amber-950 uppercase tracking-wider">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    Ringkasan Materi & Panduan
                  </h4>
                  <p className="text-xs leading-relaxed text-amber-900">{material.summaryContent}</p>
                </div>
              )}

              {/* Section 1: Multiple Choice */}
              {mcQuestions.length > 0 && (
                <div className="space-y-4">
                  <h3 className="font-black text-slate-900 text-sm sm:text-base border-b border-slate-100 pb-2 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-emerald-700" />
                    <span>Bagian A: Soal Pilihan Ganda ({mcQuestions.length} Soal)</span>
                  </h3>

                  <div className="space-y-4">
                    {mcQuestions.map((q, qIndex) => (
                      <div key={q.id} className="p-3.5 sm:p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
                        <p className="font-bold text-slate-900">
                          {qIndex + 1}. {q.question}
                        </p>
                        <div className="space-y-1.5">
                          {q.options.map((opt, optIdx) => {
                            const isSelected = selectedAnswers[q.id] === optIdx;
                            return (
                              <label
                                key={optIdx}
                                onClick={() => handleOptionSelect(q.id, optIdx)}
                                className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                                  isSelected
                                    ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold'
                                    : 'bg-white border-slate-200 hover:bg-slate-100 text-slate-800'
                                }`}
                              >
                                <input
                                  type="radio"
                                  name={`q-${q.id}`}
                                  checked={isSelected}
                                  onChange={() => handleOptionSelect(q.id, optIdx)}
                                  className="text-emerald-700 focus:ring-emerald-600"
                                />
                                <span>{opt}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Section 2: Checklist */}
              {checklistItems.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-black text-slate-900 text-sm sm:text-base border-b border-slate-100 pb-2 flex items-center gap-2">
                    <FileCheck className="w-4 h-4 text-teal-700" />
                    <span>Bagian B: Checklist Praktik Ibadah & Adab</span>
                  </h3>
                  <div className="space-y-2">
                    {checklistItems.map((item, idx) => (
                      <label
                        key={idx}
                        onClick={() => handleChecklistToggle(idx)}
                        className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 cursor-pointer transition-colors"
                      >
                        <input
                          type="checkbox"
                          checked={checkedList[idx] || false}
                          onChange={() => handleChecklistToggle(idx)}
                          className="mt-0.5 w-4 h-4 text-emerald-700 rounded focus:ring-emerald-600 cursor-pointer"
                        />
                        <span className="text-xs font-semibold text-slate-800">{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* Section 3: Short Answer Prompt */}
              {material.shortAnswerPrompt && (
                <div className="space-y-2">
                  <h3 className="font-black text-slate-900 text-sm sm:text-base border-b border-slate-100 pb-2 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-700" />
                    <span>Bagian C: Uraian & Refleksi Karakter</span>
                  </h3>
                  <label htmlFor="short-answer" className="block font-semibold text-slate-700 text-xs">
                    {material.shortAnswerPrompt}
                  </label>
                  <textarea
                    id="short-answer"
                    rows={3}
                    value={shortAnswer}
                    onChange={e => setShortAnswer(e.target.value)}
                    placeholder="Tuliskan jawaban atau refleksi kamu di sini..."
                    className="w-full p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none text-xs bg-slate-50 text-slate-900"
                  />
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 font-bold hover:bg-slate-100 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Kirim Jawaban LKS</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
