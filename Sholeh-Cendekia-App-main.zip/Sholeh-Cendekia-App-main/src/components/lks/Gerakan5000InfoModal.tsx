import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  HeartHandshake,
  ShieldCheck,
  Sparkles,
  BookOpen,
  Users,
  CheckCircle2,
  Building2,
  QrCode,
  CreditCard,
  Copy,
  Check,
  ArrowRight,
  Heart,
  HelpCircle,
  Smartphone
} from 'lucide-react';

interface Gerakan5000InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultNominal?: number;
  categoryNiat?: 'gerakan_5000' | 'sedekah_subuh' | 'lks_dhuafa';
}

export const Gerakan5000InfoModal: React.FC<Gerakan5000InfoModalProps> = ({
  isOpen,
  onClose,
  defaultNominal,
  categoryNiat = 'gerakan_5000'
}) => {
  const { gerakan5000Config, recordParticipation5000, currentUser } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'qris' | 'transfer'>('qris');
  const [selectedNominal, setSelectedNominal] = useState<number>(
    defaultNominal || gerakan5000Config.nominal
  );
  const [customNominal, setCustomNominal] = useState<string>('');
  const [isCustom, setIsCustom] = useState(false);
  const [donorName, setDonorName] = useState(currentUser?.name || '');
  const [donorPrayer, setDonorPrayer] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const [isPaymentStep, setIsPaymentStep] = useState(false);
  const [done, setDone] = useState(false);

  if (!isOpen) return null;

  const currentAmount = isCustom
    ? parseInt(customNominal.replace(/\D/g, ''), 10) || gerakan5000Config.minNominal
    : selectedNominal;

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleComplete = () => {
    recordParticipation5000(currentAmount, donorName || 'Hamba Allah', currentUser?.role);
    setDone(true);
  };

  const handleReset = () => {
    setIsPaymentStep(false);
    setDone(false);
    onClose();
  };

  const presetNominals = [
    { label: 'Rp2.000', value: 2000, desc: 'Infak Harian Santri' },
    { label: 'Rp5.000', value: 5000, desc: 'Gerakan 5.000 / Bulan' },
    { label: 'Rp10.000', value: 10000, desc: 'Dukungan Modul LKS' },
    { label: 'Rp20.000', value: 20000, desc: 'Apresiasi Guru Mengaji' },
    { label: 'Rp50.000', value: 50000, desc: 'Paket Karakter Berkelanjutan' }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-slate-900 my-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-800 to-emerald-900 px-5 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-sm shadow-sm">
              <HeartHandshake className="w-5 h-5 text-emerald-950" />
            </div>
            <div>
              <h3 className="font-black text-base leading-tight">
                Gerakan Cimahi Pintar 5.000 &amp; Sedekah
              </h3>
              <p className="text-[11px] text-emerald-200">
                Gotong Royong Pendidikan Karakter Siswa Kota Cimahi
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {!isPaymentStep && !done ? (
            <>
              {/* Motto / Impact Box */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200/80 space-y-2 text-center">
                <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white text-emerald-800 text-[10px] font-black uppercase tracking-wider border border-emerald-300 shadow-2xs">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  <span>Filosofi Gerakan Gotong Royong</span>
                </div>
                <p className="text-sm sm:text-base font-black text-emerald-950 leading-snug">
                  &ldquo;Rp5.000 dari kita, manfaatnya terus mengalir untuk mencerdaskan generasi sholeh dan guru ngaji se-Kota Cimahi.&rdquo;
                </p>
                <p className="text-[11px] text-slate-600 font-medium">
                  {gerakan5000Config.donationInstruction}
                </p>
              </div>

              {/* Pilih Nominal */}
              <div className="space-y-2">
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider">
                  Pilih Nominal Infak / Dukungan
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {presetNominals.map(p => (
                    <button
                      key={p.value}
                      type="button"
                      onClick={() => {
                        setSelectedNominal(p.value);
                        setIsCustom(false);
                      }}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        !isCustom && selectedNominal === p.value
                          ? 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                      }`}
                    >
                      <div className="font-black text-xs sm:text-sm">{p.label}</div>
                      <div
                        className={`text-[10px] truncate ${
                          !isCustom && selectedNominal === p.value
                            ? 'text-emerald-200'
                            : 'text-slate-500'
                        }`}
                      >
                        {p.desc}
                      </div>
                    </button>
                  ))}

                  {/* Custom Nominal Button */}
                  <button
                    type="button"
                    onClick={() => setIsCustom(true)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isCustom
                        ? 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                    }`}
                  >
                    <div className="font-black text-xs sm:text-sm">Nominal Lain</div>
                    <div
                      className={`text-[10px] ${
                        isCustom ? 'text-emerald-200' : 'text-slate-500'
                      }`}
                    >
                      Sesuai Keikhlasan
                    </div>
                  </button>
                </div>

                {isCustom && (
                  <div className="pt-1">
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-xs">
                        Rp
                      </span>
                      <input
                        type="number"
                        min={gerakan5000Config.minNominal}
                        step="1000"
                        value={customNominal}
                        onChange={e => setCustomNominal(e.target.value)}
                        placeholder={`Contoh: 15000 (Min. ${gerakan5000Config.minNominal.toLocaleString('id-ID')})`}
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 pl-10 text-xs sm:text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Data Donatur / Santri & Niat Doa */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Nama Hamba Allah / Siswa
                  </label>
                  <input
                    type="text"
                    value={donorName}
                    onChange={e => setDonorName(e.target.value)}
                    placeholder="Nama Anda atau Hamba Allah"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Doa / Harapan Kebaikan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={donorPrayer}
                    onChange={e => setDonorPrayer(e.target.value)}
                    placeholder="Semoga anak sholeh, berkah & istiqomah..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-medium"
                  />
                </div>
              </div>

              {/* Transparansi & Akuntabilitas Banner */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-[11px] text-slate-600">
                <div className="flex items-center justify-between font-bold text-slate-800 text-xs">
                  <span className="flex items-center gap-1 text-emerald-800">
                    <ShieldCheck className="w-4 h-4" />
                    Penyaluran Amanah &amp; Terpercaya
                  </span>
                  <span className="text-amber-700 font-extrabold">100% Bebas Potongan</span>
                </div>
                <p className="leading-relaxed">
                  Diawasi bersama <strong>BAZNAS Kota Cimahi</strong>, <strong>Pemkot Cimahi</strong>, dan <strong>DMI Kota Cimahi</strong> untuk LKS gratis, insentif ustadz, dan santunan santri dhuafa.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="button"
                  onClick={() => setIsPaymentStep(true)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-md shadow-emerald-900/15 hover:shadow-lg transition-all cursor-pointer"
                >
                  <span>Lanjut ke Pembayaran (Rp {currentAmount.toLocaleString('id-ID')})</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : isPaymentStep && !done ? (
            /* STEP 2: METODE PEMBAYARAN (QRIS & TRANSFER BANK) */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-black text-sm sm:text-base text-slate-900">
                    Pilih Metode Pembayaran
                  </h4>
                  <p className="text-xs text-slate-500">
                    Nominal Infak: <strong className="text-emerald-800">Rp {currentAmount.toLocaleString('id-ID')}</strong>
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase border border-emerald-300">
                  {donorName || 'Hamba Allah'}
                </span>
              </div>

              {/* Method Switcher Tabs */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('qris')}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'qris'
                      ? 'bg-white text-emerald-900 shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-emerald-700" />
                  <span>QRIS (Semua E-Wallet/M-Banking)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('transfer')}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'transfer'
                      ? 'bg-white text-emerald-900 shadow-xs border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-emerald-700" />
                  <span>Transfer Bank (BSI &amp; BJB)</span>
                </button>
              </div>

              {/* QRIS Content */}
              {paymentMethod === 'qris' && (
                <div className="space-y-3 animate-in fade-in duration-150">
                  <div className="p-4 bg-gradient-to-b from-slate-50 to-white rounded-2xl border border-slate-200 text-center space-y-3">
                    <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold uppercase border border-emerald-300">
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>{gerakan5000Config.qrisMerchantName || 'SHOLEH CENDEKIA CIMAHI'}</span>
                    </div>

                    <div className="w-44 h-44 bg-white p-3 border-2 border-slate-300 rounded-2xl mx-auto flex flex-col items-center justify-center shadow-inner relative group">
                      {gerakan5000Config.qrisImageUrl ? (
                        <img
                          src={gerakan5000Config.qrisImageUrl}
                          alt="QRIS Donasi"
                          className="w-full h-full object-contain rounded-lg"
                        />
                      ) : (
                        <QrCode className="w-32 h-32 text-slate-800" />
                      )}
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs font-black text-slate-900">
                        NMID: {gerakan5000Config.qrisNmid}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Bisa di-scan menggunakan GoPay, OVO, ShopeePay, Dana, LinkAja, BCA Mobile, Livin Mandiri, BRImo, BSI Mobile, dll.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Transfer Bank Content */}
              {paymentMethod === 'transfer' && (
                <div className="space-y-3 animate-in fade-in duration-150">
                  {/* Bank 1: BSI */}
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                        <Building2 className="w-4 h-4 text-emerald-700" />
                        {gerakan5000Config.bankName}
                      </span>
                      {gerakan5000Config.bankCode && (
                        <span className="text-[10px] text-slate-500 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
                          Kode: {gerakan5000Config.bankCode}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200">
                      <div>
                        <div className="text-xs text-slate-500">Nomor Rekening:</div>
                        <div className="font-black text-sm sm:text-base text-slate-900 tracking-wider font-mono">
                          {gerakan5000Config.bankAccountNumber}
                        </div>
                        <div className="text-[10px] text-slate-600 font-semibold">
                          a.n. {gerakan5000Config.accountHolder}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopy(gerakan5000Config.bankAccountNumber, 'bank1')}
                        className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-200 flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        {copiedField === 'bank1' ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Tersalin!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Salin No. Rek</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Bank 2: Secondary Bank (if configured) */}
                  {gerakan5000Config.secondaryBankName && (
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                          <Building2 className="w-4 h-4 text-teal-700" />
                          {gerakan5000Config.secondaryBankName}
                        </span>
                      </div>

                      <div className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200">
                        <div>
                          <div className="text-xs text-slate-500">Nomor Rekening:</div>
                          <div className="font-black text-sm sm:text-base text-slate-900 tracking-wider font-mono">
                            {gerakan5000Config.secondaryBankAccountNumber}
                          </div>
                          <div className="text-[10px] text-slate-600 font-semibold">
                            a.n. {gerakan5000Config.secondaryBankAccountHolder}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            handleCopy(
                              gerakan5000Config.secondaryBankAccountNumber || '',
                              'bank2'
                            )
                          }
                          className="px-3 py-1.5 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 font-bold text-xs border border-teal-200 flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          {copiedField === 'bank2' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-teal-600" />
                              <span>Tersalin!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Salin No. Rek</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Confirmation Navigation */}
              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setIsPaymentStep(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 cursor-pointer"
                >
                  Kembali
                </button>
                <button
                  type="button"
                  onClick={handleComplete}
                  className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-md cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-amber-300" />
                  <span>Saya Sudah Transfer / Scan QRIS</span>
                </button>
              </div>
            </div>
          ) : (
            /* STEP 3: BLESSED RECEIPT & SUCCESS CONFIRMATION */
            <div className="text-center py-6 space-y-4 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-10 h-10 text-emerald-700" />
              </div>

              <div className="space-y-1">
                <div className="inline-block px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase tracking-wider">
                  Alhamdulillah &bull; Jazakumullah Khairan
                </div>
                <h4 className="text-lg sm:text-xl font-black text-slate-900">
                  Infak &amp; Dukungan Anda Telah Diterima!
                </h4>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  Semoga menjadi amal jariyah yang memberkahi keluarga, memuliakan akhlak buah hati, dan mencerdaskan generasi Kota Cimahi.
                </p>
              </div>

              {/* Digital Acknowledgment Receipt */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs space-y-2 max-w-sm mx-auto">
                <div className="flex justify-between py-1 border-b border-slate-200">
                  <span className="text-slate-500">Nama Donatur / Santri</span>
                  <strong className="text-slate-900">{donorName || 'Hamba Allah'}</strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200">
                  <span className="text-slate-500">Nominal Disalurkan</span>
                  <strong className="text-emerald-800 font-black">
                    Rp {currentAmount.toLocaleString('id-ID')}
                  </strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200">
                  <span className="text-slate-500">Metode</span>
                  <span className="text-slate-800 font-semibold">
                    {paymentMethod === 'qris' ? 'QRIS Digital' : 'Transfer Bank'}
                  </span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Status</span>
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Terverifikasi Sistem
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleReset}
                className="mt-2 px-6 py-2.5 rounded-xl bg-emerald-800 text-white font-bold text-xs sm:text-sm hover:bg-emerald-700 transition-colors shadow-md cursor-pointer"
              >
                Selesai &amp; Kembali
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
