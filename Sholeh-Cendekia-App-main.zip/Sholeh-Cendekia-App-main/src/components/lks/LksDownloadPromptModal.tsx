import React, { useState } from 'react';
import { LearningMaterial } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  X,
  HeartHandshake,
  Download,
  Printer,
  Sparkles,
  QrCode,
  CheckCircle2,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

interface LksDownloadPromptModalProps {
  material: LearningMaterial | null;
  isOpen: boolean;
  onClose: () => void;
}

export const LksDownloadPromptModal: React.FC<LksDownloadPromptModalProps> = ({
  material,
  isOpen,
  onClose
}) => {
  const { recordParticipation5000 } = useApp();
  const [step, setStep] = useState<'prompt' | 'support_flow' | 'success'>('prompt');
  const [selectedMethod, setSelectedMethod] = useState<'qris' | 'va'>('qris');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen || !material) return null;

  const triggerDirectDownload = () => {
    // Generate clean printable LKS document or simulated download
    const printableWindow = window.open('', '_blank');
    if (printableWindow) {
      printableWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>LKS - ${material.title}</title>
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; padding: 24px; color: #1e293b; max-width: 800px; margin: 0 auto; }
            .header { border-bottom: 2px solid #047857; padding-bottom: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; }
            .badge { background: #d1fae5; color: #065f46; padding: 4px 8px; border-radius: 6px; font-weight: bold; font-size: 12px; }
            h1 { font-size: 20px; margin: 0 0 6px 0; color: #065f46; }
            .meta { font-size: 13px; color: #475569; }
            .box { border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px; margin: 16px 0; background: #f8fafc; }
            .q-item { margin-bottom: 14px; padding-bottom: 10px; border-bottom: 1px dashed #e2e8f0; }
            .footer { font-size: 11px; text-align: center; color: #94a3b8; margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 10px; }
            @media print { .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <span class="badge">SHOLEH CENDEKIA CIMAHI &bull; LKS RESMI</span>
              <h1>${material.title}</h1>
              <div class="meta">Jenjang: ${material.jenjang} &bull; Kelas: ${material.kelas} &bull; Mata Pelajaran: ${material.subject} &bull; Tema: ${material.tema}</div>
            </div>
          </div>

          <div class="box">
            <strong>Identitas Siswa:</strong>
            <div style="margin-top: 8px; display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 13px;">
              <div>Nama: ....................................................</div>
              <div>Kelas / NISN: .......................................</div>
              <div>Sekolah: ...............................................</div>
              <div>Masjid / DKM: ......................................</div>
            </div>
          </div>

          <div style="margin-top: 16px;">
            <h3 style="font-size: 15px; color: #0f172a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">A. Ringkasan & Petunjuk Belajar</h3>
            <p style="font-size: 13px; line-height: 1.6; color: #334155;">${material.summaryContent || material.description}</p>
          </div>

          ${
            material.mcQuestions && material.mcQuestions.length > 0
              ? `
              <div style="margin-top: 18px;">
                <h3 style="font-size: 15px; color: #0f172a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">B. Lembar Kerja Soal Pilihan Ganda</h3>
                ${material.mcQuestions
                  .map(
                    (q, idx) => `
                  <div class="q-item">
                    <p style="font-size: 13px; font-weight: bold; margin: 4px 0;">${idx + 1}. ${q.question}</p>
                    <div style="margin-left: 12px; font-size: 12px; color: #334155;">
                      ${q.options.map((opt, oIdx) => `<div>(${String.fromCharCode(65 + oIdx)}) ${opt}</div>`).join('')}
                    </div>
                  </div>
                `
                  )
                  .join('')}
              </div>
            `
              : ''
          }

          ${
            material.checklistItems && material.checklistItems.length > 0
              ? `
              <div style="margin-top: 18px;">
                <h3 style="font-size: 15px; color: #0f172a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">C. Lembar Checklist Pembiasaan Ibadah</h3>
                ${material.checklistItems
                  .map(
                    item => `
                  <div style="font-size: 12px; padding: 4px 0;">
                    [ &nbsp; ] &nbsp; ${item}
                  </div>
                `
                  )
                  .join('')}
              </div>
            `
              : ''
          }

          <div class="footer">
            Sholeh Cendekia Cimahi &bull; Gerakan Pembentukan Karakter Siswa Kota Cimahi &bull; Me-Ramadhan-kan 11 Bulan Lainnya
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
        </html>
      `);
      printableWindow.document.close();
    }
    onClose();
  };

  const handleSupportClick = () => {
    setStep('support_flow');
  };

  const handleCompleteSupport = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      recordParticipation5000();
      setStep('success');
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-slate-900">
        {/* Header Modal */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-700 px-5 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-5 h-5 text-amber-300" />
            <h3 className="font-black text-sm sm:text-base">Gerakan Cimahi Pintar 5.000</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Stages */}
        <div className="p-5 sm:p-6 space-y-5 text-xs sm:text-sm">
          {step === 'prompt' && (
            <>
              {/* Contextual Movement Invitation */}
              <div className="text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto shadow-inner">
                  <Sparkles className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 inline-block mb-1">
                    Dukung Agar LKS Ini Terus Gratis
                  </span>
                  <h4 className="text-base sm:text-lg font-black text-slate-900">
                    LKS ini dikembangkan agar siswa Cimahi dapat belajar dengan mudah.
                  </h4>
                </div>
                <p className="text-slate-600 leading-relaxed text-xs">
                  Jika berkenan, dukung keberlanjutan ekosistem <strong>Sholeh Cendekia</strong> melalui:
                </p>
              </div>

              {/* Box Gerakan 5.000 */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-300 text-center space-y-2">
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-900">
                  GERAKAN CIMAHI PINTAR 5.000
                </p>
                <div className="text-2xl sm:text-3xl font-black text-emerald-800">
                  Rp5.000
                </div>
                <p className="text-xs text-emerald-900 font-medium">
                  &ldquo;Rp5.000 dari kita, manfaatnya bisa terus dirasakan bersama untuk menjaga materi belajar tetap tersedia bagi seluruh siswa.&rdquo;
                </p>
              </div>

              <div className="space-y-2 pt-2">
                {/* Dukung Button */}
                <button
                  type="button"
                  onClick={handleSupportClick}
                  className="w-full py-3 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <HeartHandshake className="w-4 h-4 text-amber-300" />
                  <span>Dukung Rp5.000 & Cetak LKS</span>
                </button>

                {/* Lewati Button (Mandatory clear option without guilt) */}
                <button
                  type="button"
                  onClick={triggerDirectDownload}
                  className="w-full py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 text-slate-500" />
                  <span>Lewati untuk Download Langsung (Gratis)</span>
                </button>
              </div>
            </>
          )}

          {step === 'support_flow' && (
            <>
              <div className="space-y-4">
                <div className="text-center space-y-1">
                  <h4 className="font-black text-base text-slate-900">
                    Pilih Metode Partisipasi Rp5.000
                  </h4>
                  <p className="text-xs text-slate-500">
                    Dukungan untuk: {material.title}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('qris')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      selectedMethod === 'qris'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-black'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold'
                    }`}
                  >
                    <QrCode className="w-5 h-5 mx-auto mb-1 text-emerald-700" />
                    <span className="text-xs block">QRIS Cimahi Pintar</span>
                    <span className="text-[10px] text-slate-500 block font-normal">Semua e-Wallet / Mobile Bank</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMethod('va')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      selectedMethod === 'va'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-black'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold'
                    }`}
                  >
                    <ShieldCheck className="w-5 h-5 mx-auto mb-1 text-teal-700" />
                    <span className="text-xs block">Virtual Account</span>
                    <span className="text-[10px] text-slate-500 block font-normal">BJB Syariah / BSI</span>
                  </button>
                </div>

                {/* QR Code / VA Simulation */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-3">
                  {selectedMethod === 'qris' ? (
                    <div className="space-y-2">
                      <div className="w-32 h-32 bg-white p-2 border border-slate-300 rounded-xl mx-auto flex items-center justify-center shadow-xs">
                        <QrCode className="w-24 h-24 text-slate-800" />
                      </div>
                      <p className="text-[11px] text-slate-600 font-semibold">
                        NMID: ID102026CIMAHIPINTAR &bull; Nominal: <strong>Rp5.000</strong>
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-1.5 py-3">
                      <p className="text-[11px] text-slate-500 font-semibold">Nomor Virtual Account BSI/BJB Syariah:</p>
                      <div className="text-base font-black text-slate-900 tracking-wider bg-white p-2 rounded-lg border border-slate-300">
                        8805 0822 5000 1234
                      </div>
                      <p className="text-[10px] text-slate-500">Atas nama: Sholeh Cendekia Gerakan 5.000</p>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep('prompt')}
                    className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                  >
                    Kembali
                  </button>
                  <button
                    type="button"
                    onClick={handleCompleteSupport}
                    disabled={isProcessing}
                    className="flex-2 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                    <span>{isProcessing ? 'Memproses...' : 'Konfirmasi Partisipasi (Rp5.000)'}</span>
                  </button>
                </div>
              </div>
            </>
          )}

          {step === 'success' && (
            <>
              <div className="text-center space-y-4 py-4">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-8 h-8 text-emerald-700" />
                </div>
                <div>
                  <h4 className="font-black text-base sm:text-lg text-slate-900">
                    Jazakumullah Khairan Katsiran!
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 max-w-xs mx-auto">
                    Partisipasi Rp5.000 Anda telah tercatat untuk mendukung penyediaan materi belajar gratis bagi santri & siswa Cimahi.
                  </p>
                </div>

                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs font-semibold text-emerald-900">
                  Dokumen LKS &ldquo;{material.title}&rdquo; siap dicetak / diunduh sekarang.
                </div>

                <button
                  type="button"
                  onClick={triggerDirectDownload}
                  className="w-full py-3 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm shadow-md flex items-center justify-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  <span>Buka / Cetak LKS Sekarang</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
