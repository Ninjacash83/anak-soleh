import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LearningMaterial } from '../../types';
import { DigitalLksPlayerModal } from './DigitalLksPlayerModal';
import { LksDownloadPromptModal } from './LksDownloadPromptModal';
import {
  BookOpen,
  Smartphone,
  Download,
  Search,
  Filter,
  CheckCircle2,
  Sparkles,
  Award,
  Clock,
  FileText,
  HeartHandshake
} from 'lucide-react';

interface LksLibraryViewProps {
  studentId?: string;
  defaultJenjang?: 'SD' | 'SMP' | 'SMA';
  compact?: boolean;
}

export const LksLibraryView: React.FC<LksLibraryViewProps> = ({
  defaultJenjang,
  compact = false
}) => {
  const { learningMaterials, lksSubmissions, currentStudent, setIsGerakan5000InfoOpen } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [jenjangFilter, setJenjangFilter] = useState<string>(defaultJenjang || 'ALL');
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');

  const [selectedDigitalMaterial, setSelectedDigitalMaterial] = useState<LearningMaterial | null>(null);
  const [selectedDownloadMaterial, setSelectedDownloadMaterial] = useState<LearningMaterial | null>(null);

  // Filter subjects available
  const subjects = Array.from(new Set(learningMaterials.map(m => m.subject)));

  const filteredMaterials = learningMaterials.filter(m => {
    const matchesSearch =
      m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.tema.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.subject.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesJenjang = jenjangFilter === 'ALL' || m.jenjang === jenjangFilter;
    const matchesSubject = subjectFilter === 'ALL' || m.subject === subjectFilter;

    return matchesSearch && matchesJenjang && matchesSubject;
  });

  const getSubmissionStatus = (materialId: string) => {
    if (!currentStudent) return null;
    return lksSubmissions.find(
      s => s.materialId === materialId && s.studentId === currentStudent.id
    );
  };

  const displayedMaterials = compact ? filteredMaterials.slice(0, 3) : filteredMaterials;

  return (
    <div className="space-y-6">
      {/* Header Banner (Full mode only) */}
      {!compact && (
        <div className="bg-gradient-to-br from-emerald-800 to-teal-700 rounded-3xl p-5 sm:p-7 text-white shadow-lg relative overflow-hidden">
          <div className="relative z-10 max-w-2xl space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/60 text-emerald-200 text-xs font-black uppercase tracking-wider">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Pusat Belajar & LKS Sholeh Cendekia</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              Lembar Kerja Siswa (LKS) & Modul Interaktif
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
              Tersedia dua mode: <strong>Kerjakan langsung di HP</strong> tanpa perlu print, atau <strong>Download & Cetak LKS</strong> untuk pengerjaan tertulis di rumah/sekolah.
            </p>
          </div>

          {/* Small movement banner button */}
          <div className="mt-4 pt-3 border-t border-emerald-700/60 flex items-center justify-between flex-wrap gap-2 text-xs">
            <span className="text-emerald-100 font-medium">
              Materi ini dijaga gratis melalui Gerakan Cimahi Pintar 5.000.
            </span>
            <button
              onClick={() => setIsGerakan5000InfoOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold transition-colors"
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>Pelajari Gerakan 5.000</span>
            </button>
          </div>
        </div>
      )}

      {/* Filters & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
          {/* Search Bar */}
          <div className="sm:col-span-6 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Cari judul LKS, tema, atau materi..."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 pl-9 text-xs sm:text-sm text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          {/* Jenjang Filter */}
          <div className="sm:col-span-3">
            <select
              value={jenjangFilter}
              onChange={e => setJenjangFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
            >
              <option value="ALL">Semua Jenjang (SD, SMP, SMA)</option>
              <option value="SD">Jenjang SD</option>
              <option value="SMP">Jenjang SMP</option>
              <option value="SMA">Jenjang SMA</option>
            </select>
          </div>

          {/* Subject Filter */}
          <div className="sm:col-span-3">
            <select
              value={subjectFilter}
              onChange={e => setSubjectFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
            >
              <option value="ALL">Semua Mata Pelajaran</option>
              {subjects.map(s => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Jenjang Badges */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[11px] font-bold text-slate-500 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Jenjang:
          </span>
          {['ALL', 'SD', 'SMP', 'SMA'].map(j => (
            <button
              key={j}
              onClick={() => setJenjangFilter(j)}
              className={`px-3 py-1 rounded-lg font-bold text-xs transition-colors shrink-0 ${
                jenjangFilter === j
                  ? 'bg-emerald-800 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {j === 'ALL' ? 'Semua' : j}
            </button>
          ))}
        </div>
      </div>

      {/* LKS Material Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {displayedMaterials.map(material => {
          const submission = getSubmissionStatus(material.id);
          const isDone = !!submission;

          return (
            <div
              key={material.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              {/* Card Thumbnail & Badge */}
              <div className="p-4 sm:p-5 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-extrabold text-[10px]">
                      {material.jenjang} &bull; {material.kelas}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-bold text-[10px]">
                      {material.subject}
                    </span>
                  </div>

                  {isDone ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-black text-[10px]">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Nilai: {submission.score}
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 font-bold text-[10px]">
                      Tersedia
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base leading-snug">
                    {material.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium mt-1 line-clamp-2">
                    {material.description}
                  </p>
                </div>

                <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    {material.estimatedTime}
                  </span>
                  <span className="flex items-center gap-1">
                    <FileText className="w-3 h-3 text-slate-400" />
                    {material.durationOrPages}
                  </span>
                </div>
              </div>

              {/* Two Action Buttons: MODE 1 (Digital HP) & MODE 2 (Download / Print) */}
              <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-100 grid grid-cols-2 gap-2">
                {/* Button 1: Kerjakan di HP */}
                <button
                  type="button"
                  onClick={() => setSelectedDigitalMaterial(material)}
                  className="w-full py-2 px-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span className="truncate">{isDone ? 'Buka Nilai' : 'Kerjakan di HP'}</span>
                </button>

                {/* Button 2: Download / Cetak LKS (Triggers Contextual Movement Prompt) */}
                <button
                  type="button"
                  onClick={() => setSelectedDownloadMaterial(material)}
                  className="w-full py-2 px-2.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span className="truncate">Download / Cetak</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredMaterials.length === 0 && (
        <div className="p-8 bg-white rounded-2xl border border-slate-200 text-center space-y-2">
          <BookOpen className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="font-bold text-slate-800 text-sm">LKS Tidak Ditemukan</h3>
          <p className="text-xs text-slate-500">
            Coba ubah kata kunci pencarian atau filter jenjang/mata pelajaran.
          </p>
        </div>
      )}

      {/* Digital LKS Player Modal */}
      <DigitalLksPlayerModal
        material={selectedDigitalMaterial}
        isOpen={!!selectedDigitalMaterial}
        onClose={() => setSelectedDigitalMaterial(null)}
      />

      {/* Contextual Gerakan 5.000 Download Prompt Modal */}
      <LksDownloadPromptModal
        material={selectedDownloadMaterial}
        isOpen={!!selectedDownloadMaterial}
        onClose={() => setSelectedDownloadMaterial(null)}
      />
    </div>
  );
};
