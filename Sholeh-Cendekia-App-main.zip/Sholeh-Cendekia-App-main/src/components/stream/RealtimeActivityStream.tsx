import React, { useState, useMemo } from 'react';
import { useActivityStream } from '../../context/ActivityStreamContext';
import { useApp } from '../../context/AppContext';
import { ActivityStreamItem, ActivityStreamFilter } from '../../types/activityStream';
import {
  Radio,
  Flame,
  CheckCircle2,
  Heart,
  Award,
  BookOpen,
  Building2,
  GraduationCap,
  Sparkles,
  Search,
  Filter,
  Volume2,
  VolumeX,
  Share2,
  MessageCircle,
  ThumbsUp,
  RotateCw,
  BellRing,
  ArrowUpRight
} from 'lucide-react';

interface RealtimeActivityStreamProps {
  compact?: boolean;
  maxItems?: number;
  title?: string;
  showFilters?: boolean;
  className?: string;
}

export const RealtimeActivityStream: React.FC<RealtimeActivityStreamProps> = ({
  compact = false,
  maxItems,
  title = 'Aktivitas & Prestasi Real-Time Kota Cimahi',
  showFilters = true,
  className = ''
}) => {
  const {
    streamItems,
    reactToItem,
    soundEnabled,
    setSoundEnabled,
    unreadCount,
    clearUnread,
    isLiveConnected,
    activeFilter,
    setActiveFilter
  } = useActivityStream();

  const { currentStudent, currentTeacher, currentMosque, currentUser } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [praiseSentId, setPraiseSentId] = useState<string | null>(null);
  const [praiseMessage, setPraiseMessage] = useState('');

  // Format relative time in Indonesian
  const getRelativeTime = (isoString: string) => {
    const now = new Date();
    const time = new Date(isoString);
    const diffMs = now.getTime() - time.getTime();
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);

    if (diffSecs < 30) return 'Baru saja';
    if (diffMins < 1) return `${diffSecs} dtk lalu`;
    if (diffMins < 60) return `${diffMins} mnt lalu`;
    if (diffHours < 24) return `${diffHours} jam lalu`;
    return time.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
  };

  // Filter items based on activeFilter and searchTerm
  const filteredItems = useMemo(() => {
    let result = streamItems;

    // Filter type
    if (activeFilter === 'my_school') {
      const mySchoolName =
        currentStudent?.schoolName ||
        currentTeacher?.schoolName ||
        (currentUser as any)?.entityName;
      if (mySchoolName) {
        result = result.filter(item => item.schoolName === mySchoolName);
      }
    } else if (activeFilter === 'my_mosque') {
      const myMosqueName =
        currentStudent?.mosqueName ||
        currentMosque?.name ||
        (currentUser as any)?.entityName;
      if (myMosqueName) {
        result = result.filter(item => item.mosqueName === myMosqueName);
      }
    } else if (activeFilter === 'accomplishments') {
      result = result.filter(
        item =>
          item.type === 'streak_milestone' ||
          item.type === 'lks_completion' ||
          item.type === 'teacher_observation'
      );
    } else if (activeFilter === 'infak') {
      result = result.filter(item => item.type === 'donation_5000');
    } else if (activeFilter === 'verifications') {
      result = result.filter(
        item =>
          item.type === 'dkm_verification' || item.type === 'parent_confirmation'
      );
    }

    // Search filter
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        item =>
          item.actorName.toLowerCase().includes(q) ||
          item.title.toLowerCase().includes(q) ||
          item.description.toLowerCase().includes(q) ||
          item.schoolName?.toLowerCase().includes(q) ||
          item.mosqueName?.toLowerCase().includes(q)
      );
    }

    // Deduplicate items by ID
    const seen = new Set<string>();
    const uniqueResult: ActivityStreamItem[] = [];
    for (const item of result) {
      if (!seen.has(item.id)) {
        seen.add(item.id);
        uniqueResult.push(item);
      }
    }

    if (maxItems) {
      return uniqueResult.slice(0, maxItems);
    }
    return uniqueResult;
  }, [
    streamItems,
    activeFilter,
    searchTerm,
    maxItems,
    currentStudent,
    currentTeacher,
    currentMosque,
    currentUser
  ]);

  const handleSendPraiseSubmit = (e: React.FormEvent, itemId: string) => {
    e.preventDefault();
    if (!praiseMessage.trim()) return;
    reactToItem(itemId, 'praise');
    setPraiseSentId(null);
    setPraiseMessage('');
  };

  const getBadgeColor = (color?: string) => {
    switch (color) {
      case 'emerald':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'amber':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'indigo':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'teal':
        return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'rose':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'purple':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'blue':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getTypeIcon = (type: ActivityStreamItem['type']) => {
    switch (type) {
      case 'streak_milestone':
        return <Flame className="w-4 h-4 text-amber-500" />;
      case 'dkm_verification':
      case 'parent_confirmation':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      case 'lks_completion':
        return <BookOpen className="w-4 h-4 text-teal-600" />;
      case 'donation_5000':
        return <Heart className="w-4 h-4 text-rose-500" />;
      case 'teacher_observation':
        return <Award className="w-4 h-4 text-indigo-600" />;
      case 'system_update':
        return <Sparkles className="w-4 h-4 text-blue-600" />;
      default:
        return <Radio className="w-4 h-4 text-emerald-600" />;
    }
  };

  return (
    <div
      className={`bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden ${className}`}
    >
      {/* Header Bar */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-emerald-700/50 border border-emerald-500/40 shrink-0">
            <Radio className="w-4 h-4 text-emerald-200 animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-400"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-black tracking-tight">{title}</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-400 text-slate-950 border border-amber-300">
                Data Simulasi MVP
              </span>
            </div>
            <p className="text-[11px] text-emerald-200/80">
              Umpan aktivitas sistem &amp; pencapaian aksi pengguna (Simulasi MVP Sholeh Cendekia)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-emerald-100 text-xs flex items-center gap-1.5 transition-colors"
            title={soundEnabled ? 'Matikan Suara Notifikasi' : 'Aktifkan Suara Notifikasi'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline text-[11px]">
              {soundEnabled ? 'Suara Aktif' : 'Suara Bisu'}
            </span>
          </button>

          {/* Connection Indicator */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-[10px] text-emerald-200 font-semibold">
            <span
              className={`w-2 h-2 rounded-full ${
                isLiveConnected ? 'bg-emerald-400' : 'bg-amber-400'
              }`}
            />
            {isLiveConnected ? 'Terhubung' : 'Sinkronisasi...'}
          </div>
        </div>
      </div>

      {/* Unread Items Banner */}
      {unreadCount > 0 && (
        <button
          onClick={clearUnread}
          className="w-full py-2 px-4 bg-amber-500/10 hover:bg-amber-500/20 border-b border-amber-200 text-amber-900 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
        >
          <BellRing className="w-3.5 h-3.5 text-amber-600 animate-bounce" />
          <span>Ada {unreadCount} aktivitas baru — Klik untuk lihat terbaru</span>
        </button>
      )}

      {/* Controls & Filter Bar */}
      {showFilters && !compact && (
        <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-200 space-y-3">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            {/* Search Box */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Cari siswa, sekolah, atau masjid..."
                className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
              />
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 text-xs font-semibold">
              <button
                onClick={() => setActiveFilter('all')}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
                  activeFilter === 'all'
                    ? 'bg-emerald-800 text-white font-bold shadow-2xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                Semua Kota
              </button>
              {(currentStudent?.schoolName || currentTeacher?.schoolName) && (
                <button
                  onClick={() => setActiveFilter('my_school')}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors flex items-center gap-1 ${
                    activeFilter === 'my_school'
                      ? 'bg-emerald-800 text-white font-bold shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <GraduationCap className="w-3.5 h-3.5" />
                  Sekolah Saya
                </button>
              )}
              {(currentStudent?.mosqueName || currentMosque?.name) && (
                <button
                  onClick={() => setActiveFilter('my_mosque')}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors flex items-center gap-1 ${
                    activeFilter === 'my_mosque'
                      ? 'bg-emerald-800 text-white font-bold shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5" />
                  Masjid Saya
                </button>
              )}
              <button
                onClick={() => setActiveFilter('accomplishments')}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors flex items-center gap-1 ${
                  activeFilter === 'accomplishments'
                    ? 'bg-emerald-800 text-white font-bold shadow-2xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                Prestasi & Streak
              </button>
              <button
                onClick={() => setActiveFilter('infak')}
                className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors flex items-center gap-1 ${
                  activeFilter === 'infak'
                    ? 'bg-emerald-800 text-white font-bold shadow-2xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Heart className="w-3.5 h-3.5 text-rose-500" />
                Infak 5.000
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Activity Stream Feed */}
      <div className={`divide-y divide-slate-100 ${compact ? 'max-h-96' : 'max-h-[580px]'} overflow-y-auto`}>
        {filteredItems.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs">
            Tidak ada aktivitas real-time yang sesuai filter saat ini.
          </div>
        ) : (
          filteredItems.map((item, idx) => (
            <div
              key={`${item.id}-${idx}`}
              className={`p-3.5 sm:p-4 hover:bg-slate-50/80 transition-colors ${
                item.isLive ? 'bg-emerald-50/30' : ''
              }`}
            >
              <div className="flex items-start gap-3">
                {/* Avatar / Icon Badge */}
                <div className="relative shrink-0">
                  {item.actorAvatar ? (
                    <img
                      src={item.actorAvatar}
                      alt={item.actorName}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-2xs"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 border border-emerald-200 font-black flex items-center justify-center text-sm shadow-2xs">
                      {item.actorName.charAt(0)}
                    </div>
                  )}
                  <div className="absolute -bottom-1 -right-1 p-0.5 rounded-md bg-white border border-slate-200 shadow-2xs">
                    {getTypeIcon(item.type)}
                  </div>
                </div>

                {/* Main Item Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-extrabold text-xs text-slate-900 truncate">
                        {item.actorName}
                      </span>
                      {item.badge && (
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold border ${getBadgeColor(
                            item.badge.color
                          )}`}
                        >
                          {item.badge.label}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-medium shrink-0">
                      {getRelativeTime(item.timestamp)}
                    </span>
                  </div>

                  <h4 className="text-xs sm:text-sm font-bold text-slate-800 tracking-tight leading-snug">
                    {item.title}
                  </h4>

                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Context Meta Tags (School / Mosque / District) */}
                  <div className="mt-2 flex items-center gap-2 flex-wrap text-[11px] text-slate-500 font-medium">
                    {item.schoolName && (
                      <span className="inline-flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md">
                        <GraduationCap className="w-3 h-3 text-slate-500" />
                        {item.schoolName}
                      </span>
                    )}
                    {item.mosqueName && (
                      <span className="inline-flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md">
                        <Building2 className="w-3 h-3 text-slate-500" />
                        {item.mosqueName}
                      </span>
                    )}
                    {item.kecamatan && (
                      <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded-md">
                        📍 {item.kecamatan}
                      </span>
                    )}
                  </div>

                  {/* Reaction Bar */}
                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
                      <button
                        onClick={() => reactToItem(item.id, 'praise')}
                        className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-600 text-[11px] font-bold flex items-center gap-1 transition-colors"
                        title="Kirim Pujian / Apresiasi"
                      >
                        <span>👏</span>
                        <span>{item.reactions.praise}</span>
                      </button>

                      <button
                        onClick={() => reactToItem(item.id, 'barakallah')}
                        className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-600 text-[11px] font-bold flex items-center gap-1 transition-colors"
                        title="Ucapkan Barakallah"
                      >
                        <span>🤲</span>
                        <span>{item.reactions.barakallah}</span>
                      </button>

                      <button
                        onClick={() => reactToItem(item.id, 'fire')}
                        className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-amber-100 hover:text-amber-800 text-slate-600 text-[11px] font-bold flex items-center gap-1 transition-colors"
                        title="Semangat 🔥"
                      >
                        <span>🔥</span>
                        <span>{item.reactions.fire}</span>
                      </button>

                      <button
                        onClick={() => reactToItem(item.id, 'masyaAllah')}
                        className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-teal-100 hover:text-teal-800 text-slate-600 text-[11px] font-bold flex items-center gap-1 transition-colors"
                        title="Masya Allah ✨"
                      >
                        <span>✨</span>
                        <span>{item.reactions.masyaAllah}</span>
                      </button>
                    </div>

                    <button
                      onClick={() =>
                        setPraiseSentId(praiseSentId === item.id ? null : item.id)
                      }
                      className="text-[11px] font-bold text-emerald-800 hover:text-emerald-900 flex items-center gap-1 hover:underline ml-auto"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      Kirim Pesan Semangat
                    </button>
                  </div>

                  {/* Send Custom Praise Input */}
                  {praiseSentId === item.id && (
                    <form
                      onSubmit={e => handleSendPraiseSubmit(e, item.id)}
                      className="mt-2.5 p-2 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center gap-2"
                    >
                      <input
                        type="text"
                        value={praiseMessage}
                        onChange={e => setPraiseMessage(e.target.value)}
                        placeholder="Tulis ucapan selamat/doa (contoh: Masya Allah, terus tingkatkan!)..."
                        className="flex-1 px-3 py-1 bg-white border border-emerald-300 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-600"
                      />
                      <button
                        type="submit"
                        className="px-3 py-1 bg-emerald-800 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 shrink-0"
                      >
                        Kirim
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer info */}
      <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-500 font-medium flex items-center justify-between">
        <span>Diperbarui otomatis saat siswa/sekolah beraktivitas</span>
        <button
          onClick={() => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="text-emerald-800 hover:underline font-bold flex items-center gap-1"
        >
          Ke Atas <ArrowUpRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
