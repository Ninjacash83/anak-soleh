import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ActivityCategory, ActivityRecord } from '../../types';
import { formatShortIndonesianDate } from '../../utils/dateUtils';
import {
  BookOpen,
  CheckCircle2,
  PlusCircle,
  Search,
  Sunrise,
  Moon,
  Heart,
  UserCheck,
  HeartHandshake,
  X
} from 'lucide-react';

interface BukuKendaliTableProps {
  filterStudentId?: string;
  filterMosqueId?: string;
  filterSchoolId?: string;
  readOnly?: boolean;
}

export const BukuKendaliTable: React.FC<BukuKendaliTableProps> = ({
  filterStudentId,
  filterMosqueId,
  filterSchoolId,
  readOnly = false
}) => {
  const {
    records,
    currentRole,
    currentStudent,
    currentMosque,
    parentChildren,
    addActivityRecord,
    confirmActivityParent,
    verifyActivityDKM
  } = useApp();

  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [confirmModalRecord, setConfirmModalRecord] = useState<ActivityRecord | null>(null);
  const [verifyModalRecord, setVerifyModalRecord] = useState<ActivityRecord | null>(null);

  // Add Form State
  const [newCategory, setNewCategory] = useState<ActivityCategory>('subuh_berjamaah');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCompanion, setNewCompanion] = useState<ActivityRecord['companion']>('Orang Tua');
  const [newNotes, setNewNotes] = useState('');

  // Feedback States
  const [parentFeedback, setParentFeedback] = useState('');
  const [dkmFeedback, setDkmFeedback] = useState('');

  // Strictly scoped studentId for Siswa role
  const effectiveStudentId =
    filterStudentId || (currentRole === 'siswa' ? currentStudent?.id : undefined);

  const parentChildIds = new Set(parentChildren.map(c => c.id));

  const filteredRecords = records.filter(r => {
    if (effectiveStudentId && r.studentId !== effectiveStudentId) return false;
    if (filterMosqueId && r.mosqueId !== filterMosqueId) return false;
    if (filterSchoolId && r.schoolId !== filterSchoolId) return false;

    const matchCategory = categoryFilter === 'all' || r.category === categoryFilter;
    const matchStatus = statusFilter === 'all' || r.status === statusFilter;
    const matchSearch =
      !searchTerm.trim() ||
      r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.description.toLowerCase().includes(searchTerm.toLowerCase());

    return matchCategory && matchStatus && matchSearch;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetId = effectiveStudentId;
    if (!targetId || !newTitle.trim()) return;

    addActivityRecord({
      studentId: targetId,
      category: newCategory,
      title: newTitle.trim(),
      description: newDesc.trim() || `Melaksanakan ${newTitle.trim()} dengan tertib.`,
      companion: newCompanion,
      notes: newNotes.trim() || undefined
    });

    setNewTitle('');
    setNewDesc('');
    setNewNotes('');
    setIsAddModalOpen(false);
  };

  const handleConfirmSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmModalRecord) return;
    confirmActivityParent(confirmModalRecord.id, parentFeedback);
    setParentFeedback('');
    setConfirmModalRecord(null);
  };

  const handleVerifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyModalRecord) return;
    verifyActivityDKM(verifyModalRecord.id, dkmFeedback);
    setDkmFeedback('');
    setVerifyModalRecord(null);
  };

  const categoryMeta: Record<ActivityCategory, { label: string; icon: React.ReactNode }> = {
    subuh_berjamaah: {
      label: 'Subuh Berjamaah',
      icon: <Sunrise className="w-4 h-4 text-amber-600" />
    },
    maghrib_mengaji: {
      label: 'Maghrib Mengaji',
      icon: <Moon className="w-4 h-4 text-indigo-600" />
    },
    tilawah_belajar: {
      label: 'Tilawah & Belajar',
      icon: <BookOpen className="w-4 h-4 text-emerald-700" />
    },
    kebaikan_kepedulian: {
      label: 'Kebaikan & Kepedulian',
      icon: <Heart className="w-4 h-4 text-rose-600" />
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
      {/* Header & Controls */}
      <div className="p-4 sm:p-5 border-b border-slate-200 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-extrabold text-slate-900">
              Buku Kendali Anak Sholeh
            </h3>
            <p className="text-xs text-slate-500">
              Siklus terpadu: Membiasakan &rarr; Mendampingi &rarr; Mencatat &rarr; Membina
            </p>
          </div>

          {!readOnly && currentRole === 'siswa' && effectiveStudentId && (
            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Catat Kegiatan Baru</span>
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Cari kegiatan atau nama siswa..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:bg-white focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-700 outline-hidden"
          >
            <option value="all">Semua Pilar Kegiatan (4 Pilar)</option>
            <option value="subuh_berjamaah">1. Subuh Berjamaah</option>
            <option value="maghrib_mengaji">2. Maghrib Mengaji</option>
            <option value="tilawah_belajar">3. Tilawah &amp; Belajar</option>
            <option value="kebaikan_kepedulian">4. Kebaikan &amp; Kepedulian</option>
          </select>

          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-700 outline-hidden"
          >
            <option value="all">Semua Status Verifikasi</option>
            <option value="dicatat">Baru Dicatat</option>
            <option value="dikonfirmasi_ortu">Dikonfirmasi Orang Tua</option>
            <option value="diverifikasi_dkm">Diverifikasi DKM</option>
          </select>
        </div>
      </div>

      {/* Records List */}
      <div className="divide-y divide-slate-100">
        {filteredRecords.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            Belum ada catatan kegiatan Buku Kendali yang sesuai filter.
          </div>
        ) : (
          filteredRecords.map(rec => {
            const meta = categoryMeta[rec.category];
            const canParentConfirm =
              !readOnly &&
              currentRole === 'orang_tua' &&
              !rec.parentConfirmed &&
              parentChildIds.has(rec.studentId);

            const canDkmVerify =
              !readOnly &&
              currentRole === 'dkm' &&
              !rec.dkmVerified &&
              currentMosque &&
              rec.mosqueId === currentMosque.id;

            return (
              <div
                key={rec.id}
                className="p-4 sm:p-5 hover:bg-slate-50/70 transition-colors flex flex-col md:flex-row md:items-start justify-between gap-4 text-xs"
              >
                <div className="space-y-1.5 flex-1">
                  {/* Unboxed clean metadata line */}
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500">
                    <span className="inline-flex items-center gap-1 font-bold text-slate-800">
                      {meta.icon}
                      {meta.label}
                    </span>
                    <span aria-hidden="true">&middot;</span>
                    <span>{formatShortIndonesianDate(rec.date)}</span>
                    <span aria-hidden="true">&middot;</span>
                    <span>{rec.time} WIB</span>
                    <span aria-hidden="true">&middot;</span>
                    <span className="font-semibold text-slate-700">{rec.studentName}</span>
                    <span aria-hidden="true">&middot;</span>
                    <span>Pendamping: {rec.companion}</span>
                  </div>

                  <h4 className="font-extrabold text-sm text-slate-900">
                    {rec.title}
                  </h4>

                  <p className="text-slate-600 leading-relaxed">
                    {rec.description}
                  </p>

                  {rec.notes && (
                    <p className="text-[11px] text-slate-500 italic">
                      Catatan Siswa: &ldquo;{rec.notes}&rdquo;
                    </p>
                  )}

                  {/* Verification & Confirmation Notes */}
                  <div className="pt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px]">
                    <span
                      className={
                        rec.dkmVerified
                          ? 'text-emerald-800 font-bold inline-flex items-center gap-1'
                          : 'text-slate-400'
                      }
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {rec.dkmVerified
                        ? `Diverifikasi DKM (${rec.dkmVerifierName || rec.mosqueName})`
                        : `Menunggu Verifikasi ${rec.mosqueName}`}
                    </span>

                    <span
                      className={
                        rec.parentConfirmed
                          ? 'text-blue-800 font-bold inline-flex items-center gap-1'
                          : 'text-slate-400'
                      }
                    >
                      <HeartHandshake className="w-3.5 h-3.5" />
                      {rec.parentConfirmed
                        ? 'Dikonfirmasi Orang Tua'
                        : 'Menunggu Konfirmasi Orang Tua'}
                    </span>
                  </div>

                  {rec.parentNote && (
                    <p className="text-[11px] text-blue-900 bg-blue-50/70 px-3 py-1.5 rounded-xl border border-blue-100 mt-1">
                      <strong>Doa &amp; Konfirmasi Orang Tua:</strong> &ldquo;{rec.parentNote}&rdquo;
                    </p>
                  )}

                  {rec.dkmNote && (
                    <p className="text-[11px] text-emerald-900 bg-emerald-50/70 px-3 py-1.5 rounded-xl border border-emerald-100 mt-1">
                      <strong>Catatan Pembina DKM:</strong> &ldquo;{rec.dkmNote}&rdquo;
                    </p>
                  )}
                </div>

                {/* Role-Scoped Action Buttons */}
                {(canParentConfirm || canDkmVerify) && (
                  <div className="flex items-center gap-2 shrink-0 self-start">
                    {canParentConfirm && (
                      <button
                        type="button"
                        onClick={() => setConfirmModalRecord(rec)}
                        className="px-3.5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <HeartHandshake className="w-3.5 h-3.5" />
                        <span>Konfirmasi Orang Tua</span>
                      </button>
                    )}

                    {canDkmVerify && (
                      <button
                        type="button"
                        onClick={() => setVerifyModalRecord(rec)}
                        className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Verifikasi DKM</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Add Activity Modal (Siswa) */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-slate-200 shadow-2xl text-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-slate-900">
                Catat Amalan Buku Kendali Hari Ini
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3.5">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Pilar Kegiatan</label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as ActivityCategory)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="subuh_berjamaah">1. Subuh Berjamaah</option>
                  <option value="maghrib_mengaji">2. Maghrib Mengaji</option>
                  <option value="tilawah_belajar">3. Tilawah &amp; Belajar</option>
                  <option value="kebaikan_kepedulian">4. Kebaikan &amp; Kepedulian</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Judul Kegiatan</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="Contoh: Sholat Subuh Berjamaah / Tadarus Juz 30"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Keterangan Pelaksanaan</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  placeholder="Ceritakan singkat pelaksanaan kegiatanmu..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Didampingi Oleh</label>
                <select
                  value={newCompanion}
                  onChange={e => setNewCompanion(e.target.value as ActivityRecord['companion'])}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                >
                  <option value="Orang Tua">Orang Tua</option>
                  <option value="Ayah">Ayah</option>
                  <option value="Ibu">Ibu</option>
                  <option value="Guru Mengaji">Guru Mengaji / Ustadz DKM</option>
                  <option value="Guru Agama">Guru Agama</option>
                  <option value="Rekan Sebaya">Rekan Sebaya</option>
                  <option value="Mandiri">Mandiri</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 text-white font-bold rounded-xl cursor-pointer"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Parent Confirmation Modal */}
      {confirmModalRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-slate-200 shadow-2xl text-xs space-y-4">
            <h3 className="text-base font-extrabold text-slate-900">
              Konfirmasi &amp; Doa Orang Tua
            </h3>
            <p className="text-slate-600">
              Kegiatan Ananda <strong>{confirmModalRecord.studentName}</strong>: {confirmModalRecord.title}
            </p>
            <form onSubmit={handleConfirmSubmit} className="space-y-3">
              <textarea
                rows={3}
                value={parentFeedback}
                onChange={e => setParentFeedback(e.target.value)}
                placeholder="Tuliskan pesan semangat atau doa untuk ananda (opsional)..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmModalRecord(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-orange-600 text-white font-bold rounded-xl cursor-pointer"
                >
                  Konfirmasi Kegiatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DKM Verification Modal */}
      {verifyModalRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-slate-200 shadow-2xl text-xs space-y-4">
            <h3 className="text-base font-extrabold text-slate-900">
              Verifikasi Pembina DKM ({verifyModalRecord.mosqueName})
            </h3>
            <p className="text-slate-600">
              Siswa: <strong>{verifyModalRecord.studentName}</strong> &middot; {verifyModalRecord.title}
            </p>
            <form onSubmit={handleVerifySubmit} className="space-y-3">
              <textarea
                rows={3}
                value={dkmFeedback}
                onChange={e => setDkmFeedback(e.target.value)}
                placeholder="Catatan ustadz/pembina (contoh: Bacaan tartil, hadir tepat waktu)..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setVerifyModalRecord(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl cursor-pointer"
                >
                  Sah &amp; Verifikasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
