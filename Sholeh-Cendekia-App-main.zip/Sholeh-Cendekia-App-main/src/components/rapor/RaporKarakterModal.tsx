import React, { useRef } from 'react';
import { Student, ActivityRecord } from '../../types';
import { formatIndonesianDate, formatShortIndonesianDate } from '../../utils/dateUtils';
import {
  Printer,
  X,
  Award,
  CheckCircle2,
  ShieldCheck,
  FileText
} from 'lucide-react';

interface RaporKarakterModalProps {
  student: Student;
  records: ActivityRecord[];
  onClose: () => void;
}

export const RaporKarakterModal: React.FC<RaporKarakterModalProps> = ({
  student,
  records,
  onClose
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const studentRecords = records.filter(r => r.studentId === student.id);
  const totalSubuh = studentRecords.filter(r => r.category === 'subuh_berjamaah' && r.status !== 'belum_dicatat').length;
  const totalMaghrib = studentRecords.filter(r => r.category === 'maghrib_mengaji' && r.status !== 'belum_dicatat').length;
  const totalTilawah = studentRecords.filter(r => r.category === 'tilawah_belajar' && r.status !== 'belum_dicatat').length;
  const totalKebaikan = studentRecords.filter(r => r.category === 'kebaikan_kepedulian' && r.status !== 'belum_dicatat').length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Modal Box */}
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden flex flex-col max-h-[92vh] my-auto">
        {/* Top Actions Bar (Hidden on Print) */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between gap-3 shrink-0 print:hidden">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-800 text-amber-300">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-white">
                Rapor Resmi Buku Kendali Digital &amp; Karakter
              </h3>
              <p className="text-[11px] text-slate-300">
                Dokumen Hasil Pembinaan Karakter Sholeh — Kota Cimahi
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>Cetak / Simpan PDF</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Content Body */}
        <div className="p-6 sm:p-10 overflow-y-auto bg-white text-slate-900 space-y-6" ref={printRef}>
          {/* Header Kop Surat Official */}
          <div className="border-b-4 border-double border-slate-900 pb-5 text-center relative">
            <div className="flex items-center justify-between gap-4 mb-3">
              <div className="w-16 h-16 rounded-2xl bg-emerald-800 text-white font-black text-xl flex items-center justify-center border-2 border-amber-400 shrink-0">
                SC
              </div>

              <div className="flex-1 text-center space-y-0.5">
                <h4 className="text-xs font-bold tracking-widest text-slate-600 uppercase">
                  Pemerintah Kota Cimahi
                </h4>
                <h2 className="text-base sm:text-lg font-black text-slate-900 uppercase tracking-tight">
                  Dinas Pendidikan &amp; Kementerian Agama Kota Cimahi
                </h2>
                <p className="text-[11px] text-slate-600 font-semibold">
                  Program Pembinaan Karakter &amp; Istiqomah Buku Kendali Digital Ramadhan
                </p>
                <p className="text-[10px] text-slate-500 italic">
                  Jl. R.D. Hardjakusumah No.1, Cihanjuang, Kec. Cimahi Utara, Kota Cimahi, Jawa Barat 40513
                </p>
              </div>

              <div className="w-16 h-16 rounded-2xl bg-amber-400 text-slate-950 font-black text-xs flex flex-col items-center justify-center border-2 border-slate-900 shrink-0">
                <Award className="w-6 h-6 text-slate-950" />
                <span className="text-[8px] font-black uppercase">Cimahi</span>
              </div>
            </div>
          </div>

          {/* Report Title */}
          <div className="text-center space-y-1">
            <h3 className="text-base font-black text-slate-900 uppercase tracking-wider underline underline-offset-4">
              RAPOR HASIL BUKU KENDALI DIGITAL &amp; KEMAJUAN KARAKTER
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              Tahun Ajaran 2025/2026 &bull; Kota Cimahi
            </p>
          </div>

          {/* Student Identitas Matrix */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-300 text-xs font-medium">
            <div className="space-y-1.5">
              <div className="flex justify-between border-b border-slate-200 pb-1">
                <span className="text-slate-500">Nama Siswa:</span>
                <strong className="text-slate-900 font-extrabold">{student.name}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-1">
                <span className="text-slate-500">ID Siswa:</span>
                <strong className="text-slate-800">{student.id}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-1">
                <span className="text-slate-500">Kelas / Sekolah:</span>
                <strong className="text-slate-800">
                  {student.grade} &bull; {student.schoolName}
                </strong>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between border-b border-slate-200 pb-1">
                <span className="text-slate-500">Masjid Binaan:</span>
                <strong className="text-slate-800">{student.mosqueName}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-1">
                <span className="text-slate-500">Wilayah Kecamatan:</span>
                <strong className="text-slate-800">{student.kecamatan}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-1">
                <span className="text-slate-500">Nama Orang Tua:</span>
                <strong className="text-slate-800">{student.parentName}</strong>
              </div>
            </div>
          </div>

          {/* Summary Matrix Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200">
              <span className="block text-xl font-black text-emerald-800">{totalSubuh}</span>
              <span className="text-[11px] font-bold text-emerald-900">Subuh Berjamaah</span>
            </div>

            <div className="p-3 rounded-2xl bg-teal-50 border border-teal-200">
              <span className="block text-xl font-black text-teal-800">{totalMaghrib}</span>
              <span className="text-[11px] font-bold text-teal-900">Maghrib Mengaji</span>
            </div>

            <div className="p-3 rounded-2xl bg-indigo-50 border border-indigo-200">
              <span className="block text-xl font-black text-indigo-800">{totalTilawah + totalKebaikan}</span>
              <span className="text-[11px] font-bold text-indigo-900">Tilawah &amp; Kebaikan</span>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200">
              <span className="block text-xl font-black text-amber-900">{student.streakDays} Hari</span>
              <span className="text-[11px] font-bold text-amber-900">Rekor Streak</span>
            </div>
          </div>

          {/* Detailed Records Table */}
          <div className="space-y-2">
            <h4 className="font-extrabold text-xs text-slate-900 uppercase tracking-wider flex items-center justify-between">
              <span>Detail Catatan Kegiatan Terakhir</span>
              <span className="text-emerald-800 font-bold">
                Skor Karakter: {student.characterScore} Pts
              </span>
            </h4>

            <div className="border border-slate-300 rounded-2xl overflow-hidden text-xs">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-300 font-extrabold text-slate-700">
                    <th className="p-2.5">Tanggal</th>
                    <th className="p-2.5">Kategori Kegiatan</th>
                    <th className="p-2.5">Judul Amalan</th>
                    <th className="p-2.5 text-center">Orang Tua</th>
                    <th className="p-2.5 text-center">DKM Masjid</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {studentRecords.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-4 text-center text-slate-500 italic">
                        Belum ada data catatan amalan.
                      </td>
                    </tr>
                  ) : (
                    studentRecords.slice(0, 8).map(rec => (
                      <tr key={rec.id} className="hover:bg-slate-50">
                        <td className="p-2.5 font-medium text-slate-600">
                          {formatShortIndonesianDate(rec.date)}
                        </td>
                        <td className="p-2.5 font-bold text-slate-800 capitalize">
                          {rec.category.replace('_', ' ')}
                        </td>
                        <td className="p-2.5 text-slate-700">{rec.title}</td>
                        <td className="p-2.5 text-center">
                          {rec.parentConfirmed ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                              <CheckCircle2 className="w-3 h-3 text-emerald-800" /> Ada
                            </span>
                          ) : (
                            <span className="text-slate-400 text-[10px]">&mdash;</span>
                          )}
                        </td>
                        <td className="p-2.5 text-center">
                          {rec.dkmVerified ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                              <ShieldCheck className="w-3 h-3 text-emerald-800" /> Sah
                            </span>
                          ) : (
                            <span className="text-slate-400 text-[10px]">&mdash;</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Validation & Signature Box */}
          <div className="pt-6 border-t border-slate-300 grid grid-cols-3 gap-4 text-center text-xs text-slate-800">
            <div className="space-y-12">
              <p className="font-bold">Orang Tua / Wali</p>
              <p className="font-extrabold underline">{student.parentName}</p>
            </div>

            <div className="space-y-12">
              <p className="font-bold">Ketua DKM {student.mosqueName}</p>
              <p className="font-extrabold underline">Ustadz Penguji DKM</p>
            </div>

            <div className="space-y-12">
              <p className="font-bold">Guru Agama &amp; Pembimbing</p>
              <p className="font-extrabold underline">{student.teacherName || 'Guru Pembimbing'}</p>
            </div>
          </div>

          {/* QR Verification Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-500 font-medium">
            <p>
              Kode Otentikasi Digital: SC-CIMAHI-2026-RAPOR-{student.id}
            </p>
            <p>
              Dicetak pada {formatIndonesianDate(new Date().toISOString().split('T')[0])}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
