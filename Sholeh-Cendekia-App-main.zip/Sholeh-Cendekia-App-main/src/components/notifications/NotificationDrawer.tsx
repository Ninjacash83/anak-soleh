import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { NotificationItem, UserRole } from '../../types';
import {
  Bell,
  X,
  CheckCheck,
  CheckCircle2,
  BookOpen,
  MessageSquare,
  Calendar,
  MapPin,
  Clock,
  Sparkles,
  ArrowRight,
  Plus,
  Send,
  Trash2
} from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose
}) => {
  const {
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    sendNotification,
    deleteNotification,
    currentRole,
    currentUser,
    setActiveTab
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<
    'all' | 'unread' | 'tugas' | 'pesan_sekolah' | 'agenda_karakter'
  >('all');

  const [showBroadcastModal, setShowBroadcastModal] = useState(false);
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [broadcastCategory, setBroadcastCategory] = useState<NotificationItem['category']>('pesan_sekolah');
  const [broadcastPriority, setBroadcastPriority] = useState<'high' | 'normal'>('normal');
  const [broadcastActionTab, setBroadcastActionTab] = useState('buku_kendali');
  const [broadcastActionLabel, setBroadcastActionLabel] = useState('Lihat Informasi');
  const [broadcastEventDate, setBroadcastEventDate] = useState('');
  const [broadcastEventLoc, setBroadcastEventLoc] = useState('');

  const popoverRef = useRef<HTMLDivElement>(null);

  const canBroadcast =
    currentRole === 'super_admin' ||
    currentRole === 'guru_agama' ||
    currentRole === 'dkm' ||
    currentRole === 'admin_pemkot';

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(event.target as Node) &&
        !showBroadcastModal
      ) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose, showBroadcastModal]);

  if (!isOpen) return null;

  // Filter notifications relevant to current role
  const userNotifications = notifications.filter(n => {
    if (n.targetRoles && n.targetRoles.length > 0) {
      return n.targetRoles.includes(currentRole);
    }
    return true;
  });

  const filteredList = userNotifications.filter(n => {
    if (activeFilter === 'unread') return !n.isRead;
    if (activeFilter === 'tugas') return n.category === 'tugas' || n.category === 'lks';
    if (activeFilter === 'pesan_sekolah') return n.category === 'pesan_sekolah';
    if (activeFilter === 'agenda_karakter') return n.category === 'agenda_karakter';
    return true;
  });

  const unreadCount = userNotifications.filter(n => !n.isRead).length;

  const handleNotificationClick = (item: NotificationItem) => {
    markNotificationRead(item.id);
    if (item.actionTab) {
      setActiveTab(item.actionTab);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    onClose();
  };

  const handleBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle.trim() || !broadcastMsg.trim()) return;

    let targetRoles: UserRole[] = ['siswa', 'orang_tua'];
    if (broadcastCategory === 'agenda_karakter') {
      targetRoles = ['siswa', 'orang_tua', 'dkm', 'guru_agama', 'admin_pemkot', 'super_admin'];
    } else if (broadcastCategory === 'tugas') {
      targetRoles = ['siswa', 'orang_tua', 'guru_agama'];
    }

    sendNotification({
      title: broadcastTitle.trim(),
      message: broadcastMsg.trim(),
      category: broadcastCategory,
      targetRoles: targetRoles,
      sender: currentUser?.name || 'Pengelola Ekosistem',
      senderRole:
        currentRole === 'guru_agama'
          ? 'Guru Agama (PAI)'
          : currentRole === 'dkm'
          ? 'DKM Masjid'
          : currentRole === 'admin_pemkot'
          ? 'Pemkot Cimahi'
          : 'Super Admin',
      priority: broadcastPriority,
      actionTab: broadcastActionTab,
      actionLabel: broadcastActionLabel || 'Lihat Detail',
      eventDate: broadcastEventDate || undefined,
      eventLocation: broadcastEventLoc || undefined
    });

    setBroadcastTitle('');
    setBroadcastMsg('');
    setBroadcastEventDate('');
    setBroadcastEventLoc('');
    setShowBroadcastModal(false);
  };

  const getCategoryMeta = (category: NotificationItem['category']) => {
    switch (category) {
      case 'tugas':
      case 'lks':
        return {
          label: 'Tugas & LKS',
          badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300',
          icon: BookOpen
        };
      case 'pesan_sekolah':
        return {
          label: 'Pesan Sekolah',
          badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-300',
          icon: MessageSquare
        };
      case 'agenda_karakter':
        return {
          label: 'Agenda Karakter',
          badgeClass: 'bg-amber-100 text-amber-900 border-amber-300',
          icon: Calendar
        };
      case 'buku_kendali':
        return {
          label: 'Buku Kendali',
          badgeClass: 'bg-teal-100 text-teal-800 border-teal-300',
          icon: CheckCircle2
        };
      case 'prestasi':
        return {
          label: 'Prestasi',
          badgeClass: 'bg-purple-100 text-purple-800 border-purple-300',
          icon: Sparkles
        };
      default:
        return {
          label: 'Informasi',
          badgeClass: 'bg-slate-100 text-slate-800 border-slate-300',
          icon: Bell
        };
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/40 backdrop-blur-2xs flex justify-end sm:p-4 animate-in fade-in duration-150">
      <div
        ref={popoverRef}
        className="bg-white w-full sm:max-w-md min-h-screen sm:min-h-0 sm:max-h-[92vh] sm:rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden text-slate-900"
      >
        {/* Header Notification Panel */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-700 px-5 py-4 text-white flex items-center justify-between shrink-0 shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-8 h-8 rounded-xl bg-white/15 flex items-center justify-center">
                <Bell className="w-4 h-4 text-white" />
              </div>
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center border border-white">
                  {unreadCount}
                </span>
              )}
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base">Pusat Notifikasi</h3>
              <p className="text-[10px] text-emerald-200">
                Tugas, Pesan Sekolah &amp; Agenda Karakter
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {canBroadcast && (
              <button
                onClick={() => setShowBroadcastModal(true)}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer mr-1"
                title="Buat Notifikasi / Tugas / Agenda Baru"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">Buat</span>
              </button>
            )}

            {unreadCount > 0 && (
              <button
                onClick={markAllNotificationsRead}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                title="Tandai semua sudah dibaca"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Tandai Dibaca</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto shrink-0 text-xs font-bold">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-xl transition-all shrink-0 cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-emerald-800 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Semua ({userNotifications.length})
          </button>
          <button
            onClick={() => setActiveFilter('unread')}
            className={`px-3 py-1.5 rounded-xl transition-all shrink-0 cursor-pointer ${
              activeFilter === 'unread'
                ? 'bg-emerald-800 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Belum Dibaca ({unreadCount})
          </button>
          <button
            onClick={() => setActiveFilter('tugas')}
            className={`px-3 py-1.5 rounded-xl transition-all shrink-0 cursor-pointer ${
              activeFilter === 'tugas'
                ? 'bg-emerald-800 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Tugas &amp; LKS
          </button>
          <button
            onClick={() => setActiveFilter('pesan_sekolah')}
            className={`px-3 py-1.5 rounded-xl transition-all shrink-0 cursor-pointer ${
              activeFilter === 'pesan_sekolah'
                ? 'bg-emerald-800 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Pesan Sekolah
          </button>
          <button
            onClick={() => setActiveFilter('agenda_karakter')}
            className={`px-3 py-1.5 rounded-xl transition-all shrink-0 cursor-pointer ${
              activeFilter === 'agenda_karakter'
                ? 'bg-emerald-800 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Agenda Karakter
          </button>
        </div>

        {/* Notifications List Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2.5 divide-y divide-slate-100">
          {filteredList.map(item => {
            const meta = getCategoryMeta(item.category);
            const Icon = meta.icon;

            return (
              <div
                key={item.id}
                onClick={() => handleNotificationClick(item)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer space-y-2.5 ${
                  item.isRead
                    ? 'bg-white border-slate-200/80 hover:border-slate-300'
                    : 'bg-emerald-50/40 border-emerald-200 hover:border-emerald-300 shadow-2xs'
                }`}
              >
                {/* Header item: Category tag, Sender & Time */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black border uppercase tracking-wider ${meta.badgeClass}`}
                    >
                      <Icon className="w-3 h-3" />
                      <span>{meta.label}</span>
                    </span>

                    {item.priority === 'high' && (
                      <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 text-[9px] font-black uppercase tracking-wider border border-rose-200">
                        Penting
                      </span>
                    )}

                    {!item.isRead && (
                      <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {item.time}
                    </span>
                    {canBroadcast && (
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          deleteNotification(item.id);
                        }}
                        className="text-slate-300 hover:text-rose-600 p-0.5 transition-colors"
                        title="Hapus Notifikasi"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Title & Content */}
                <div>
                  <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 leading-snug">
                    {item.title}
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {item.message}
                  </p>
                </div>

                {/* Event date/location box if applicable */}
                {item.eventDate && (
                  <div className="p-2.5 rounded-xl bg-amber-50/80 border border-amber-200 text-amber-950 space-y-1 text-[11px]">
                    <div className="flex items-center gap-1.5 font-bold">
                      <Calendar className="w-3.5 h-3.5 text-amber-700" />
                      <span>{item.eventDate}</span>
                    </div>
                    {item.eventLocation && (
                      <div className="flex items-center gap-1.5 text-slate-700 font-medium">
                        <MapPin className="w-3.5 h-3.5 text-amber-700" />
                        <span>{item.eventLocation}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Sender info & Action button */}
                <div className="pt-1.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 font-medium truncate max-w-[180px]">
                    Dari: <strong>{item.sender || 'Sistem Sholeh Cendekia'}</strong>
                  </span>

                  <span className="inline-flex items-center gap-1 font-bold text-emerald-800 hover:text-emerald-900">
                    <span>{item.actionLabel || 'Lihat Detail'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}

          {filteredList.length === 0 && (
            <div className="text-center py-12 space-y-2">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Bell className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-slate-700">Tidak ada notifikasi</p>
              <p className="text-[11px] text-slate-400">
                Semua tugas, pesan sekolah, dan agenda sudah Anda tinjau.
              </p>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[10px] text-slate-500 font-medium">
          Sholeh Cendekia Cimahi &bull; Notifikasi Real-Time Terintegrasi
        </div>
      </div>

      {/* Broadcast Modal for Teachers / DKM / Admin */}
      {showBroadcastModal && (
        <div className="fixed inset-0 z-60 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs sm:text-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <Send className="w-4 h-4 text-emerald-700" />
                <span>Kirim Notifikasi / Tugas / Agenda</span>
              </h3>
              <button
                onClick={() => setShowBroadcastModal(false)}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleBroadcastSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kategori Notifikasi
                </label>
                <select
                  value={broadcastCategory}
                  onChange={e => setBroadcastCategory(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                >
                  <option value="tugas">Tugas Pembiasaan / LKS</option>
                  <option value="pesan_sekolah">Pesan dari Sekolah / Guru PAI / DKM</option>
                  <option value="agenda_karakter">Agenda / Acara Karakter Akbar</option>
                  <option value="buku_kendali">Pengingat Buku Kendali</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Judul Notifikasi
                </label>
                <input
                  type="text"
                  placeholder="Misal: Tugas Hafalan Doa Harian Pekan Ini"
                  value={broadcastTitle}
                  onChange={e => setBroadcastTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Isi Pesan / Instruksi
                </label>
                <textarea
                  rows={3}
                  placeholder="Tuliskan detail instruksi tugas, pengumuman sekolah, atau detail acara..."
                  value={broadcastMsg}
                  onChange={e => setBroadcastMsg(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                  required
                />
              </div>

              {broadcastCategory === 'agenda_karakter' && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Waktu Pelaksanaan
                    </label>
                    <input
                      type="text"
                      placeholder="Ahad, 05.00 WIB"
                      value={broadcastEventDate}
                      onChange={e => setBroadcastEventDate(e.target.value)}
                      className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Lokasi Acara
                    </label>
                    <input
                      type="text"
                      placeholder="Masjid / Sekolah"
                      value={broadcastEventLoc}
                      onChange={e => setBroadcastEventLoc(e.target.value)}
                      className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tingkat Prioritas
                  </label>
                  <select
                    value={broadcastPriority}
                    onChange={e => setBroadcastPriority(e.target.value as any)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                  >
                    <option value="normal">Normal</option>
                    <option value="high">Tinggi (Penting)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Arahkan ke Menu
                  </label>
                  <select
                    value={broadcastActionTab}
                    onChange={e => setBroadcastActionTab(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                  >
                    <option value="buku_kendali">Buku Kendali</option>
                    <option value="belajar">Pusat Belajar &amp; LKS</option>
                    <option value="prestasi">Prestasi &amp; Lencana</option>
                    <option value="beranda">Beranda</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowBroadcastModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1.5 shadow-md"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Kirim Notifikasi</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
