import React, { useState, useEffect } from 'react';
import { Bell, BellRing, ShieldCheck, CheckCircle2, Sparkles, AlertCircle, Smartphone } from 'lucide-react';

interface PushNotificationManagerProps {
  compact?: boolean;
}

export const PushNotificationManager: React.FC<PushNotificationManagerProps> = ({
  compact = false
}) => {
  const [permission, setPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });

  const [settings, setSettings] = useState({
    dkmVerification: true,
    parentConfirmation: true,
    lksGrading: true,
    cityAnnouncements: true
  });

  const [testSent, setTestSent] = useState(false);

  const requestNotificationPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const res = await Notification.requestPermission();
        setPermission(res);
      } catch (err) {
        console.error('Failed to request notification permission:', err);
      }
    }
  };

  const handleTestPush = () => {
    setTestSent(true);
    setTimeout(() => setTestSent(false), 4000);

    // Try real browser notification if granted
    if (permission === 'granted' && typeof window !== 'undefined' && 'Notification' in window) {
      new Notification('Sholeh Cendekia Cimahi 🕌', {
        body: 'Alhamdulillah! Pengingat Sholat Subuh Berjamaah & Tilawah siap dikirim ke HP Anda.',
        icon: '/favicon.ico'
      });
    }
  };

  return (
    <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-emerald-100 text-emerald-800 font-bold shrink-0">
            <BellRing className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
              Notifikasi Push &amp; Pengingat Amalan HP
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              Dapatkan peringatan langsung saat DKM memverifikasi atau Orang Tua mengonfirmasi amalan.
            </p>
          </div>
        </div>

        {permission !== 'granted' ? (
          <button
            type="button"
            onClick={requestNotificationPermission}
            className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md transition-all shrink-0 cursor-pointer"
          >
            Aktifkan Push HP
          </button>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-black shrink-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-800" />
            Notifikasi Aktif
          </span>
        )}
      </div>

      {/* Toggles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs font-semibold text-slate-700">
        <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200 cursor-pointer hover:bg-slate-100/80 transition-colors">
          <span>Verifikasi Absensi DKM Masjid</span>
          <input
            type="checkbox"
            checked={settings.dkmVerification}
            onChange={e => setSettings({ ...settings, dkmVerification: e.target.checked })}
            className="w-4 h-4 text-emerald-800 rounded focus:ring-emerald-600"
          />
        </label>

        <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200 cursor-pointer hover:bg-slate-100/80 transition-colors">
          <span>Konfirmasi &amp; Catatan Orang Tua</span>
          <input
            type="checkbox"
            checked={settings.parentConfirmation}
            onChange={e => setSettings({ ...settings, parentConfirmation: e.target.checked })}
            className="w-4 h-4 text-emerald-800 rounded focus:ring-emerald-600"
          />
        </label>

        <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200 cursor-pointer hover:bg-slate-100/80 transition-colors">
          <span>Nilai &amp; Koreksi Modul LKS Karakter</span>
          <input
            type="checkbox"
            checked={settings.lksGrading}
            onChange={e => setSettings({ ...settings, lksGrading: e.target.checked })}
            className="w-4 h-4 text-emerald-800 rounded focus:ring-emerald-600"
          />
        </label>

        <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200 cursor-pointer hover:bg-slate-100/80 transition-colors">
          <span>Pengumuman Resmi Pemkot Cimahi</span>
          <input
            type="checkbox"
            checked={settings.cityAnnouncements}
            onChange={e => setSettings({ ...settings, cityAnnouncements: e.target.checked })}
            className="w-4 h-4 text-emerald-800 rounded focus:ring-emerald-600"
          />
        </label>
      </div>

      <div className="flex items-center justify-between pt-2 border-t border-slate-100">
        <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
          <Smartphone className="w-3.5 h-3.5 text-slate-400" />
          Kompatibel dengan browser Android Chrome, Safari, Edge &amp; Desktop
        </span>

        <button
          type="button"
          onClick={handleTestPush}
          className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Bell className="w-3.5 h-3.5 text-slate-600" />
          <span>Tes Notifikasi</span>
        </button>
      </div>

      {testSent && (
        <div className="p-3 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-900 font-bold text-xs flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>Notifikasi pengujian berhasil terkirim! Periksa baris notifikasi HP/Browser Anda.</span>
        </div>
      )}
    </div>
  );
};
