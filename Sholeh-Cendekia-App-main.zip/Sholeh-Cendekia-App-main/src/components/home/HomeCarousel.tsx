import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { CarouselSlide } from '../../types';
import {
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  HeartHandshake,
  BookOpen,
  Award,
  Newspaper,
  FileText,
  Sparkles
} from 'lucide-react';

interface HomeCarouselProps {
  onOpenArticle?: (type: 'nasehat' | 'berita') => void;
}

export const HomeCarousel: React.FC<HomeCarouselProps> = ({ onOpenArticle }) => {
  const { carouselSlides, setActiveTab, setIsGerakan5000InfoOpen } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartX = useRef<number | null>(null);

  const activeSlides = carouselSlides.filter(s => s.isActive);
  const slides = activeSlides.length > 0 ? activeSlides : carouselSlides;

  useEffect(() => {
    if (isPaused || slides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % slides.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [isPaused, slides.length]);

  const handlePrev = () => {
    setCurrentIndex(prev => (prev - 1 + slides.length) % slides.length);
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev + 1) % slides.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    setIsPaused(true);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (diff > 40) {
      handleNext();
    } else if (diff < -40) {
      handlePrev();
    }
    touchStartX.current = null;
    setIsPaused(false);
  };

  const handleSlideAction = (slide: CarouselSlide) => {
    switch (slide.actionType) {
      case 'gerakan_5000':
        setIsGerakan5000InfoOpen(true);
        break;
      case 'article_nasehat':
        if (onOpenArticle) onOpenArticle('nasehat');
        break;
      case 'article_berita':
        if (onOpenArticle) onOpenArticle('berita');
        break;
      case 'tab_progress':
        setActiveTab('prestasi');
        break;
      case 'tab_belajar':
        setActiveTab('belajar');
        break;
      default:
        break;
    }
  };

  const currentSlide = slides[currentIndex] || slides[0];

  return (
    <div
      className="relative rounded-3xl overflow-hidden shadow-lg border border-slate-200/80 group"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Slide Container */}
      <div className="relative min-h-[220px] sm:min-h-[260px] md:min-h-[280px] flex flex-col justify-end overflow-hidden">
        {/* Background Image with Gradient Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={currentSlide.imageUrl}
            alt={currentSlide.headline}
            className="w-full h-full object-cover object-center transform scale-100 group-hover:scale-105 transition-transform duration-700 ease-out"
          />
          {/* Gradient Overlay for high text legibility */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/60 to-slate-900/20" />
          <div className="absolute inset-0 bg-emerald-950/20 mix-blend-multiply" />
        </div>

        {/* Slide Content */}
        <div className="relative z-10 p-5 sm:p-7 md:p-8 space-y-2.5 max-w-2xl text-white">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md border border-white/25 text-[10px] sm:text-xs font-black tracking-wider uppercase text-amber-300">
            <Sparkles className="w-3 h-3" />
            <span>{currentSlide.kicker}</span>
          </div>

          <h3 className="text-lg sm:text-2xl md:text-3xl font-black text-white leading-tight tracking-tight drop-shadow-xs">
            {currentSlide.headline}
          </h3>

          <p className="text-xs sm:text-sm text-slate-200 line-clamp-2 max-w-xl drop-shadow-xs leading-relaxed font-medium">
            {currentSlide.content}
          </p>

          <div className="pt-2">
            <button
              type="button"
              onClick={() => handleSlideAction(currentSlide)}
              className="inline-flex items-center gap-2 px-4 py-2 sm:py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm shadow-md transition-all cursor-pointer hover:shadow-lg active:scale-95"
            >
              <span>{currentSlide.ctaLabel}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Navigation Arrows (Desktop) */}
        {slides.length > 1 && (
          <>
            <button
              type="button"
              onClick={handlePrev}
              className="hidden sm:flex absolute left-3 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 text-white items-center justify-center backdrop-blur-xs transition-colors cursor-pointer"
              aria-label="Previous slide"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 text-white items-center justify-center backdrop-blur-xs transition-colors cursor-pointer"
              aria-label="Next slide"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}

        {/* Dots Indicator */}
        {slides.length > 1 && (
          <div className="absolute bottom-3 right-4 z-20 flex items-center gap-1.5 bg-black/30 backdrop-blur-xs px-2.5 py-1 rounded-full border border-white/10">
            {slides.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                  currentIndex === idx ? 'w-5 bg-amber-400' : 'w-1.5 bg-white/50 hover:bg-white'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
