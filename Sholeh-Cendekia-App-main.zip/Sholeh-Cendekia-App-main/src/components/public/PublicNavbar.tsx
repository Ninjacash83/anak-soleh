import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Menu, X, ArrowRight, LayoutDashboard, LogIn } from 'lucide-react';

interface PublicNavbarProps {
  onScrollTo: (sectionId: string) => void;
}

export const PublicNavbar: React.FC<PublicNavbarProps> = ({ onScrollTo }) => {
  const { setActiveAppMode, isAuthenticated, appSettings } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navMenuItems = [
    { id: 'pilar-program', label: 'Program' },
    { id: 'papan-peringkat', label: 'Peringkat 🏆' },
    { id: 'ekosistem-5peran', label: 'Ekosistem' },
    { id: 'koleksi-lks', label: 'LKS' }
  ];

  const handleNavClick = (sectionId: string) => {
    onScrollTo(sectionId);
    setMobileMenuOpen(false);
  };

  const handleLoginClick = () => {
    setActiveAppMode('login');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  const handlePlatformClick = () => {
    setActiveAppMode('platform');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-[70px]">
          {/* Brand Logo & Name */}
          <button
            onClick={() => handleNavClick('cita-cita')}
            className="flex items-center gap-2.5 text-left group cursor-pointer"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden bg-emerald-950 flex items-center justify-center text-white font-black text-base sm:text-lg shadow-xs border border-emerald-700/40 group-hover:scale-103 transition-all shrink-0">
              {appSettings.logoImageUrl ? (
                <img
                  src={appSettings.logoImageUrl}
                  alt={appSettings.appName}
                  className="w-full h-full object-cover rounded-xl"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              ) : (
                <span>{appSettings.logoText || 'SC'}</span>
              )}
            </div>
            <div className="leading-tight">
              <span className="block font-black text-slate-900 tracking-tight text-sm sm:text-base">
                SHOLEH CENDEKIA
              </span>
              <span className="block text-[10px] sm:text-[11px] font-bold text-emerald-800 tracking-wider">
                CIMAHI
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8">
            {navMenuItems.map(item => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className="text-sm font-semibold text-slate-600 hover:text-emerald-800 transition-colors cursor-pointer py-1"
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right Action Button */}
          <div className="flex items-center gap-2 sm:gap-3">
            {isAuthenticated ? (
              <button
                onClick={handlePlatformClick}
                className="px-4 py-2 sm:py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Buka Dashboard</span>
              </button>
            ) : (
              <button
                onClick={handleLoginClick}
                className="px-4 py-2 sm:py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
              >
                <span>Masuk Platform</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-100 bg-white px-4 pt-3 pb-5 space-y-3 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex flex-col space-y-2">
            {navMenuItems.map(item => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className="text-left px-3 py-2 text-sm font-semibold text-slate-700 hover:text-emerald-800 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100">
            {isAuthenticated ? (
              <button
                onClick={handlePlatformClick}
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white text-sm font-bold rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Buka Dashboard</span>
              </button>
            ) : (
              <button
                onClick={handleLoginClick}
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white text-sm font-bold rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Masuk Platform</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
