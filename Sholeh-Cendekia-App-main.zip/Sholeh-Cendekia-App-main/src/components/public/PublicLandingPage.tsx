import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PublicHeroCarousel } from './PublicHeroCarousel';
import { LksDownloadPromptModal } from '../lks/LksDownloadPromptModal';
import { PwaInstallSection } from '../pwa/PwaInstallSection';
import { LeaderboardKebaikan } from '../leaderboard/LeaderboardKebaikan';
import { LearningMaterial } from '../../types';
import {
  Sunrise,
  Moon,
  BookOpen,
  Heart,
  GraduationCap,
  Users,
  Building2,
  ShieldCheck,
  HeartHandshake,
  ArrowRight,
  Smartphone,
  Download
} from 'lucide-react';

import heroImg from '../../assets/images/hero_sholeh_cendekia_1791045753143.jpg';
import lksFiqihCover from '../../assets/images/lks_fiqih_cover_1791045837300.jpg';
import lksMatematikaCover from '../../assets/images/lks_matematika_cover_1791045850736.jpg';
import lksAdabCover from '../../assets/images/lks_adab_cover_1791045867716.jpg';
import lksQuranCover from '../../assets/images/lks_quran_cover_1791045880627.jpg';

interface PublicLandingPageProps {
  onStartClick: () => void;
}

export const PublicLandingPage: React.FC<PublicLandingPageProps> = ({ onStartClick }) => {
  const { setIsGerakan5000InfoOpen, learningMaterials, appSettings } = useApp();
  const [downloadModalMaterial, setDownloadModalMaterial] = useState<LearningMaterial | null>(null);

  const heroHeadline = appSettings.heroHeadline || 'Setiap Orang Tua Mendambakan Anak Sholeh & Cendekia';
  const heroSubquote = appSettings.heroSubquote || '“Me-Ramadhan-kan 11 Bulan Lainnya”';
  const heroDescription = appSettings.heroDescription || 'Menjaga konsistensi sholat Subuh berjamaah, mengaji ba’da Maghrib, ketekunan belajar mandiri, dan adab kepedulian sosial sepanjang tahun melalui kolaborasi erat rumah, masjid, sekolah, dan kota.';
  const heroKicker = appSettings.heroKicker || 'Gerakan Pembinaan Karakter Anak Kota Cimahi';
  const heroButtonText = appSettings.heroButtonText || 'Masuk ke Platform Ekosistem';
  const statStudents = appSettings.statStudentsCount || '1.240+';
  const statMosques = appSettings.statMosquesCount || '48';
  const statSchools = appSettings.statSchoolsCount || '24';
  const statRate = appSettings.statVerificationRate || '92%';
  const gerakanHeadline = appSettings.gerakan5000Headline || 'Partisipasi masyarakat untuk mendukung keberlanjutan ekosistem.';
  const gerakanDesc = appSettings.gerakan5000Description || 'Gotong royong sukarela Rp5.000 warga Kota Cimahi untuk memastikan seluruh modul LKS tetap dapat diakses gratis oleh siswa dan mendukung operasional para ustadz di 342 masjid Maghrib Mengaji.';

  const lksDisplayList = [
    {
      id: 'lks-fiqih-sholat',
      title: 'LKS Fiqih Sholat Berjamaah & Adab di Masjid',
      jenjang: 'SD & SMP',
      kelas: 'Fase A-D',
      subject: 'Fiqih & Ibadah',
      tema: 'Adab Masjid & Sholat Subuh',
      cover: lksFiqihCover,
      description: 'Panduan tata cara sholat berjamaah, dzikir ba’da sholat, dan adab santun memuliakan masjid.'
    },
    {
      id: 'lks-matematika-5',
      title: 'LKS Matematika Kelas 5 & Karakter Amanah',
      jenjang: 'SD',
      kelas: 'Kelas 5',
      subject: 'Matematika Karakter',
      tema: 'Kejujuran & Ketepatan Hitung',
      cover: lksMatematikaCover,
      description: 'Literasi berhitung, geometri, dan logika berbasis kejujuran dan amanah dalam kehidupan sehari-hari.'
    },
    {
      id: 'lks-adab-remaja',
      title: 'LKS Adab Pergaulan Remaja & Literasi Digital',
      jenjang: 'SMP & SMA',
      kelas: 'Fase D-E',
      subject: 'Akhlak & Digital',
      tema: 'Etika Pergaulan & Medsos Sehat',
      cover: lksAdabCover,
      description: 'Pedoman beretika di dunia nyata dan media sosial sesuai tuntunan syariat dan nilai kebangsaan.'
    },
    {
      id: 'lks-tajwid-quran',
      title: 'LKS Al-Qur’an, Tajwid Praktis & Doa Harian',
      jenjang: 'Semua Tingkat',
      kelas: 'Tingkat Dasar-Lanjut',
      subject: 'Al-Qur’an & Hadits',
      tema: 'Tahsin Maghrib Mengaji',
      cover: lksQuranCover,
      description: 'Modul pendamping Maghrib Mengaji dengan kaidah tajwid mudah dan kumpulan doa penting harian.'
    }
  ];

  const handleDownloadClick = (item: typeof lksDisplayList[0]) => {
    // Find matching real material or build a compliant LearningMaterial object
    const matched = learningMaterials.find(
      m => m.title.toLowerCase().includes(item.subject.toLowerCase()) || m.id === item.id
    );

    if (matched) {
      setDownloadModalMaterial(matched);
    } else {
      setDownloadModalMaterial({
        id: item.id,
        title: item.title,
        type: 'lks',
        jenjang: item.jenjang.includes('SD') ? 'SD' : 'SMP',
        kelas: item.kelas,
        subject: item.subject,
        tema: item.tema,
        category: 'Ibadah & Karakter',
        estimatedTime: '20 Menit',
        durationOrPages: '4 Halaman',
        description: item.description,
        source: 'Sholeh Cendekia Cimahi & Masagi',
        thumbnail: item.cover,
        digitalAvailable: true,
        pdfAvailable: true,
        summaryContent: item.description
      });
    }
  };

  return (
    <div className="space-y-16 sm:space-y-24 pb-16">
      {/* ================= SECTION 1 — CITA-CITA & HERO ================= */}
      <section id="cita-cita" className="pt-6 sm:pt-12 max-w-6xl mx-auto px-4 scroll-mt-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Headline & Value Proposition */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-emerald-800 tracking-wide uppercase">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              <span>{heroKicker}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15]">
              {heroHeadline}
            </h1>

            <div className="space-y-3">
              <p className="text-base sm:text-lg font-bold text-slate-800 italic">
                {heroSubquote}
              </p>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl">
                {heroDescription}
              </p>
            </div>

            {/* CTA Button */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={onStartClick}
                className="px-7 py-3.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-sm sm:text-base shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
              >
                <span>{heroButtonText}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Trust Indicators (MVP Simulation Metrics) */}
            <div className="pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                  Data Simulasi MVP
                </span>
                <span className="text-[10px] text-slate-600 font-bold">Model Percontohan Ekosistem</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
                <div>
                  <div className="text-xl sm:text-2xl font-black text-slate-900">{statStudents}</div>
                  <div className="text-[11px] text-slate-500 font-medium">Siswa Terhubung</div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-slate-900">{statMosques}</div>
                  <div className="text-[11px] text-slate-500 font-medium">Masjid DKM Aktif</div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-slate-900">{statSchools}</div>
                  <div className="text-[11px] text-slate-500 font-medium">Sekolah Terpadu</div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-emerald-800">{statRate}</div>
                  <div className="text-[11px] text-slate-500 font-medium">Aktivitas Terverifikasi</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Asset */}
          <div className="lg:col-span-5 space-y-4">
            <div className="relative rounded-3xl overflow-hidden shadow-lg border border-slate-200/80 bg-slate-100 group">
              <img
                src={heroImg}
                alt="Anak-anak sholeh Kota Cimahi belajar bersama dengan ceria"
                className="w-full h-auto object-cover aspect-[4/3] group-hover:scale-102 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-4 left-4 right-4 text-white pointer-events-none">
                <p className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                  Sholeh Cendekia Cimahi
                </p>
                <p className="text-sm font-extrabold text-white mt-0.5">
                  Sinergi Orang Tua · Guru · DKM Masjid
                </p>
              </div>
            </div>

            {/* Verified BPS Official City Statistics Card */}
            <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-emerald-950 uppercase tracking-wider text-[10px] bg-emerald-200 px-2 py-0.5 rounded-md">
                  Sumber Data Resmi BPS Kota Cimahi (2024/2025)
                </span>
                <span className="text-[10px] text-emerald-800 font-bold">Profil Pendidikan Kota</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center pt-1 font-semibold text-slate-800">
                <div className="p-2 bg-white rounded-xl border border-emerald-100">
                  <span className="block font-black text-slate-900 text-sm">119 SD</span>
                  <span className="text-[10px] text-slate-500">46.636 Siswa &bull; 2.069 Guru</span>
                </div>
                <div className="p-2 bg-white rounded-xl border border-emerald-100">
                  <span className="block font-black text-slate-900 text-sm">19 SMA</span>
                  <span className="text-[10px] text-slate-500">12.105 Siswa &bull; 648 Guru</span>
                </div>
                <div className="p-2 bg-white rounded-xl border border-emerald-100">
                  <span className="block font-black text-slate-900 text-sm">22 SMK</span>
                  <span className="text-[10px] text-slate-500">16.409 Siswa &bull; 861 Guru</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= SECTION 2 — VISUAL CAROUSEL ================= */}
      <PublicHeroCarousel />

      {/* ================= SECTION 3 — 4 PILAR PROGRAM ================= */}
      <section id="pilar-program" className="max-w-6xl mx-auto px-4 scroll-mt-24 space-y-8">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
            Pondasi Kebiasaan Baik
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            4 Pilar Pembentukan Karakter Siswa
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Aktivitas harian yang dicatat melalui Buku Kendali Digital dan diverifikasi bersama oleh Orang Tua dan DKM Masjid.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Pilar 1 */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4 hover:border-emerald-300 transition-colors">
            <div className="w-11 h-11 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <Sunrise className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-amber-800 tracking-wider">Pilar 1</div>
              <h3 className="text-base font-black text-slate-900 mt-0.5">Subuh Berjamaah</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Membiasakan bangun pagi dan melangkahkan kaki ke masjid terdekat bersama keluarga dan kawan sebaya.
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 text-[11px] font-semibold text-slate-500">
              Jadwal: 04.30 – 05.15 WIB
            </div>
          </div>

          {/* Pilar 2 */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4 hover:border-emerald-300 transition-colors">
            <div className="w-11 h-11 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-indigo-800 tracking-wider">Pilar 2</div>
              <h3 className="text-base font-black text-slate-900 mt-0.5">Maghrib Mengaji</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Menghidupkan masjid di waktu senja dengan tadarus Al-Qur’an, tahsin, tajwid, dan bimbingan akhlak dari ustadz.
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 text-[11px] font-semibold text-slate-500">
              Jadwal: 18.15 – 19.15 WIB
            </div>
          </div>

          {/* Pilar 3 */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4 hover:border-emerald-300 transition-colors">
            <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-emerald-800 tracking-wider">Pilar 3</div>
              <h3 className="text-base font-black text-slate-900 mt-0.5">Tilawah &amp; Belajar</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Penyelesaian LKS digital/cetak dan penambahan wawasan ilmu pengetahuan umum bernafaskan nilai Islam.
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 text-[11px] font-semibold text-slate-500">
              Jadwal: Harian Terstruktur
            </div>
          </div>

          {/* Pilar 4 */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4 hover:border-emerald-300 transition-colors">
            <div className="w-11 h-11 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase text-rose-800 tracking-wider">Pilar 4</div>
              <h3 className="text-base font-black text-slate-900 mt-0.5">Kebaikan &amp; Kepedulian</h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Berbakti kepada orang tua, membantu tetangga, infak shubuh, dan merawat kebersihan lingkungan sekitar.
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 text-[11px] font-semibold text-slate-500">
              Jadwal: Sepanjang Hari
            </div>
          </div>
        </div>
      </section>

      {/* ================= SECTION 4 — EKOSISTEM 5 PERAN ================= */}
      <section id="ekosistem-5peran" className="max-w-6xl mx-auto px-4 scroll-mt-24 space-y-8">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
            Kolaborasi Terpadu
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Ekosistem 5 Peran Pembinaan
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Pendidikan karakter bukan tanggung jawab satu pihak, melainkan sinergi erat rumah, masjid, sekolah, dan pemerintah kota.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-sm text-slate-900">1. Siswa / Santri</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Mencatat amalan ibadah harian, mengerjakan LKS di HP/cetak, dan mengumpulkan lencana prestasi karakter.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-800 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-sm text-slate-900">2. Orang Tua</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Memantau anak-anaknya, memberikan konfirmasi Buku Kendali, serta menuliskan catatan doa dan motivasi.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-sm text-slate-900">3. DKM Masjid</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Memverifikasi kehadiran Subuh &amp; Maghrib Mengaji untuk santri yang terdaftar di masjid masing-masing.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-800 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-sm text-slate-900">4. Guru Agama</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Mengintegrasikan Buku Kendali dengan nilai rapor PAI dan memberikan bimbingan adab di sekolah.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-800 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-sm text-slate-900">5. Pemkot Cimahi</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Monitoring capaian wilayah se-Cimahi, evaluasi kebijakan karakter, dan fasilitasi apresiasi santri.
            </p>
          </div>
        </div>
      </section>

      {/* ================= SECTION 5 — MODUL & LKS ================= */}
      <section id="koleksi-lks" className="max-w-6xl mx-auto px-4 scroll-mt-24 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
              Pusat Bahan Belajar
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              Modul &amp; LKS Karakter Siap Pakai
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Dapat dikerjakan langsung di smartphone atau diunduh untuk dicetak mandiri.
            </p>
          </div>

          <button
            onClick={onStartClick}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Buka Semua di Platform</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {lksDisplayList.map(lks => (
            <div
              key={lks.id}
              className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden flex flex-col justify-between hover:shadow-md transition-shadow group"
            >
              <div>
                {/* Visual Cover Image */}
                <div className="relative aspect-[4/3] bg-slate-100 overflow-hidden">
                  <img
                    src={lks.cover}
                    alt={lks.title}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-slate-950/70 text-white text-[10px] font-bold backdrop-blur-xs">
                    {lks.jenjang}
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <div className="text-[11px] font-bold text-emerald-800">
                    {lks.subject}
                  </div>
                  <h3 className="font-extrabold text-slate-900 text-sm leading-snug">
                    {lks.title}
                  </h3>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {lks.description}
                  </p>
                </div>
              </div>

              <div className="p-4 pt-0 border-t border-slate-100 flex items-center gap-2 mt-3">
                <button
                  onClick={onStartClick}
                  className="flex-1 py-2 px-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Kerjakan di HP</span>
                </button>
                <button
                  onClick={() => handleDownloadClick(lks)}
                  className="flex-1 py-2 px-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ================= SECTION PWA INSTALLATION GUIDE ================= */}
      <section id="pwa-install-guide" className="max-w-6xl mx-auto px-4 scroll-mt-24">
        <PwaInstallSection />
      </section>

      {/* ================= SECTION PAPAN PERINGKAT KEBAIKAN ================= */}
      <section id="papan-peringkat" className="max-w-6xl mx-auto px-4 scroll-mt-24">
        <LeaderboardKebaikan />
      </section>

      {/* ================= SECTION 6 — GERAKAN 5.000 KEBERLANJUTAN ================= */}
      <section id="gerakan-5000" className="max-w-5xl mx-auto px-4 scroll-mt-24">
        <div className="rounded-3xl bg-slate-900 text-white p-6 sm:p-10 shadow-lg space-y-6 relative overflow-hidden border border-slate-800">
          <div className="relative z-10 space-y-4 max-w-2xl">
            <div className="text-xs font-bold text-amber-400 tracking-wide uppercase">
              Keberlanjutan Ekosistem
            </div>

            <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
              {gerakanHeadline}
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {gerakanDesc}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-xs font-bold text-white">Modul LKS Gratis</div>
                <div className="text-[11px] text-slate-400">Menjamin akses belajar mandiri tanpa beban biaya bagi seluruh siswa.</div>
              </div>
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-xs font-bold text-white">Apresiasi Guru Ngaji</div>
                <div className="text-[11px] text-slate-400">Mendukung dedikasi para ustadz pengajar di program Maghrib Mengaji.</div>
              </div>
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                <div className="text-xs font-bold text-white">Keandalan Platform</div>
                <div className="text-[11px] text-slate-400">Pemeliharaan server dan integrasi data amalan harian terpercaya.</div>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={() => setIsGerakan5000InfoOpen(true)}
                className="px-6 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
              >
                <HeartHandshake className="w-4 h-4 text-emerald-800" />
                <span>Pelajari Detail Partisipasi Gotong Royong</span>
              </button>
              <span className="text-[11px] text-slate-400 italic">
                *Bersifat sukarela. Siswa tetap dapat mengunduh dan belajar tanpa syarat.
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ================= SECTION 7 — DEVELOPER & KOLABORATOR ================= */}
      <section id="developer-kolaborator" className="max-w-6xl mx-auto px-4 scroll-mt-24 space-y-8">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
            Sinergi &amp; Kolaborasi
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Pengembang &amp; Kolaborator Ekosistem
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Platform Sholeh Cendekia Cimahi terwujud atas inisiasi dan kolaborasi multipihak untuk memajukan pendidikan karakter islami.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Developer Card */}
          <div className="p-6 rounded-2xl bg-emerald-900 text-white shadow-sm space-y-4 lg:col-span-1 border border-emerald-800 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="text-[11px] font-bold uppercase text-emerald-300 tracking-wider">
                Pengembang Aplikasi
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                ITEC &amp; PT Masagi Cendekia Berkah
              </h3>
              <p className="text-xs text-emerald-100/80 leading-relaxed">
                Pengembang arsitektur platform digital, sistem buku kendali terintegrasi, pilar kurikulum pembiasaan, serta penyedia modul LKS digital &amp; cetak.
              </p>
            </div>

            <div className="pt-4 border-t border-emerald-800/80 flex items-center justify-between text-xs text-emerald-200 font-semibold">
              <span>Official Tech &amp; Content Developer</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            </div>
          </div>

          {/* Kolaborator Grid */}
          <div className="lg:col-span-2 p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">Lembaga Kolaborator</div>
                <h3 className="text-base font-black text-slate-900">7 Lembaga Mitra Utama Kota Cimahi</h3>
              </div>
              <ShieldCheck className="w-5 h-5 text-emerald-800" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {[
                { name: 'Pemkot Cimahi', role: 'Payung Kebijakan & Pembina Daerah', icon: '🏛️' },
                { name: 'Dinas Pendidikan Kota Cimahi', role: 'Integrasi Kurikulum & Rapor PAI', icon: '🎓' },
                { name: 'Dinas Sosial Kota Cimahi', role: 'Pemberdayaan & Karakter Inklusif', icon: '🤝' },
                { name: 'DMI (Dewan Masjid Indonesia) Cimahi', role: 'Jejaring 342 DKM & Maghrib Mengaji', icon: '🕌' },
                { name: 'MUI Kota Cimahi', role: 'Pedoman Syariah & Karakter Akhlak', icon: '📜' },
                { name: 'BAZNAS Kota Cimahi', role: 'Akuntabilitas & Dukungan Beasiswa/LKS', icon: '⚖️' },
                { name: 'ICMI Orda Cimahi', role: 'Konseptor Keilmuan & Cendekia Islam', icon: '💡' }
              ].map(k => (
                <div key={k.name} className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{k.icon}</span>
                    <span className="font-bold text-xs text-slate-900">{k.name}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 pl-5">{k.role}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ================= SECTION 8 — AJAKAN BERGABUNG ================= */}
      <section id="panduan-bergabung" className="max-w-4xl mx-auto px-4 scroll-mt-24 text-center space-y-6">
        <div className="p-8 sm:p-12 rounded-3xl bg-slate-900 text-white shadow-md space-y-5">
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Mari Bergerak Bersama Membangun Karakter Generasi Cimahi
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
            Pilih peran Anda untuk mengakses Buku Kendali harian, verifikasi ibadah, dan modul pembelajaran interaktif.
          </p>

          <div className="pt-2">
            <button
              onClick={onStartClick}
              className="px-8 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm sm:text-base shadow-xs transition-all inline-flex items-center gap-2 cursor-pointer active:scale-98"
            >
              <span>Masuk Platform Sholeh Cendekia</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Contextual LKS Download / Print Prompt Modal */}
      <LksDownloadPromptModal
        material={downloadModalMaterial}
        isOpen={!!downloadModalMaterial}
        onClose={() => setDownloadModalMaterial(null)}
      />
    </div>
  );
};
