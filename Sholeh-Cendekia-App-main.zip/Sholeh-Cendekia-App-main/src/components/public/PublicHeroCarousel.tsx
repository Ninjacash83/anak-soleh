import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

import slide1Img from '../../assets/images/carousel_maghrib_1791045767962.jpg';
import slide2Img from '../../assets/images/carousel_kendali_1791045781131.jpg';
import slide3Img from '../../assets/images/carousel_lks_study_1791045794274.jpg';
import slide4Img from '../../assets/images/carousel_ecosystem_1791045807942.jpg';
import slide5Img from '../../assets/images/carousel_social_1791045822549.jpg';

interface SlideItem {
  id: string;
  tag: string;
  title: string;
  subtitle: string;
  image: string;
  alt: string;
}

const CAROUSEL_SLIDES: SlideItem[] = [
  {
    id: 'gerakan',
    tag: 'GERAKAN PEMBIASAAN',
    title: '“Me-Ramadhan-kan 11 Bulan Lainnya”',
    subtitle: 'Menghidupkan sholat Subuh berjamaah dan tadarus Maghrib Mengaji sepanjang tahun bersama keluarga dan masjid terdekat.',
    image: slide1Img,
    alt: 'Keluarga mengaji bersama di masjid'
  },
  {
    id: 'kendali',
    tag: 'BUKU KENDALI DIGITAL',
    title: '“Kebiasaan Baik, Dicatat. Karakter, Dibentuk.”',
    subtitle: 'Pencatatan amalan harian praktis dari smartphone, terverifikasi otomatis antara orang tua, guru, dan pengurus DKM.',
    image: slide2Img,
    alt: 'Siswa mencatat kebiasaan baik di HP'
  },
  {
    id: 'lks',
    tag: 'MODUL & LKS INTERAKTIF',
    title: '“Belajar Lebih Mudah, Langsung dari HP.”',
    subtitle: 'Modul Fiqih Ibadah, Matematika Karakter, dan Adab Islami siap pakai interaktif di ponsel atau diunduh cetak.',
    image: slide3Img,
    alt: 'Modul LKS digital dan tablet belajar'
  },
  {
    id: 'ekosistem',
    tag: 'KOLABORASI 5 PILAR',
    title: '“Anak • Keluarga • Masjid • Sekolah • Pemerintah”',
    subtitle: 'Sinergi terpadu lima pilar pendidikan Kota Cimahi mewujudkan ekosistem tumbuh kembang anak yang berilmu dan berakhlak.',
    image: slide4Img,
    alt: 'Komunitas ekosistem 5 peran Kota Cimahi'
  },
  {
    id: 'gerakan5000',
    tag: 'KEBERLANJUTAN EKOSISTEM',
    title: '“Rp5.000 dari kita, menjaga kesempatan belajar bersama.”',
    subtitle: 'Partisipasi gotong royong sukarela warga Cimahi untuk menjaga ketersediaan modul gratis dan apresiasi guru ngaji.',
    image: slide5Img,
    alt: 'Anak-anak belajar bersama dengan ceria'
  }
];

export const PublicHeroCarousel: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartXRef = useRef<number | null>(null);

  // Auto-play timer
  useEffect(() => {
    if (isPaused) return;

    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % CAROUSEL_SLIDES.length);
    }, 5500);

    return () => clearInterval(timer);
  }, [isPaused]);

  const handlePrev = () => {
    setCurrentIndex(prev => (prev === 0 ? CAROUSEL_SLIDES.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev + 1) % CAROUSEL_SLIDES.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
    setIsPaused(true);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const deltaX = touchStartXRef.current - touchEndX;

    if (deltaX > 45) {
      handleNext();
    } else if (deltaX < -45) {
      handlePrev();
    }

    touchStartXRef.current = null;
    setIsPaused(false);
  };

  return (
    <section className="max-w-6xl mx-auto px-4">
      <div
        className="relative rounded-3xl overflow-hidden bg-slate-950 shadow-md border border-slate-200/80 group"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Slides Container */}
        <div className="relative h-[320px] sm:h-[360px] md:h-[390px] w-full overflow-hidden">
          {CAROUSEL_SLIDES.map((slide, idx) => {
            const isActive = idx === currentIndex;
            return (
              <div
                key={slide.id}
                className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
                  isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
                }`}
                aria-hidden={!isActive}
              >
                {/* Background Image */}
                <img
                  src={slide.image}
                  alt={slide.alt}
                  className="w-full h-full object-cover object-center transform scale-100 group-hover:scale-102 transition-transform duration-1000"
                />

                {/* Scrim Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-slate-950/90 via-slate-950/60 to-slate-950/20 md:to-transparent" />

                {/* Content Overlay */}
                <div className="absolute inset-0 flex flex-col justify-end md:justify-center p-6 sm:p-10 md:p-12 max-w-2xl text-white">
                  <div className="space-y-2 sm:space-y-3">
                    <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold tracking-wider text-amber-300 uppercase">
                      <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                      <span>{slide.tag}</span>
                    </div>

                    <h3 className="text-xl sm:text-2xl md:text-3xl font-black tracking-tight leading-snug sm:leading-tight text-white drop-shadow-sm">
                      {slide.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-xl line-clamp-3 sm:line-clamp-none font-medium">
                      {slide.subtitle}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Desktop Navigation Arrows */}
        <button
          onClick={handlePrev}
          className="hidden sm:flex absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-slate-950/50 hover:bg-slate-950/80 text-white backdrop-blur-xs items-center justify-center transition-all opacity-80 group-hover:opacity-100 cursor-pointer border border-white/20"
          aria-label="Slide sebelumnya"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          onClick={handleNext}
          className="hidden sm:flex absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-slate-950/50 hover:bg-slate-950/80 text-white backdrop-blur-xs items-center justify-center transition-all opacity-80 group-hover:opacity-100 cursor-pointer border border-white/20"
          aria-label="Slide berikutnya"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Pagination Indicators */}
        <div className="absolute bottom-4 left-0 right-0 z-20 flex items-center justify-center gap-2">
          {CAROUSEL_SLIDES.map((slide, idx) => {
            const isActive = idx === currentIndex;
            return (
              <button
                key={slide.id}
                onClick={() => setCurrentIndex(idx)}
                className={`transition-all rounded-full cursor-pointer ${
                  isActive
                    ? 'w-7 h-2 bg-amber-400'
                    : 'w-2 h-2 bg-white/50 hover:bg-white/80'
                }`}
                aria-label={`Lihat slide ${idx + 1}: ${slide.tag}`}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
};
