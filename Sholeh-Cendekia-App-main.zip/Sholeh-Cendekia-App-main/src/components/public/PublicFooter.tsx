import React from 'react';
import { useApp } from '../../context/AppContext';
import { Heart, Globe, ArrowRight, ShieldCheck, HeartHandshake, Smartphone, ArrowUp } from 'lucide-react';

interface PublicFooterProps {
  onScrollTo: (sectionId: string) => void;
}

export const PublicFooter: React.FC<PublicFooterProps> = ({ onScrollTo }) => {
  const { setActiveAppMode, setIsGerakan5000InfoOpen, appSettings } = useApp();

  const goToLogin = () => {
    setActiveAppMode('login');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white font-black text-base">
                {appSettings.logoText || 'SC'}
              </div>
              <span className="font-black text-white text-base tracking-tight">
                {appSettings.appName} {appSettings.appBadge}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {appSettings.appTagline}
            </p>
          </div>

          {/* Col 2: Navigasi Cepat */}
          <div className="space-y-2">
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider">
              Navigasi Halaman
            </h4>
            <ul className="space-y-1.5 text-[11px]">
              <li>
                <button
                  onClick={() => onScrollTo('cita-cita')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Cita-Cita & Visi Program
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollTo('pilar-program')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  4 Pilar Kebiasaan Baik
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollTo('ekosistem-5peran')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Ekosistem 5 Peran
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollTo('koleksi-lks')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Modul &amp; LKS Interaktif
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollTo('pwa-install-guide')}
                  className="hover:text-amber-300 text-amber-400 font-bold transition-colors flex items-center gap-1"
                >
                  <Smartphone className="w-3 h-3" />
                  <span>Cara Install Aplikasi HP (PWA)</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Akses Platform Peran */}
          <div className="space-y-2">
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider">
              5 Peran Ekosistem
            </h4>
            <ul className="space-y-1.5 text-[11px]">
              <li>
                <button onClick={goToLogin} className="hover:text-emerald-400 transition-colors">
                  Akses Siswa / Santri
                </button>
              </li>
              <li>
                <button onClick={goToLogin} className="hover:text-emerald-400 transition-colors">
                  Akses Orang Tua / Wali
                </button>
              </li>
              <li>
                <button onClick={goToLogin} className="hover:text-emerald-400 transition-colors">
                  Akses DKM & Guru Mengaji
                </button>
              </li>
              <li>
                <button onClick={goToLogin} className="hover:text-emerald-400 transition-colors">
                  Akses Guru Agama (PAI)
                </button>
              </li>
              <li>
                <button onClick={goToLogin} className="hover:text-emerald-400 transition-colors">
                  Akses Pemkot Cimahi
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Gerakan 5.000 & Hubungi */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider">
              Gerakan Cimahi Pintar
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Partisipasi sukarela Rp5.000 untuk menjaga ketersediaan materi dan ekosistem anak sholeh se-Cimahi.
            </p>
            <button
              onClick={() => setIsGerakan5000InfoOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded-lg text-xs font-bold border border-emerald-800 transition-colors"
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>Detail Gerakan 5.000</span>
            </button>
          </div>
        </div>

        {/* Collaborators & Developer Banner */}
        <div className="pt-6 border-t border-slate-900 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-white font-extrabold text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>Developer Aplikasi</span>
            </div>
            <p className="text-xs text-slate-300 font-semibold">
              ITEC &amp; PT Masagi Cendekia Berkah
            </p>
            <p className="text-[11px] text-slate-400">
              Pengembang arsitektur platform digital, sistem buku kendali terintegrasi, dan modul LKS interaktif.
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-white font-extrabold text-xs">
              <span className="w-2 h-2 rounded-full bg-teal-400"></span>
              <span>Kolaborator Ekosistem Kota Cimahi</span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[
                'Pemkot Cimahi',
                'Dinas Pendidikan',
                'Dinas Sosial',
                'DMI Kota Cimahi',
                'MUI Kota Cimahi',
                'BAZNAS Kota Cimahi',
                'ICMI Orda Cimahi'
              ].map(c => (
                <span
                  key={c}
                  className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-[10px] text-slate-300 font-medium"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>
            &copy; {new Date().getFullYear()} Sholeh Cendekia Cimahi &bull; Dikembangkan oleh <strong>ITEC &amp; Masagi Cendekia Berkah</strong> bersama Pemkot Cimahi &amp; Para Kolaborator.
          </p>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Integrasi Karakter Berkelanjutan</span>
            </div>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-emerald-950 text-emerald-400 font-bold border border-emerald-800/60 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <ArrowUp className="w-3.5 h-3.5 text-amber-300" />
              <span>Kembali ke Atas</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
