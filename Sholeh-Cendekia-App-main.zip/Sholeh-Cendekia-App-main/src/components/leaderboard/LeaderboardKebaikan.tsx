import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Trophy,
  Award,
  Flame,
  Building2,
  GraduationCap,
  Sparkles,
  Search,
  Filter,
  Users
} from 'lucide-react';

interface LeaderboardKebaikanProps {
  className?: string;
  compact?: boolean;
}

export const LeaderboardKebaikan: React.FC<LeaderboardKebaikanProps> = ({
  className = '',
  compact = false
}) => {
  const { students, schools, mosques, cityMetrics } = useApp();

  const [activeTab, setActiveTab] = useState<'siswa' | 'sekolah' | 'masjid' | 'kecamatan'>('siswa');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Top Students calculation
  const topStudents = useMemo(() => {
    let filtered = [...students];

    if (selectedDistrict !== 'all') {
      filtered = filtered.filter(s => s.kecamatan === selectedDistrict);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      filtered = filtered.filter(
        s =>
          s.name.toLowerCase().includes(q) ||
          s.schoolName.toLowerCase().includes(q) ||
          s.mosqueName.toLowerCase().includes(q)
      );
    }

    // Sort by total completed activities + streak days + character score
    return filtered
      .sort((a, b) => {
        const scoreA = a.totalCompletedActivities * 10 + a.streakDays * 5 + a.characterScore;
        const scoreB = b.totalCompletedActivities * 10 + b.streakDays * 5 + b.characterScore;
        return scoreB - scoreA;
      })
      .slice(0, compact ? 5 : 20);
  }, [students, selectedDistrict, searchTerm, compact]);

  // Top Schools calculation
  const topSchools = useMemo(() => {
    let filtered = [...schools];

    if (selectedDistrict !== 'all') {
      filtered = filtered.filter(s => s.kecamatan === selectedDistrict);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      filtered = filtered.filter(s => s.name.toLowerCase().includes(q));
    }

    return filtered
      .sort((a, b) => b.totalStudents - a.totalStudents)
      .slice(0, compact ? 5 : 15);
  }, [schools, selectedDistrict, searchTerm, compact]);

  // Top Mosques calculation
  const topMosques = useMemo(() => {
    let filtered = [...mosques];

    if (selectedDistrict !== 'all') {
      filtered = filtered.filter(m => m.kecamatan === selectedDistrict);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      filtered = filtered.filter(m => m.name.toLowerCase().includes(q));
    }

    return filtered
      .sort((a, b) => b.activeStudentsCount - a.activeStudentsCount)
      .slice(0, compact ? 5 : 15);
  }, [mosques, selectedDistrict, searchTerm, compact]);

  // District Rankings
  const districtRankings = useMemo(() => {
    const districts = [
      {
        name: 'Cimahi Tengah',
        icon: '🕌',
        activeStudents: 1420,
        subuhRate: '94.2%',
        totalPoints: 18450,
        activeSchools: 12,
        activeMosques: 24
      },
      {
        name: 'Cimahi Utara',
        icon: '🌿',
        activeStudents: 1280,
        subuhRate: '92.8%',
        totalPoints: 16900,
        activeSchools: 10,
        activeMosques: 21
      },
      {
        name: 'Cimahi Selatan',
        icon: '✨',
        activeStudents: 1140,
        subuhRate: '91.5%',
        totalPoints: 15320,
        activeSchools: 9,
        activeMosques: 18
      }
    ];

    return districts.sort((a, b) => b.totalPoints - a.totalPoints);
  }, []);

  const getRankBadge = (rank: number) => {
    if (rank === 1) {
      return (
        <span className="w-7 h-7 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center shadow-md border border-amber-300">
          🥇 1
        </span>
      );
    }
    if (rank === 2) {
      return (
        <span className="w-7 h-7 rounded-full bg-slate-300 text-slate-900 font-black text-xs flex items-center justify-center shadow-2xs border border-slate-200">
          🥈 2
        </span>
      );
    }
    if (rank === 3) {
      return (
        <span className="w-7 h-7 rounded-full bg-amber-700 text-white font-black text-xs flex items-center justify-center shadow-2xs border border-amber-800">
          🥉 3
        </span>
      );
    }
    return (
      <span className="w-7 h-7 rounded-full bg-slate-100 text-slate-600 font-bold text-xs flex items-center justify-center border border-slate-200">
        {rank}
      </span>
    );
  };

  return (
    <div
      className={`bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden ${className}`}
    >
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 p-5 sm:p-6 text-white relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-6">
          <Trophy className="w-48 h-48 text-white" />
        </div>

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                <Trophy className="w-3.5 h-3.5" />
                <span>Apresiasi Karakter Sholeh Cimahi</span>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white border border-white/30 text-[10px] font-black uppercase tracking-wider">
                Data Simulasi MVP
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black tracking-tight text-white flex items-center gap-2">
              Papan Peringkat Kebaikan &amp; Istiqomah
            </h2>
            <p className="text-xs text-emerald-100/90 max-w-xl font-medium">
              Kompetisi sehat dalam memperbanyak amalan sholeh, Subuh berjamaah, tilawah Al-Qur&apos;an, dan pengisian Buku Kendali Digital se-Kota Cimahi.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0 bg-white/10 backdrop-blur-md p-2.5 rounded-2xl border border-white/15 text-center">
            <div>
              <p className="text-[10px] text-emerald-200 font-medium">Total Siswa Binaan</p>
              <p className="text-base font-black text-amber-300">
                {cityMetrics.coverage.totalStudents.toLocaleString('id-ID')}
              </p>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div>
              <p className="text-[10px] text-emerald-200 font-medium">Siswa Aktif</p>
              <p className="text-base font-black text-white">
                {cityMetrics.coverage.activeStudents.toLocaleString('id-ID')}
              </p>
            </div>
          </div>
        </div>

        {/* Tab Selection Bar */}
        <div className="mt-5 flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-bold">
          <button
            onClick={() => setActiveTab('siswa')}
            className={`px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'siswa'
                ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Siswa Top Streak</span>
          </button>

          <button
            onClick={() => setActiveTab('sekolah')}
            className={`px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'sekolah'
                ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Sekolah Istiqomah</span>
          </button>

          <button
            onClick={() => setActiveTab('masjid')}
            className={`px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'masjid'
                ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Masjid Teraktif DKM</span>
          </button>

          <button
            onClick={() => setActiveTab('kecamatan')}
            className={`px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'kecamatan'
                ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Peringkat Kecamatan</span>
          </button>
        </div>
      </div>

      {/* Filters & Search Bar */}
      <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder={`Cari nama ${
              activeTab === 'siswa'
                ? 'siswa, sekolah...'
                : activeTab === 'sekolah'
                ? 'sekolah...'
                : 'masjid...'
            }`}
            className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-300 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <select
            value={selectedDistrict}
            onChange={e => setSelectedDistrict(e.target.value)}
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-700 focus:outline-none"
          >
            <option value="all">📍 Seluruh Wilayah Cimahi</option>
            <option value="Cimahi Tengah">Cimahi Tengah</option>
            <option value="Cimahi Utara">Cimahi Utara</option>
            <option value="Cimahi Selatan">Cimahi Selatan</option>
          </select>
        </div>
      </div>

      {/* Leaderboard Table / Content */}
      <div className="p-3 sm:p-5">
        {/* ================= TAB 1: SISWA TOP STREAK ================= */}
        {activeTab === 'siswa' && (
          <div className="space-y-2.5">
            {topStudents.map((siswa, idx) => {
              const rank = idx + 1;
              return (
                <div
                  key={siswa.id}
                  className={`p-3 sm:p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    rank === 1
                      ? 'bg-gradient-to-r from-amber-50 to-orange-50/40 border-amber-300 shadow-2xs'
                      : rank === 2
                      ? 'bg-slate-50/80 border-slate-300'
                      : rank === 3
                      ? 'bg-amber-900/5 border-amber-200'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="shrink-0">{getRankBadge(rank)}</div>

                    <img
                      src={siswa.avatar}
                      alt={siswa.name}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-2xs shrink-0"
                    />

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-extrabold text-sm text-slate-900 truncate">
                          {siswa.name}
                        </h4>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black">
                          {siswa.grade}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-medium truncate mt-0.5">
                        {siswa.schoolName} &bull; {siswa.mosqueName}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200/60 text-xs">
                    <div className="text-center px-2.5 py-1 bg-amber-100/70 text-amber-900 rounded-xl border border-amber-200/80">
                      <div className="flex items-center gap-1 font-black text-amber-900">
                        <Flame className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                        <span>{siswa.streakDays} Hari</span>
                      </div>
                      <span className="text-[10px] font-semibold text-amber-800">Streak Record</span>
                    </div>

                    <div className="text-center px-2.5 py-1 bg-emerald-50 text-emerald-900 rounded-xl border border-emerald-200">
                      <div className="font-black text-emerald-800">
                        {siswa.totalCompletedActivities} Kegiatan
                      </div>
                      <span className="text-[10px] font-semibold text-emerald-700">Tercatat</span>
                    </div>

                    <div className="text-center px-2.5 py-1 bg-indigo-50 text-indigo-900 rounded-xl border border-indigo-200">
                      <div className="font-black text-indigo-800">{siswa.characterScore} Pts</div>
                      <span className="text-[10px] font-semibold text-indigo-700">Skor Karakter</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ================= TAB 2: SEKOLAH ISTIQOMAH ================= */}
        {activeTab === 'sekolah' && (
          <div className="space-y-2.5">
            {topSchools.map((sch, idx) => {
              const rank = idx + 1;
              return (
                <div
                  key={sch.id}
                  className="p-3.5 sm:p-4 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="shrink-0">{getRankBadge(rank)}</div>
                    <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl font-bold shrink-0">
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-slate-900">{sch.name}</h4>
                      <p className="text-xs text-slate-500 font-medium">
                        📍 {sch.address} ({sch.kecamatan}) &bull; Tingkat: {sch.level}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 text-xs shrink-0">
                    <div className="text-center px-3 py-1 bg-slate-100 rounded-xl">
                      <span className="block font-black text-slate-900">
                        {sch.totalStudents} Siswa
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">Total Binaan</span>
                    </div>

                    <div className="text-center px-3 py-1 bg-emerald-50 text-emerald-900 rounded-xl border border-emerald-200">
                      <span className="block font-black text-emerald-800">
                        94.5%
                      </span>
                      <span className="text-[10px] text-emerald-700 font-semibold">Tingkat Subuh</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ================= TAB 3: MASJID TERAKTIF DKM ================= */}
        {activeTab === 'masjid' && (
          <div className="space-y-2.5">
            {topMosques.map((mosq, idx) => {
              const rank = idx + 1;
              return (
                <div
                  key={mosq.id}
                  className="p-3.5 sm:p-4 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="shrink-0">{getRankBadge(rank)}</div>
                    <div className="p-2.5 bg-teal-100 text-teal-800 rounded-xl font-bold shrink-0">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-slate-900">{mosq.name}</h4>
                      <p className="text-xs text-slate-500 font-medium">
                        📍 {mosq.address} ({mosq.kecamatan}) &bull; Ketua DKM: {mosq.dkmLeader}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 text-xs shrink-0">
                    <div className="text-center px-3 py-1 bg-emerald-50 text-emerald-900 rounded-xl border border-emerald-200">
                      <span className="block font-black text-emerald-800">
                        {mosq.activeStudentsCount} Siswa
                      </span>
                      <span className="text-[10px] text-emerald-700 font-semibold">Jamaah Binaan</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ================= TAB 4: PERINGKAT KECAMATAN ================= */}
        {activeTab === 'kecamatan' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {districtRankings.map((dist, idx) => (
              <div
                key={dist.name}
                className="p-5 rounded-3xl bg-gradient-to-b from-slate-50 to-emerald-50/40 border border-slate-200 space-y-4 relative overflow-hidden"
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xl">{dist.icon}</span>
                  {getRankBadge(idx + 1)}
                </div>

                <div>
                  <h4 className="text-base font-black text-slate-900">{dist.name}</h4>
                  <p className="text-xs text-slate-500 font-medium">Kecamatan Teladan Cimahi</p>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-200/80 text-xs font-semibold">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Siswa Aktif:</span>
                    <strong className="text-slate-900">{dist.activeStudents} anak</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Kehadiran Subuh:</span>
                    <strong className="text-emerald-800 font-extrabold">{dist.subuhRate}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Sekolah &amp; Masjid:</span>
                    <strong className="text-slate-900">
                      {dist.activeSchools} Sekolah / {dist.activeMosques} Masjid
                    </strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3.5 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500 font-medium">
        Papan peringkat diperbarui secara realtime berdasarkan aktivitas yang terverifikasi DKM &amp; Orang Tua.
      </div>
    </div>
  );
};
