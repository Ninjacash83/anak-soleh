import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { PwaInstallSection } from '../pwa/PwaInstallSection';
import {
  LogIn,
  ArrowLeft,
  ShieldCheck,
  Lock,
  Mail,
  GraduationCap,
  Users,
  Building2,
  BookOpen,
  Info,
  Eye,
  EyeOff,
  Sparkles,
  Sliders
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { login, setActiveAppMode, users, appSettings } = useApp();

  const [selectedRole, setSelectedRole] = useState<UserRole>('siswa');
  const [email, setEmail] = useState('student@example.com');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const roleOptions: {
    role: UserRole;
    label: string;
    description: string;
    defaultEmail: string;
    defaultPass: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    {
      role: 'siswa',
      label: 'Siswa / Santri',
      description: 'Akses Buku Kendali, amalan ibadah harian, modul LKS digital, & lencana prestasi.',
      defaultEmail: 'student@example.com',
      defaultPass: 'password123',
      icon: GraduationCap
    },
    {
      role: 'orang_tua',
      label: 'Orang Tua / Wali Murid',
      description: 'Pantau amalan anak, konfirmasi Buku Kendali, dan catat motivasi perkembangan.',
      defaultEmail: 'parent@example.com',
      defaultPass: 'password123',
      icon: Users
    },
    {
      role: 'dkm',
      label: 'DKM / Guru Mengaji',
      description: 'Verifikasi jamaah Subuh & santri Maghrib Mengaji di masjid binaan.',
      defaultEmail: 'dkm@example.com',
      defaultPass: 'password123',
      icon: Building2
    },
    {
      role: 'guru_agama',
      label: 'Guru Agama (PAI)',
      description: 'Bimbingan adab sekolah, integrasi Buku Kendali dengan portofolio & rapor PAI.',
      defaultEmail: 'teacher@example.com',
      defaultPass: 'password123',
      icon: BookOpen
    },
    {
      role: 'admin_pemkot',
      label: 'Pemerintah Kota Cimahi',
      description: 'Dashboard eksekutif wilayah per kecamatan, ketercapaian 4 pilar, & jejaring kota.',
      defaultEmail: 'admin@example.com',
      defaultPass: 'password123',
      icon: ShieldCheck
    },
    {
      role: 'super_admin',
      label: 'Super Admin (Pengelola CMS & Sistem)',
      description: 'Hak akses penuh: ubah logo, edit materi LKS, atur carousel, pilar, & kelola akun.',
      defaultEmail: 'superadmin@example.com',
      defaultPass: 'admin123',
      icon: Sliders
    }
  ];

  const handleRoleChange = (newRole: UserRole) => {
    setSelectedRole(newRole);
    setErrorMsg('');
    const matched = roleOptions.find(r => r.role === newRole);
    if (matched) {
      setEmail(matched.defaultEmail);
      setPassword(matched.defaultPass);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    setTimeout(() => {
      const result = login(email, password);
      setLoading(false);

      if (!result.success) {
        setErrorMsg(result.message || 'Kredensial tidak valid. Silakan periksa kembali email atau peran.');
      }
    }, 250);
  };

  const currentRoleOption = roleOptions.find(r => r.role === selectedRole) || roleOptions[0];
  const CurrentIcon = currentRoleOption.icon;

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50/60 via-slate-50 to-teal-50/40 flex flex-col justify-center py-8 px-4 sm:px-6 lg:px-8 text-slate-900">
      {/* Top Header / Back Link */}
      <div className="max-w-md w-full mx-auto mb-6 flex items-center justify-between">
        <button
          onClick={() => {
            setActiveAppMode('public');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-700 hover:text-emerald-800 bg-white hover:bg-slate-100 px-3.5 py-2 rounded-xl transition-all border border-slate-200 shadow-2xs cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-700" />
          <span>Website Publik</span>
        </button>

        <span className="text-[11px] font-black text-emerald-900 uppercase tracking-wider bg-emerald-100/90 px-2.5 py-1 rounded-lg border border-emerald-300 shadow-2xs">
          {appSettings.appName} {appSettings.appBadge}
        </span>
      </div>

      <div className="max-w-md w-full mx-auto">
        {/* Brand Banner Card */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-950 overflow-hidden text-white font-black text-2xl shadow-lg shadow-emerald-900/15 mb-3 border-2 border-white p-0.5">
            {appSettings.logoImageUrl ? (
              <img
                src={appSettings.logoImageUrl}
                alt={appSettings.appName}
                className="w-full h-full object-cover rounded-xl"
              />
            ) : (
              <span>{appSettings.logoText || 'SC'}</span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Masuk Platform Ekosistem
          </h1>
          <p className="text-xs text-slate-600 mt-1 max-w-xs mx-auto leading-relaxed">
            Silakan pilih peran Anda pada menu dropdown di bawah untuk masuk ke dashboard resmi.
          </p>
        </div>

        {/* Login Box */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-slate-200/60 border border-slate-200">
          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleFormSubmit} className="space-y-4">
            {/* Clean Role Dropdown Selection */}
            <div>
              <label
                htmlFor="role-select"
                className="block text-xs font-extrabold text-slate-800 mb-1.5 flex items-center justify-between"
              >
                <span>Pilih Peran Akun</span>
                <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Dropdown Peran
                </span>
              </label>
              <div className="relative">
                <select
                  id="role-select"
                  value={selectedRole}
                  onChange={e => handleRoleChange(e.target.value as UserRole)}
                  className="w-full bg-slate-50 border border-slate-300 hover:border-emerald-600 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none transition-all cursor-pointer appearance-none pr-10 shadow-2xs"
                >
                  {roleOptions.map(opt => (
                    <option key={opt.role} value={opt.role} className="py-2 text-xs font-bold text-slate-900">
                      {opt.label}
                    </option>
                  ))}
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-emerald-700">
                  <CurrentIcon className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[11px] text-slate-600 mt-1.5 flex items-start gap-1.5 font-medium bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                <Info className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                <span>{currentRoleOption.description}</span>
              </p>
            </div>

            {/* Email / ID Input */}
            <div>
              <label
                htmlFor="email-input"
                className="block text-xs font-extrabold text-slate-800 mb-1"
              >
                Email / No. WhatsApp / NISN
              </label>
              <div className="relative">
                <input
                  id="email-input"
                  type="text"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="nama@email.com atau no. WA"
                  required
                  className="w-full bg-slate-50 border border-slate-300 focus:bg-white rounded-xl px-3.5 py-2.5 pl-9 text-xs sm:text-sm text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none transition-all shadow-2xs"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            {/* Password Input with Eye Visibility Toggle Button */}
            <div>
              <label
                htmlFor="password-input"
                className="block text-xs font-extrabold text-slate-800 mb-1"
              >
                Kata Sandi
              </label>
              <div className="relative">
                <input
                  id="password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full bg-slate-50 border border-slate-300 focus:bg-white rounded-xl px-3.5 py-2.5 pl-9 pr-10 text-xs sm:text-sm text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none transition-all shadow-2xs"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 rounded-md transition-colors cursor-pointer"
                  title={showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4 text-emerald-700" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-800 hover:bg-emerald-700 text-white font-black py-3 px-4 rounded-xl text-xs sm:text-sm shadow-md shadow-emerald-900/15 hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer mt-3 disabled:opacity-50"
            >
              <LogIn className="w-4 h-4" />
              <span>{loading ? 'Memverifikasi...' : `Masuk sebagai ${currentRoleOption.label}`}</span>
            </button>
          </form>

          {/* PWA Mobile Quick Install Banner */}
          <div className="mt-5 pt-4 border-t border-slate-100">
            <PwaInstallSection compact />
          </div>
        </div>

        {/* Footer info: Developer & All Collaborators */}
        <div className="mt-8 pt-6 border-t border-slate-200/80 space-y-4 text-center">
          <div className="space-y-1">
            <p className="text-[11px] font-bold text-slate-700">
              Dikembangkan oleh{' '}
              <strong className="text-emerald-900 font-extrabold">
                ITEC &amp; PT Masagi Cendekia Berkah
              </strong>
            </p>
            <p className="text-[10px] text-slate-500">
              Platform Kolaborasi Ekosistem Karakter &amp; Pembiasaan Islami Kota Cimahi
            </p>
          </div>

          <div className="space-y-2">
            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
              Kolaborator Lembaga Kota Cimahi
            </span>
            <div className="flex flex-wrap justify-center gap-1.5 max-w-md mx-auto">
              {[
                'Pemkot Cimahi',
                'Dinas Pendidikan',
                'Dinas Sosial',
                'DMI Kota Cimahi',
                'MUI Kota Cimahi',
                'BAZNAS Kota Cimahi',
                'ICMI Orda Cimahi'
              ].map(c => (
                <span
                  key={c}
                  className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] text-slate-700 font-semibold shadow-2xs"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
