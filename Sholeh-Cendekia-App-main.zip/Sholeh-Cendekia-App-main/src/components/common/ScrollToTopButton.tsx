import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export const ScrollToTopButton: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 250) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  if (!isVisible) return null;

  return (
    <button
      onClick={scrollToTop}
      aria-label="Kembali ke atas"
      className="fixed bottom-20 md:bottom-8 right-4 sm:right-6 z-40 p-3 sm:p-3.5 rounded-2xl bg-emerald-800 hover:bg-emerald-700 text-white shadow-xl border border-emerald-600/40 transition-all transform hover:scale-110 active:scale-95 flex items-center justify-center gap-1.5 group cursor-pointer"
      title="Kembali ke Atas"
    >
      <ArrowUp className="w-5 h-5 text-amber-300 group-hover:-translate-y-0.5 transition-transform" />
      <span className="hidden sm:inline text-xs font-black tracking-tight">
        Ke Atas
      </span>
    </button>
  );
};
