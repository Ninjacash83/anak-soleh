import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Download, Smartphone, Share, PlusSquare, CheckCircle2, Sparkles, ArrowRight, Monitor, HelpCircle } from 'lucide-react';

interface PwaInstallSectionProps {
  className?: string;
  compact?: boolean;
}

export const PwaInstallSection: React.FC<PwaInstallSectionProps> = ({
  className = '',
  compact = false
}) => {
  const { appSettings } = useApp();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [activeOsTab, setActiveOsTab] = useState<'android' | 'ios'>('android');
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Check if running standalone PWA
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone ||
      document.referrer.includes('android-app://');

    if (isStandalone) {
      setIsInstalled(true);
    }

    // Detect iOS
    const userAgent = window.navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(userAgent)) {
      setActiveOsTab('ios');
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      if (activeOsTab === 'ios') {
        alert('Di iPhone: Buka menu Share di bawah layar Safari lalu pilih "Tambahkan ke Layar Utama".');
      } else {
        alert('Buka menu browser (titik 3 di kanan atas) lalu pilih "Tambahkan ke Layar Utama" / "Install App".');
      }
      return;
    }

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
  };

  const currentIconUrl = appSettings.logoImageUrl || '/pwa-512x512.png';

  if (compact) {
    return (
      <div className={`p-4 rounded-2xl bg-gradient-to-r from-emerald-900 to-teal-900 text-white shadow-md border border-emerald-700/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${className}`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-emerald-400/30 bg-emerald-950 p-0.5">
            <img src={currentIconUrl} alt="App Icon" className="w-full h-full object-cover rounded-lg" />
          </div>
          <div>
            <h4 className="font-extrabold text-xs sm:text-sm text-white">
              Install Aplikasi {appSettings.appName} di HP
            </h4>
            <p className="text-[11px] text-emerald-200">
              Akses cepat tanpa perlu ketik URL web lagi
            </p>
          </div>
        </div>

        <button
          onClick={handleInstallClick}
          className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-sm flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{isInstalled ? 'Sudah Terpasang' : 'Pasang di HP'}</span>
        </button>
      </div>
    );
  }

  return (
    <section id="pwa-install" className={`rounded-3xl bg-white border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl overflow-hidden shrink-0 border-2 border-emerald-600/30 bg-emerald-950 p-1 shadow-md">
            <img src={currentIconUrl} alt={appSettings.appName} className="w-full h-full object-cover rounded-xl" />
          </div>
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase tracking-wider mb-1">
              <Smartphone className="w-3 h-3 text-emerald-700" />
              <span>Aplikasi HP Berbasis PWA (Progressive Web App)</span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
              Cara Install Aplikasi {appSettings.appName} di Layar Utama HP
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Dapat diinstall langsung dari browser HP tanpa melalui Google Play / App Store
            </p>
          </div>
        </div>

        <button
          onClick={handleInstallClick}
          className="px-5 py-3 rounded-2xl bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0 hover:scale-103 active:scale-95"
        >
          <Download className="w-4 h-4 text-amber-300" />
          <span>{isInstalled ? 'Aplikasi Sudah Terpasang' : 'Pasang Sekarang (Otomatis)'}</span>
        </button>
      </div>

      {/* Benefits Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-100 space-y-1">
          <div className="flex items-center gap-2 font-bold text-xs text-emerald-900">
            <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>Ikon Logo di Home HP</span>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed">
            Ikon resmi platform muncul di home screen layaknya aplikasi bawaan Play Store.
          </p>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-100 space-y-1">
          <div className="flex items-center gap-2 font-bold text-xs text-emerald-900">
            <Monitor className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>Mode Layar Penuh</span>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed">
            Tampilan jernih tanpa address bar browser, lebih nyaman untuk siswa &amp; orang tua.
          </p>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-100 space-y-1">
          <div className="flex items-center gap-2 font-bold text-xs text-emerald-900">
            <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>Ringan &amp; Hemat Memori</span>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed">
            Sangat efisien tanpa membebankan penyimpanan memori HP orang tua atau siswa.
          </p>
        </div>
      </div>

      {/* Manual Step-by-Step Instructions */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-emerald-700" />
            <span>Panduan Langkah Manual (Per Perangkat)</span>
          </h3>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => setActiveOsTab('android')}
              className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                activeOsTab === 'android'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Android (Chrome/Edge)
            </button>
            <button
              onClick={() => setActiveOsTab('ios')}
              className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                activeOsTab === 'ios'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              iPhone / iPad (Safari)
            </button>
          </div>
        </div>

        {activeOsTab === 'android' ? (
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-700">
            <div className="space-y-1">
              <span className="font-extrabold text-emerald-800">Langkah 1:</span>
              <p>Buka tautan website ini menggunakan browser Google Chrome atau Microsoft Edge di HP Android.</p>
            </div>
            <div className="space-y-1">
              <span className="font-extrabold text-emerald-800">Langkah 2:</span>
              <p>Ketuk tombol menu <strong>Titik 3 (⋮)</strong> di sudut kanan atas browser.</p>
            </div>
            <div className="space-y-1">
              <span className="font-extrabold text-emerald-800">Langkah 3:</span>
              <p>Pilih menu <strong>"Tambahkan ke Layar Utama"</strong> atau <strong>"Install Aplikasi"</strong>.</p>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-700">
            <div className="space-y-1">
              <span className="font-extrabold text-emerald-800">Langkah 1:</span>
              <p>Buka tautan website ini menggunakan browser bawaan <strong>Safari</strong> di iPhone/iPad.</p>
            </div>
            <div className="space-y-1">
              <span className="font-extrabold text-emerald-800">Langkah 2:</span>
              <p>Ketuk tombol <strong>Bagikan (Share Icon <Share className="w-3 h-3 inline text-emerald-700" />)</strong> di bagian bawah layar.</p>
            </div>
            <div className="space-y-1">
              <span className="font-extrabold text-emerald-800">Langkah 3:</span>
              <p>Gulir menu lalu ketuk <strong>"Tambahkan ke Layar Utama" (Add to Home Screen <PlusSquare className="w-3 h-3 inline text-emerald-700" />)</strong>.</p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
