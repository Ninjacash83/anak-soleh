export type UserRole = 'siswa' | 'orang_tua' | 'dkm' | 'guru_agama' | 'admin_pemkot' | 'super_admin';

export interface AppSettings {
  appName: string;
  appBadge: string;
  appTagline: string;
  visionTitle: string;
  visionSubtitle: string;
  logoText: string;
  logoImageUrl?: string;
  primaryColor: string;
  contactEmail: string;
  contactPhone: string;

  // Public Website CMS Content
  defaultLandingMode?: 'public' | 'login';
  heroHeadline?: string;
  heroSubquote?: string;
  heroDescription?: string;
  heroKicker?: string;
  heroButtonText?: string;
  statStudentsCount?: string;
  statMosquesCount?: string;
  statSchoolsCount?: string;
  statVerificationRate?: string;
  gerakan5000Headline?: string;
  gerakan5000Description?: string;
}

export interface CarouselSlide {
  id: string;
  kicker: string;
  headline: string;
  content: string;
  ctaLabel: string;
  imageUrl: string;
  actionType: 'gerakan_5000' | 'article_nasehat' | 'article_berita' | 'tab_progress' | 'tab_belajar';
  bgClass?: string;
  accentClass?: string;
  isActive: boolean;
  order: number;
}

export interface PillarConfig {
  category: ActivityCategory;
  title: string;
  defaultTitle: string;
  schedule: string;
  description: string;
  points: number;
}

export interface Gerakan5000Config {
  nominal: number;
  minNominal: number;
  qrisNmid: string;
  qrisMerchantName: string;
  qrisImageUrl?: string;
  vaNumber: string;
  bankName: string;
  bankCode?: string;
  bankAccountNumber: string;
  accountHolder: string;
  secondaryBankName?: string;
  secondaryBankAccountNumber?: string;
  secondaryBankAccountHolder?: string;
  donationInstruction: string;
  ortuTriggerHeadline: string;
  ortuTriggerMessage: string;
  siswaTriggerHeadline: string;
  siswaTriggerMessage: string;
  targetFunds: number;
  collectedFunds: number;
  totalDonors: number;
}

export type ActivityCategory =
  | 'subuh_berjamaah'
  | 'maghrib_mengaji'
  | 'tilawah_belajar'
  | 'kebaikan_kepedulian';

export type ActivityStatus =
  | 'belum_dicatat'
  | 'dicatat'
  | 'dikonfirmasi_ortu'
  | 'diverifikasi_dkm';

export interface User {
  id: string;
  name: string;
  emailOrPhone: string;
  password?: string;
  role: UserRole;
  avatar: string;
  entityId: string;
  entityName: string;
  title?: string;
}

export interface School {
  id: string;
  name: string;
  level: 'SD' | 'SMP' | 'SMA';
  kecamatan: 'Cimahi Utara' | 'Cimahi Tengah' | 'Cimahi Selatan';
  address: string;
  totalStudents: number;
}

export interface Mosque {
  id: string;
  name: string;
  kecamatan: 'Cimahi Utara' | 'Cimahi Tengah' | 'Cimahi Selatan';
  address: string;
  dkmLeader: string;
  activeStudentsCount: number;
}

export interface Teacher {
  id: string;
  name: string;
  schoolId: string;
  schoolName: string;
  subject: string;
  phone: string;
}

export interface Parent {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  childrenIds: string[];
}

export interface Student {
  id: string;
  name: string;
  grade: string;
  jenjang: 'SD' | 'SMP' | 'SMA';
  schoolId: string;
  schoolName: string;
  mosqueId: string;
  mosqueName: string;
  kecamatan: 'Cimahi Utara' | 'Cimahi Tengah' | 'Cimahi Selatan';
  parentId: string;
  parentName: string;
  parentPhone: string;
  teacherId: string;
  teacherName: string;
  avatar: string;
  streakDays: number;
  characterScore: number;
  totalCompletedActivities: number;
}

export interface ActivityRecord {
  id: string;
  studentId: string;
  studentName: string;
  schoolId: string;
  schoolName: string;
  mosqueId: string;
  mosqueName: string;
  date: string;
  time: string;
  category: ActivityCategory;
  title: string;
  description: string;
  companion: 'Orang Tua' | 'Ayah' | 'Ibu' | 'Guru Mengaji' | 'Guru Agama' | 'Mandiri' | 'Rekan Sebaya';
  status: ActivityStatus;
  notes?: string;
  dkmVerified: boolean;
  dkmVerifierName?: string;
  dkmNote?: string;
  dkmVerifiedAt?: string;
  parentConfirmed: boolean;
  parentNote?: string;
  parentConfirmedAt?: string;
  teacherNote?: string;
  teacherNotedAt?: string;
}

export interface ObservationNote {
  id: string;
  studentId: string;
  studentName: string;
  schoolId: string;
  mosqueId: string;
  authorRole: 'dkm' | 'guru_agama';
  authorName: string;
  date: string;
  aspect: 'Sholat & Ibadah' | 'Makhraj & Tilawah' | 'Adab & Karakter' | 'Kepedulian Sosial';
  content: string;
}

export interface LksMultipleChoiceQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
}

export interface LearningMaterial {
  id: string;
  title: string;
  type: 'lks' | 'video' | 'podcast' | 'planner';
  jenjang: 'SD' | 'SMP' | 'SMA';
  kelas: string;
  subject: string;
  tema: string;
  category: string;
  estimatedTime: string;
  durationOrPages: string;
  description: string;
  source: string;
  thumbnail: string;
  digitalAvailable: boolean;
  pdfAvailable: boolean;
  summaryContent?: string;
  mcQuestions?: LksMultipleChoiceQuestion[];
  shortAnswerPrompt?: string;
  checklistItems?: string[];
}

export interface LksSubmission {
  materialId: string;
  studentId: string;
  completedAt: string;
  score: number;
  shortAnswerText: string;
  checkedItems: boolean[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: string;
  isUnlocked: boolean;
  unlockedDate?: string;
  progressPercent: number;
  criteria: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  time: string;
  category:
    | 'lks'
    | 'buku_kendali'
    | 'verifikasi'
    | 'prestasi'
    | 'berita'
    | 'tugas'
    | 'pesan_sekolah'
    | 'agenda_karakter';
  targetRoles: UserRole[];
  targetStudentId?: string;
  targetMosqueId?: string;
  targetSchoolId?: string;
  isRead: boolean;
  actionTab?: string;
  sender?: string;
  senderRole?: string;
  priority?: 'high' | 'normal' | 'low';
  actionLabel?: string;
  eventDate?: string;
  eventLocation?: string;
}

export interface EcosystemPartner {
  name: string;
  role: string;
  category: 'pemerintah' | 'keagamaan' | 'inisiator' | 'teknologi';
  description: string;
  badge: string;
}
