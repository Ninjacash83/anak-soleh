export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getRelativeDateString(daysOffset: number): string {
  const d = new Date();
  d.setDate(d.getDate() + daysOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatIndonesianDate(dateStr: string): string {
  if (!dateStr) return '';
  const today = getTodayDateString();
  const yesterday = getRelativeDateString(-1);

  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;

  const dateObj = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  const formatted = dateObj.toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  if (dateStr === today) return `Hari ini, ${formatted}`;
  if (dateStr === yesterday) return `Kemarin, ${formatted}`;
  return formatted;
}

export function formatShortIndonesianDate(dateStr: string): string {
  if (!dateStr) return '';
  const today = getTodayDateString();
  if (dateStr === today) return 'Hari Ini';
  const yesterday = getRelativeDateString(-1);
  if (dateStr === yesterday) return 'Kemarin';

  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const dateObj = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  return dateObj.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}
