import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { ActivityStreamItem, ActivityStreamReaction } from '../types/activityStream';
import { SEED_ACTIVITY_STREAM } from '../data/seedActivityStream';

interface ActivityStreamContextType {
  streamItems: ActivityStreamItem[];
  addStreamItem: (item: Omit<ActivityStreamItem, 'id' | 'timestamp' | 'reactions'>) => void;
  reactToItem: (id: string, reactionType: keyof ActivityStreamReaction) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  unreadCount: number;
  clearUnread: () => void;
  isLiveConnected: boolean;
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
}

const STORAGE_KEY = 'sc_v3_activity_stream';
const SOUND_KEY = 'sc_v3_stream_sound';

const deduplicateStreamItems = (items: ActivityStreamItem[]): ActivityStreamItem[] => {
  const seen = new Set<string>();
  const result: ActivityStreamItem[] = [];
  for (const item of items) {
    if (item && item.id && !seen.has(item.id)) {
      seen.add(item.id);
      result.push(item);
    }
  }
  return result;
};

const ActivityStreamContext = createContext<ActivityStreamContextType | undefined>(undefined);

export const ActivityStreamProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [streamItems, setStreamItems] = useState<ActivityStreamItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const clean = deduplicateStreamItems(parsed);
          if (clean.length > 0) return clean;
        }
      } catch {}
    }
    return deduplicateStreamItems(SEED_ACTIVITY_STREAM);
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem(SOUND_KEY);
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [isLiveConnected, setIsLiveConnected] = useState<boolean>(true);
  const [activeFilter, setActiveFilter] = useState<string>('all');

  // Persist stream items (deduplicated)
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(deduplicateStreamItems(streamItems).slice(0, 50)));
  }, [streamItems]);

  // Persist sound state
  useEffect(() => {
    localStorage.setItem(SOUND_KEY, JSON.stringify(soundEnabled));
  }, [soundEnabled]);

  // Broadcast channel for multi-tab synchronization
  useEffect(() => {
    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel('sc_activity_stream_channel');
      bc.onmessage = (event) => {
        if (event.data && event.data.type === 'NEW_STREAM_ITEM') {
          const incomingItem = event.data.item;
          if (!incomingItem || !incomingItem.id) return;
          setStreamItems((prev) => {
            if (prev.some((item) => item.id === incomingItem.id)) {
              return prev;
            }
            return deduplicateStreamItems([incomingItem, ...prev]);
          });
          setUnreadCount((c) => c + 1);
        } else if (event.data && event.data.type === 'REACTION_UPDATED') {
          setStreamItems((prev) =>
            prev.map((item) =>
              item.id === event.data.id ? { ...item, reactions: event.data.reactions } : item
            )
          );
        }
      };
    } catch {}

    return () => {
      if (bc) bc.close();
    };
  }, []);

  const clearUnread = useCallback(() => {
    setUnreadCount(0);
  }, []);

  const addStreamItem = useCallback(
    (newItemData: Omit<ActivityStreamItem, 'id' | 'timestamp' | 'reactions'>) => {
      const newItem: ActivityStreamItem = {
        ...newItemData,
        id: `stream-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
        timestamp: new Date().toISOString(),
        isLive: true,
        reactions: { praise: 1, barakallah: 2, fire: 0, masyaAllah: 1 }
      };

      setStreamItems((prev) => deduplicateStreamItems([newItem, ...prev]));
      setUnreadCount((c) => c + 1);

      // Broadcast to other tabs
      try {
        const bc = new BroadcastChannel('sc_activity_stream_channel');
        bc.postMessage({ type: 'NEW_STREAM_ITEM', item: newItem });
        bc.close();
      } catch {}
    },
    []
  );

  const reactToItem = useCallback((id: string, reactionType: keyof ActivityStreamReaction) => {
    setStreamItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const currentCount = (item.reactions[reactionType] as number) || 0;
          const updatedReactions = {
            ...item.reactions,
            [reactionType]: currentCount + 1
          };

          // Broadcast reaction
          try {
            const bc = new BroadcastChannel('sc_activity_stream_channel');
            bc.postMessage({ type: 'REACTION_UPDATED', id, reactions: updatedReactions });
            bc.close();
          } catch {}

          return {
            ...item,
            reactions: updatedReactions
          };
        }
        return item;
      })
    );
  }, []);

  // Note: Fake automatic interval activity simulator removed to ensure demo data is not presented as fake live citywide participation.
  // Real user actions (recording, verifying, confirming) will still post real-time updates.

  return (
    <ActivityStreamContext.Provider
      value={{
        streamItems,
        addStreamItem,
        reactToItem,
        soundEnabled,
        setSoundEnabled,
        unreadCount,
        clearUnread,
        isLiveConnected,
        activeFilter,
        setActiveFilter
      }}
    >
      {children}
    </ActivityStreamContext.Provider>
  );
};

export const useActivityStream = () => {
  const context = useContext(ActivityStreamContext);
  if (!context) {
    throw new Error('useActivityStream must be used within an ActivityStreamProvider');
  }
  return context;
};
