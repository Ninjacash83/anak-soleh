import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  School,
  Mosque,
  Teacher,
  Parent,
  Student,
  ActivityRecord,
  ObservationNote,
  LearningMaterial,
  LksSubmission,
  Achievement,
  NotificationItem,
  EcosystemPartner,
  ActivityCategory,
  AppSettings,
  CarouselSlide,
  PillarConfig,
  Gerakan5000Config
} from '../types';
import {
  SEED_USERS,
  SEED_SCHOOLS,
  SEED_MOSQUES,
  SEED_TEACHERS,
  SEED_PARENTS,
  SEED_STUDENTS,
  SEED_RECORDS,
  SEED_OBSERVATIONS,
  SEED_LEARNING_MATERIALS,
  SEED_ACHIEVEMENTS,
  SEED_NOTIFICATIONS,
  SEED_PARTNERS,
  SEED_CITY_METRICS,
  SEED_APP_SETTINGS,
  SEED_CAROUSEL_SLIDES,
  SEED_PILLARS_CONFIG,
  SEED_GERAKAN_5000_CONFIG
} from '../data/seedData';
import { getTodayDateString } from '../utils/dateUtils';

interface AppContextType {
  currentUser: User | null;
  currentRole: UserRole;
  isAuthenticated: boolean;
  activeAppMode: 'public' | 'login' | 'platform';
  setActiveAppMode: (mode: 'public' | 'login' | 'platform') => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  isGerakan5000InfoOpen: boolean;
  setIsGerakan5000InfoOpen: (open: boolean) => void;

  users: User[];
  schools: School[];
  mosques: Mosque[];
  teachers: Teacher[];
  parents: Parent[];
  students: Student[];
  records: ActivityRecord[];
  observations: ObservationNote[];
  learningMaterials: LearningMaterial[];
  lksSubmissions: LksSubmission[];
  achievements: Achievement[];
  notifications: NotificationItem[];
  partners: EcosystemPartner[];
  cityMetrics: typeof SEED_CITY_METRICS;
  appSettings: AppSettings;
  carouselSlides: CarouselSlide[];
  pillarsConfig: PillarConfig[];
  gerakan5000Config: Gerakan5000Config;

  currentStudent: Student | null;
  currentParent: Parent | null;
  parentChildren: Student[];
  selectedChild: Student | null;
  selectedChildId: string;
  setSelectedChildId: (id: string) => void;
  currentMosque: Mosque | null;
  mosqueStudents: Student[];
  mosqueRecords: ActivityRecord[];
  currentTeacher: Teacher | null;
  schoolStudents: Student[];
  schoolRecords: ActivityRecord[];

  selectedStudentId: string;
  setSelectedStudentId: (id: string) => void;

  login: (emailOrPhone: string, password?: string) => { success: boolean; message?: string };
  logout: () => void;
  switchRole: (role: UserRole) => void;
  addActivityRecord: (data: {
    studentId: string;
    category: ActivityCategory;
    title: string;
    description: string;
    companion: ActivityRecord['companion'];
    notes?: string;
  }) => void;
  confirmActivityParent: (recordId: string, parentNote?: string) => void;
  verifyActivityDKM: (recordId: string, dkmNote?: string, verifierName?: string) => void;
  addTeacherObservation: (
    studentId: string,
    aspect: ObservationNote['aspect'],
    content: string,
    authorRole: 'dkm' | 'guru_agama',
    authorName: string
  ) => void;
  submitDigitalLks: (submission: LksSubmission, materialTitle: string) => void;
  recordParticipation5000: (amount?: number, donorName?: string, donorRole?: string) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  sendNotification: (notif: Omit<NotificationItem, 'id' | 'date' | 'time' | 'isRead'>) => void;
  deleteNotification: (id: string) => void;
  resetDemoData: () => void;

  // Super Admin CMS Handlers
  updateAppSettings: (settings: Partial<AppSettings>) => void;
  updateCarouselSlide: (id: string, slide: Partial<CarouselSlide>) => void;
  addCarouselSlide: (slide: Omit<CarouselSlide, 'id'>) => void;
  deleteCarouselSlide: (id: string) => void;
  updateLearningMaterial: (id: string, material: Partial<LearningMaterial>) => void;
  addLearningMaterial: (material: Omit<LearningMaterial, 'id'>) => void;
  deleteLearningMaterial: (id: string) => void;
  updatePillarConfig: (category: ActivityCategory, config: Partial<PillarConfig>) => void;
  updateGerakan5000Config: (config: Partial<Gerakan5000Config>) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  addUser: (user: Omit<User, 'id'>) => void;
  deleteUser: (id: string) => void;
  updateSchool: (id: string, school: Partial<School>) => void;
  addSchool: (school: Omit<School, 'id'>) => void;
  deleteSchool: (id: string) => void;
  updateMosque: (id: string, mosque: Partial<Mosque>) => void;
  addMosque: (mosque: Omit<Mosque, 'id'>) => void;
  deleteMosque: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'sc_v3_user',
  USERS: 'sc_v3_users',
  RECORDS: 'sc_v3_records',
  STUDENTS: 'sc_v3_students',
  SCHOOLS: 'sc_v3_schools',
  MOSQUES: 'sc_v3_mosques',
  OBSERVATIONS: 'sc_v3_observations',
  NOTIFICATIONS: 'sc_v3_notifications',
  LKS_SUBMISSIONS: 'sc_v3_lks_submissions',
  MATERIALS: 'sc_v3_materials',
  APP_SETTINGS: 'sc_v3_app_settings',
  CAROUSEL_SLIDES: 'sc_v3_carousel_slides',
  PILLARS_CONFIG: 'sc_v3_pillars_config',
  GERAKAN_5000: 'sc_v3_gerakan_5000',
  MODE: 'sc_v3_mode'
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return SEED_USERS[0];
      }
    }
    return SEED_USERS[0];
  });

  const [activeAppMode, setActiveAppMode] = useState<'public' | 'login' | 'platform'>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MODE);
    if (saved === 'public' || saved === 'login' || saved === 'platform') {
      return saved;
    }
    const savedSettings = localStorage.getItem(STORAGE_KEYS.APP_SETTINGS);
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        if (parsed.defaultLandingMode === 'login' || parsed.defaultLandingMode === 'public') {
          return parsed.defaultLandingMode;
        }
      } catch {}
    }
    return 'public';
  });

  const [activeTab, setActiveTab] = useState<string>(() => {
    if (currentUser?.role === 'super_admin' || currentUser?.role === 'admin_pemkot') {
      return 'dashboard';
    }
    return 'beranda';
  });

  const [isGerakan5000InfoOpen, setIsGerakan5000InfoOpen] = useState(false);

  const setIsLoginModalOpen = (open: boolean) => {
    if (open) {
      setActiveAppMode('login');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS);
    return saved ? JSON.parse(saved) : SEED_USERS;
  });

  const [schools, setSchools] = useState<School[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SCHOOLS);
    return saved ? JSON.parse(saved) : SEED_SCHOOLS;
  });

  const [mosques, setMosques] = useState<Mosque[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MOSQUES);
    return saved ? JSON.parse(saved) : SEED_MOSQUES;
  });

  const [teachers] = useState<Teacher[]>(SEED_TEACHERS);
  const [parents] = useState<Parent[]>(SEED_PARENTS);

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    return saved ? JSON.parse(saved) : SEED_STUDENTS;
  });

  const [records, setRecords] = useState<ActivityRecord[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RECORDS);
    return saved ? JSON.parse(saved) : SEED_RECORDS;
  });

  const [observations, setObservations] = useState<ObservationNote[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.OBSERVATIONS);
    return saved ? JSON.parse(saved) : SEED_OBSERVATIONS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return saved ? JSON.parse(saved) : SEED_NOTIFICATIONS;
  });

  const [lksSubmissions, setLksSubmissions] = useState<LksSubmission[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LKS_SUBMISSIONS);
    return saved ? JSON.parse(saved) : [];
  });

  const [learningMaterials, setLearningMaterials] = useState<LearningMaterial[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MATERIALS);
    return saved ? JSON.parse(saved) : SEED_LEARNING_MATERIALS;
  });

  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.APP_SETTINGS);
    return saved ? JSON.parse(saved) : SEED_APP_SETTINGS;
  });

  const [carouselSlides, setCarouselSlides] = useState<CarouselSlide[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CAROUSEL_SLIDES);
    return saved ? JSON.parse(saved) : SEED_CAROUSEL_SLIDES;
  });

  const [pillarsConfig, setPillarsConfig] = useState<PillarConfig[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PILLARS_CONFIG);
    return saved ? JSON.parse(saved) : SEED_PILLARS_CONFIG;
  });

  const [gerakan5000Config, setGerakan5000Config] = useState<Gerakan5000Config>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.GERAKAN_5000);
    return saved ? JSON.parse(saved) : SEED_GERAKAN_5000_CONFIG;
  });

  const [achievements] = useState<Achievement[]>(SEED_ACHIEVEMENTS);
  const [partners] = useState<EcosystemPartner[]>(SEED_PARTNERS);
  const [cityMetrics, setCityMetrics] = useState(SEED_CITY_METRICS);

  const [selectedChildId, setSelectedChildId] = useState<string>('');

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MODE, activeAppMode);
  }, [activeAppMode]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SCHOOLS, JSON.stringify(schools));
  }, [schools]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MOSQUES, JSON.stringify(mosques));
  }, [mosques]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.OBSERVATIONS, JSON.stringify(observations));
  }, [observations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LKS_SUBMISSIONS, JSON.stringify(lksSubmissions));
  }, [lksSubmissions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MATERIALS, JSON.stringify(learningMaterials));
  }, [learningMaterials]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APP_SETTINGS, JSON.stringify(appSettings));
  }, [appSettings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CAROUSEL_SLIDES, JSON.stringify(carouselSlides));
  }, [carouselSlides]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PILLARS_CONFIG, JSON.stringify(pillarsConfig));
  }, [pillarsConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GERAKAN_5000, JSON.stringify(gerakan5000Config));
  }, [gerakan5000Config]);

  const currentRole: UserRole = currentUser ? currentUser.role : 'siswa';
  const isAuthenticated = !!currentUser;

  const currentStudent: Student | null =
    currentUser?.role === 'siswa'
      ? students.find(s => s.id === currentUser.entityId) || null
      : null;

  const currentParent: Parent | null =
    currentUser?.role === 'orang_tua'
      ? parents.find(p => p.id === currentUser.entityId) || null
      : null;

  const parentChildren: Student[] = currentParent
    ? students.filter(s => currentParent.childrenIds.includes(s.id))
    : [];

  const selectedChild: Student | null =
    parentChildren.find(c => c.id === selectedChildId) || parentChildren[0] || null;

  useEffect(() => {
    if (currentParent && parentChildren.length > 0) {
      if (!selectedChildId || !parentChildren.some(c => c.id === selectedChildId)) {
        setSelectedChildId(parentChildren[0].id);
      }
    }
  }, [currentParent, parentChildren, selectedChildId]);

  const currentMosque: Mosque | null =
    currentUser?.role === 'dkm'
      ? mosques.find(m => m.id === currentUser.entityId) || null
      : null;

  const mosqueStudents: Student[] = currentMosque
    ? students.filter(s => s.mosqueId === currentMosque.id)
    : [];

  const mosqueStudentIds = new Set(mosqueStudents.map(s => s.id));
  const mosqueRecords: ActivityRecord[] = currentMosque
    ? records.filter(r => mosqueStudentIds.has(r.studentId))
    : [];

  const currentTeacher: Teacher | null =
    currentUser?.role === 'guru_agama'
      ? teachers.find(t => t.id === currentUser.entityId) || null
      : null;

  const schoolStudents: Student[] = currentTeacher
    ? students.filter(s => s.schoolId === currentTeacher.schoolId)
    : [];

  const schoolStudentIds = new Set(schoolStudents.map(s => s.id));
  const schoolRecords: ActivityRecord[] = currentTeacher
    ? records.filter(r => schoolStudentIds.has(r.studentId))
    : [];

  const login = (emailOrPhone: string, password?: string): { success: boolean; message?: string } => {
    const trimmed = emailOrPhone.trim().toLowerCase();

    const matchedUser = users.find(
      u => u.emailOrPhone.toLowerCase() === trimmed || u.name.toLowerCase() === trimmed
    );

    if (!matchedUser) {
      return {
        success: false,
        message: 'Akun tidak ditemukan. Silakan periksa kembali email atau peran yang dipilih.'
      };
    }

    if (password !== undefined && password.trim().length < 3) {
      return {
        success: false,
        message: 'Kata sandi minimal 3 karakter.'
      };
    }

    setCurrentUser(matchedUser);
    setActiveTab(
      matchedUser.role === 'super_admin' || matchedUser.role === 'admin_pemkot'
        ? 'dashboard'
        : 'beranda'
    );
    setActiveAppMode('platform');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    setActiveAppMode('login');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const switchRole = (role: UserRole) => {
    const matched = users.find(u => u.role === role);
    if (matched) {
      setCurrentUser(matched);
      setActiveTab(
        matched.role === 'super_admin' || matched.role === 'admin_pemkot'
          ? 'dashboard'
          : 'beranda'
      );
      setActiveAppMode('platform');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const addActivityRecord = (data: {
    studentId: string;
    category: ActivityCategory;
    title: string;
    description: string;
    companion: ActivityRecord['companion'];
    notes?: string;
  }) => {
    const targetStudent = students.find(s => s.id === data.studentId);
    if (!targetStudent) return;

    const today = getTodayDateString();
    const nowTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

    const newRecord: ActivityRecord = {
      id: `rec-${Date.now()}`,
      studentId: targetStudent.id,
      studentName: targetStudent.name,
      schoolId: targetStudent.schoolId,
      schoolName: targetStudent.schoolName,
      mosqueId: targetStudent.mosqueId,
      mosqueName: targetStudent.mosqueName,
      date: today,
      time: nowTime,
      category: data.category,
      title: data.title,
      description: data.description,
      companion: data.companion,
      status: 'dicatat',
      notes: data.notes || '',
      dkmVerified: false,
      parentConfirmed: false
    };

    setRecords(prev => [newRecord, ...prev]);

    setStudents(prev =>
      prev.map(s => {
        if (s.id === targetStudent.id) {
          return {
            ...s,
            streakDays: s.streakDays + 1,
            characterScore: Math.min(100, s.characterScore + 2),
            totalCompletedActivities: s.totalCompletedActivities + 1
          };
        }
        return s;
      })
    );

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Catatan Amalan Baru',
      message: `${targetStudent.name} mencatat kegiatan ${data.title}`,
      date: today,
      time: nowTime,
      category: 'buku_kendali',
      targetRoles: ['orang_tua', 'dkm', 'guru_agama'],
      targetStudentId: targetStudent.id,
      targetMosqueId: targetStudent.mosqueId,
      targetSchoolId: targetStudent.schoolId,
      isRead: false
    };
    setNotifications(prev => [newNotif, ...prev]);

    try {
      const bc = new BroadcastChannel('sc_activity_stream_channel');
      bc.postMessage({
        type: 'NEW_STREAM_ITEM',
        item: {
          id: `stream-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          type: 'activity_record',
          actorName: targetStudent.name,
          actorRole: 'siswa',
          actorAvatar: targetStudent.avatar,
          title: `Catatan Amalan: ${data.title}`,
          description: data.description || `Mencatat kegiatan ${data.title} bersama ${data.companion}`,
          schoolName: targetStudent.schoolName,
          mosqueName: targetStudent.mosqueName,
          kecamatan: targetStudent.kecamatan,
          timestamp: new Date().toISOString(),
          badge: { label: 'Catatan Baru', color: 'emerald' },
          reactions: { praise: 1, barakallah: 1, fire: 1, masyaAllah: 1 }
        }
      });
      bc.close();
    } catch {}
  };

  const confirmActivityParent = (recordId: string, parentNote?: string) => {
    const today = getTodayDateString();
    const nowTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

    const targetRecord = records.find(r => r.id === recordId);
    setRecords(prev =>
      prev.map(r => {
        if (r.id === recordId) {
          const newStatus = r.dkmVerified ? 'diverifikasi_dkm' : 'dikonfirmasi_ortu';
          return {
            ...r,
            parentConfirmed: true,
            parentNote: parentNote || 'Alhamdulillah anak sholeh/sholehah.',
            parentConfirmedAt: `${today} ${nowTime}`,
            status: newStatus
          };
        }
        return r;
      })
    );

    if (targetRecord) {
      try {
        const bc = new BroadcastChannel('sc_activity_stream_channel');
        bc.postMessage({
          type: 'NEW_STREAM_ITEM',
          item: {
            id: `stream-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            type: 'parent_confirmation',
            actorName: currentUser?.name || 'Orang Tua',
            actorRole: 'orang_tua',
            title: `Konfirmasi Orang Tua: ${targetRecord.title}`,
            description: parentNote || `Orang tua mengonfirmasi amalan ${targetRecord.studentName}`,
            schoolName: targetRecord.schoolName,
            mosqueName: targetRecord.mosqueName,
            timestamp: new Date().toISOString(),
            badge: { label: 'Konfirmasi Ortu', color: 'amber' },
            reactions: { praise: 2, barakallah: 3, fire: 1, masyaAllah: 2 }
          }
        });
        bc.close();
      } catch {}
    }
  };

  const verifyActivityDKM = (recordId: string, dkmNote?: string, verifierName?: string) => {
    const today = getTodayDateString();
    const nowTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

    const targetRecord = records.find(r => r.id === recordId);
    setRecords(prev =>
      prev.map(r => {
        if (r.id === recordId) {
          return {
            ...r,
            dkmVerified: true,
            dkmVerifierName: verifierName || currentUser?.name || 'Ustadz DKM',
            dkmNote: dkmNote || 'Hadir dan mengikuti kegiatan dengan tertib.',
            dkmVerifiedAt: `${today} ${nowTime}`,
            status: 'diverifikasi_dkm'
          };
        }
        return r;
      })
    );

    if (targetRecord) {
      try {
        const bc = new BroadcastChannel('sc_activity_stream_channel');
        bc.postMessage({
          type: 'NEW_STREAM_ITEM',
          item: {
            id: `stream-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            type: 'dkm_verification',
            actorName: verifierName || currentUser?.name || 'Ustadz DKM',
            actorRole: 'dkm',
            title: `Verifikasi DKM: ${targetRecord.title}`,
            description: dkmNote || `DKM memverifikasi kehadiran ${targetRecord.studentName} di ${targetRecord.mosqueName}`,
            schoolName: targetRecord.schoolName,
            mosqueName: targetRecord.mosqueName,
            timestamp: new Date().toISOString(),
            badge: { label: 'Verifikasi DKM', color: 'emerald' },
            reactions: { praise: 5, barakallah: 8, fire: 3, masyaAllah: 6 }
          }
        });
        bc.close();
      } catch {}
    }
  };

  const addTeacherObservation = (
    studentId: string,
    aspect: ObservationNote['aspect'],
    content: string,
    authorRole: 'dkm' | 'guru_agama',
    authorName: string
  ) => {
    const targetStudent = students.find(s => s.id === studentId);
    if (!targetStudent) return;

    const today = getTodayDateString();
    const newNote: ObservationNote = {
      id: `obs-${Date.now()}`,
      studentId: targetStudent.id,
      studentName: targetStudent.name,
      schoolId: targetStudent.schoolId,
      mosqueId: targetStudent.mosqueId,
      authorRole,
      authorName,
      date: today,
      aspect,
      content
    };

    setObservations(prev => [newNote, ...prev]);
  };

  const submitDigitalLks = (submission: LksSubmission, materialTitle: string) => {
    setLksSubmissions(prev => {
      const filtered = prev.filter(
        s => !(s.materialId === submission.materialId && s.studentId === submission.studentId)
      );
      return [submission, ...filtered];
    });

    const targetStudent = students.find(s => s.id === submission.studentId);
    if (targetStudent) {
      setStudents(prev =>
        prev.map(s => {
          if (s.id === targetStudent.id) {
            return {
              ...s,
              characterScore: Math.min(100, s.characterScore + 3),
              totalCompletedActivities: s.totalCompletedActivities + 1
            };
          }
          return s;
        })
      );

      const today = getTodayDateString();
      const nowTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
      const notif: NotificationItem = {
        id: `notif-${Date.now()}`,
        title: 'LKS Selesai Dikerjakan',
        message: `${targetStudent.name} menyelesaikan LKS "${materialTitle}" dengan skor ${submission.score}`,
        date: today,
        time: nowTime,
        category: 'lks',
        targetRoles: ['orang_tua', 'guru_agama', 'dkm'],
        targetStudentId: targetStudent.id,
        isRead: false
      };
      setNotifications(prev => [notif, ...prev]);
    }
  };

  const recordParticipation5000 = (amount?: number, donorName?: string, donorRole?: string) => {
    const finalAmount = amount && amount > 0 ? amount : gerakan5000Config.nominal;
    setGerakan5000Config(prev => ({
      ...prev,
      collectedFunds: prev.collectedFunds + finalAmount,
      totalDonors: prev.totalDonors + 1
    }));

    setCityMetrics(prev => ({
      ...prev,
      sustainability: {
        ...prev.sustainability,
        fundsCollected: prev.sustainability.fundsCollected + finalAmount,
        totalContributors: prev.sustainability.totalContributors + 1
      }
    }));

    if (donorName) {
      const today = getTodayDateString();
      const nowTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
      const notif: NotificationItem = {
        id: `notif-donasi-${Date.now()}`,
        title: 'Donasi / Infak Diterima',
        message: `Alhamdulillah, terima kasih kepada ${donorName} (${donorRole || 'Warga'}) atas infak/dukungan Rp ${finalAmount.toLocaleString('id-ID')} untuk Gerakan Cimahi Pintar.`,
        date: today,
        time: nowTime,
        category: 'prestasi',
        targetRoles: ['orang_tua', 'siswa', 'super_admin', 'admin_pemkot'],
        isRead: false
      };
      setNotifications(prev => [notif, ...prev]);
    }
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const sendNotification = (notif: Omit<NotificationItem, 'id' | 'date' | 'time' | 'isRead'>) => {
    const today = getTodayDateString();
    const nowTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

    const newNotifItem: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}`,
      date: today,
      time: nowTime,
      isRead: false
    };

    setNotifications(prev => [newNotifItem, ...prev]);
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const resetDemoData = () => {
    Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k));
    setCurrentUser(SEED_USERS[0]);
    setUsers(SEED_USERS);
    setStudents(SEED_STUDENTS);
    setSchools(SEED_SCHOOLS);
    setMosques(SEED_MOSQUES);
    setRecords(SEED_RECORDS);
    setObservations(SEED_OBSERVATIONS);
    setNotifications(SEED_NOTIFICATIONS);
    setLearningMaterials(SEED_LEARNING_MATERIALS);
    setAppSettings(SEED_APP_SETTINGS);
    setCarouselSlides(SEED_CAROUSEL_SLIDES);
    setPillarsConfig(SEED_PILLARS_CONFIG);
    setGerakan5000Config(SEED_GERAKAN_5000_CONFIG);
    setLksSubmissions([]);
  };

  // Super Admin CMS Management Handlers
  const updateAppSettings = (settings: Partial<AppSettings>) => {
    setAppSettings(prev => ({ ...prev, ...settings }));
  };

  const updateCarouselSlide = (id: string, slide: Partial<CarouselSlide>) => {
    setCarouselSlides(prev => prev.map(s => (s.id === id ? { ...s, ...slide } : s)));
  };

  const addCarouselSlide = (slide: Omit<CarouselSlide, 'id'>) => {
    const newSlide: CarouselSlide = {
      ...slide,
      id: `slide-${Date.now()}`
    };
    setCarouselSlides(prev => [...prev, newSlide]);
  };

  const deleteCarouselSlide = (id: string) => {
    setCarouselSlides(prev => prev.filter(s => s.id !== id));
  };

  const updateLearningMaterial = (id: string, material: Partial<LearningMaterial>) => {
    setLearningMaterials(prev => prev.map(m => (m.id === id ? { ...m, ...material } : m)));
  };

  const addLearningMaterial = (material: Omit<LearningMaterial, 'id'>) => {
    const newMat: LearningMaterial = {
      ...material,
      id: `mat-${Date.now()}`
    };
    setLearningMaterials(prev => [...prev, newMat]);
  };

  const deleteLearningMaterial = (id: string) => {
    setLearningMaterials(prev => prev.filter(m => m.id !== id));
  };

  const updatePillarConfig = (category: ActivityCategory, config: Partial<PillarConfig>) => {
    setPillarsConfig(prev =>
      prev.map(p => (p.category === category ? { ...p, ...config } : p))
    );
  };

  const updateGerakan5000Config = (config: Partial<Gerakan5000Config>) => {
    setGerakan5000Config(prev => ({ ...prev, ...config }));
  };

  const updateUser = (id: string, userUpdate: Partial<User>) => {
    setUsers(prev => prev.map(u => (u.id === id ? { ...u, ...userUpdate } : u)));
    if (currentUser?.id === id) {
      setCurrentUser(prev => (prev ? { ...prev, ...userUpdate } : null));
    }
  };

  const addUser = (user: Omit<User, 'id'>) => {
    const newUser: User = {
      ...user,
      id: `usr-${Date.now()}`
    };
    setUsers(prev => [...prev, newUser]);
  };

  const deleteUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
  };

  const updateSchool = (id: string, schoolUpdate: Partial<School>) => {
    setSchools(prev => prev.map(s => (s.id === id ? { ...s, ...schoolUpdate } : s)));
  };

  const addSchool = (school: Omit<School, 'id'>) => {
    const newSchool: School = {
      ...school,
      id: `sch-${Date.now()}`
    };
    setSchools(prev => [...prev, newSchool]);
  };

  const deleteSchool = (id: string) => {
    setSchools(prev => prev.filter(s => s.id !== id));
  };

  const updateMosque = (id: string, mosqueUpdate: Partial<Mosque>) => {
    setMosques(prev => prev.map(m => (m.id === id ? { ...m, ...mosqueUpdate } : m)));
  };

  const addMosque = (mosque: Omit<Mosque, 'id'>) => {
    const newMosque: Mosque = {
      ...mosque,
      id: `msq-${Date.now()}`
    };
    setMosques(prev => [...prev, newMosque]);
  };

  const deleteMosque = (id: string) => {
    setMosques(prev => prev.filter(m => m.id !== id));
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        currentRole,
        isAuthenticated,
        activeAppMode,
        setActiveAppMode,
        activeTab,
        setActiveTab,
        isLoginModalOpen: false,
        setIsLoginModalOpen,
        isGerakan5000InfoOpen,
        setIsGerakan5000InfoOpen,
        users,
        schools,
        mosques,
        teachers,
        parents,
        students,
        records,
        observations,
        learningMaterials,
        lksSubmissions,
        achievements,
        notifications,
        partners,
        cityMetrics,
        appSettings,
        carouselSlides,
        pillarsConfig,
        gerakan5000Config,
        currentStudent,
        currentParent,
        parentChildren,
        selectedChild,
        selectedChildId: selectedChild?.id || '',
        setSelectedChildId,
        currentMosque,
        mosqueStudents,
        mosqueRecords,
        currentTeacher,
        schoolStudents,
        schoolRecords,
        selectedStudentId: currentStudent?.id || selectedChild?.id || '',
        setSelectedStudentId: setSelectedChildId,
        login,
        logout,
        switchRole,
        addActivityRecord,
        confirmActivityParent,
        verifyActivityDKM,
        addTeacherObservation,
        submitDigitalLks,
        recordParticipation5000,
        markNotificationRead,
        markAllNotificationsRead,
        sendNotification,
        deleteNotification,
        resetDemoData,
        updateAppSettings,
        updateCarouselSlide,
        addCarouselSlide,
        deleteCarouselSlide,
        updateLearningMaterial,
        addLearningMaterial,
        deleteLearningMaterial,
        updatePillarConfig,
        updateGerakan5000Config,
        updateUser,
        addUser,
        deleteUser,
        updateSchool,
        addSchool,
        deleteSchool,
        updateMosque,
        addMosque,
        deleteMosque
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
