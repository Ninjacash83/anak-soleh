import {
  User,
  School,
  Mosque,
  Teacher,
  Parent,
  Student,
  ActivityRecord,
  ObservationNote,
  LearningMaterial,
  Achievement,
  NotificationItem,
  EcosystemPartner,
  AppSettings,
  CarouselSlide,
  PillarConfig,
  Gerakan5000Config
} from '../types';
import { getTodayDateString, getRelativeDateString } from '../utils/dateUtils';

import imgGerakan5000 from '../assets/images/carousel_gerakan_5000_1791042966265.jpg';
import imgNasehatSholeh from '../assets/images/carousel_nasehat_sholeh_1791042984235.jpg';
import imgTantangan from '../assets/images/carousel_tantangan_kebiasaan_1791042997432.jpg';
import imgKabarEkosistem from '../assets/images/carousel_kabar_ekosistem_1791043015163.jpg';
import imgLksBelajar from '../assets/images/carousel_lks_belajar_1791043031629.jpg';

const TODAY = getTodayDateString();
const YESTERDAY = getRelativeDateString(-1);
const TWO_DAYS_AGO = getRelativeDateString(-2);

export const SEED_SCHOOLS: School[] = [
  {
    id: 'sch-1',
    name: 'SDN Cimahi Tengah',
    level: 'SD',
    kecamatan: 'Cimahi Tengah',
    address: 'Jl. Dra. Djulaeha Karmita No. 2, Cimahi',
    totalStudents: 480
  },
  {
    id: 'sch-2',
    name: 'SMP Negeri 2 Cimahi',
    level: 'SMP',
    kecamatan: 'Cimahi Tengah',
    address: 'Jl. Sudirman No. 152, Cimahi',
    totalStudents: 890
  },
  {
    id: 'sch-3',
    name: 'SDN Baros Mandiri 1',
    level: 'SD',
    kecamatan: 'Cimahi Tengah',
    address: 'Jl. Baros No. 24, Cimahi',
    totalStudents: 420
  },
  {
    id: 'sch-4',
    name: 'SMAN 1 Cimahi',
    level: 'SMA',
    kecamatan: 'Cimahi Utara',
    address: 'Jl. Pasar Atas No. 65, Cimahi',
    totalStudents: 1020
  }
];

export const SEED_MOSQUES: Mosque[] = [
  {
    id: 'msq-1',
    name: 'Masjid Al-Hidayah',
    kecamatan: 'Cimahi Utara',
    address: 'Jl. Cipageran Indah Blok B, Cimahi Utara',
    dkmLeader: 'Ustadz DKM Al-Hidayah',
    activeStudentsCount: 46
  },
  {
    id: 'msq-2',
    name: 'Masjid Agung Cimahi',
    kecamatan: 'Cimahi Tengah',
    address: 'Jl. Kaum No. 2, Alun-Alun Cimahi Tengah',
    dkmLeader: 'KH. Ahmad Syarif',
    activeStudentsCount: 118
  },
  {
    id: 'msq-3',
    name: 'Masjid Al-Ukhuwah Baros',
    kecamatan: 'Cimahi Selatan',
    address: 'Jl. Raya Baros No. 88, Cimahi Selatan',
    dkmLeader: 'Ustadz Ridwan Kamiludin',
    activeStudentsCount: 64
  }
];

export const SEED_TEACHERS: Teacher[] = [
  {
    id: 'tch-1',
    name: 'Ustadz Rahman, S.Pd.I',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    subject: 'PAI & Budi Pekerti',
    phone: '0812-2345-6789'
  },
  {
    id: 'tch-2',
    name: 'Ibu Hj. Siti Maryam, S.Ag',
    schoolId: 'sch-1',
    schoolName: 'SDN Cimahi Tengah',
    subject: 'PAI & Budi Pekerti',
    phone: '0813-9876-5432'
  },
  {
    id: 'tch-3',
    name: 'Drs. H. Deden Supriatna, M.Pd',
    schoolId: 'sch-4',
    schoolName: 'SMAN 1 Cimahi',
    subject: 'PAI & Budi Pekerti',
    phone: '0811-2233-4455'
  }
];

export const SEED_PARENTS: Parent[] = [
  {
    id: 'par-1',
    name: 'Bunda Aisyah',
    phone: '0812-3456-7890',
    email: 'parent@example.com',
    address: 'Komp. Cipageran Asri Blok C-12, Cimahi',
    childrenIds: ['std-1', 'std-2']
  },
  {
    id: 'par-2',
    name: 'Ayah Hendra Pratama',
    phone: '0813-4567-8901',
    email: 'hendra@example.com',
    address: 'Jl. Pesantren No. 19, Cimahi Utara',
    childrenIds: ['std-3']
  },
  {
    id: 'par-3',
    name: 'Ibu Ratna Sari',
    phone: '0815-6789-0123',
    email: 'ratna@example.com',
    address: 'Jl. Melong Asih No. 40, Cimahi Selatan',
    childrenIds: ['std-4']
  }
];

export const SEED_STUDENTS: Student[] = [
  {
    id: 'std-1',
    name: 'Ahmad Faiz',
    grade: 'Kelas 5',
    jenjang: 'SD',
    schoolId: 'sch-1',
    schoolName: 'SDN Cimahi Tengah',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    kecamatan: 'Cimahi Tengah',
    parentId: 'par-1',
    parentName: 'Bunda Aisyah',
    parentPhone: '0812-3456-7890',
    teacherId: 'tch-2',
    teacherName: 'Ibu Hj. Siti Maryam, S.Ag',
    avatar: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=240&auto=format&fit=crop&q=80',
    streakDays: 6,
    characterScore: 92,
    totalCompletedActivities: 48
  },
  {
    id: 'std-2',
    name: 'Siti Nabila Zahra',
    grade: 'Kelas 8',
    jenjang: 'SMP',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    mosqueId: 'msq-2',
    mosqueName: 'Masjid Agung Cimahi',
    kecamatan: 'Cimahi Tengah',
    parentId: 'par-1',
    parentName: 'Bunda Aisyah',
    parentPhone: '0812-3456-7890',
    teacherId: 'tch-1',
    teacherName: 'Ustadz Rahman, S.Pd.I',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=240&auto=format&fit=crop&q=80',
    streakDays: 14,
    characterScore: 95,
    totalCompletedActivities: 74
  },
  {
    id: 'std-3',
    name: 'Muhammad Rizky Pratama',
    grade: 'Kelas 8',
    jenjang: 'SMP',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    kecamatan: 'Cimahi Utara',
    parentId: 'par-2',
    parentName: 'Ayah Hendra Pratama',
    parentPhone: '0813-4567-8901',
    teacherId: 'tch-1',
    teacherName: 'Ustadz Rahman, S.Pd.I',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=240&auto=format&fit=crop&q=80',
    streakDays: 5,
    characterScore: 88,
    totalCompletedActivities: 39
  },
  {
    id: 'std-4',
    name: 'Putri Aisyah Humaira',
    grade: 'Kelas 11',
    jenjang: 'SMA',
    schoolId: 'sch-4',
    schoolName: 'SMAN 1 Cimahi',
    mosqueId: 'msq-3',
    mosqueName: 'Masjid Al-Ukhuwah Baros',
    kecamatan: 'Cimahi Selatan',
    parentId: 'par-3',
    parentName: 'Ibu Ratna Sari',
    parentPhone: '0815-6789-0123',
    teacherId: 'tch-3',
    teacherName: 'Drs. H. Deden Supriatna, M.Pd',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=240&auto=format&fit=crop&q=80',
    streakDays: 11,
    characterScore: 90,
    totalCompletedActivities: 61
  }
];

export const SEED_USERS: User[] = [
  {
    id: 'usr-siswa-1',
    name: 'Ahmad Faiz',
    emailOrPhone: 'student@example.com',
    password: 'password123',
    role: 'siswa',
    avatar: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=240&auto=format&fit=crop&q=80',
    entityId: 'std-1',
    entityName: 'Kelas 5 • SDN Cimahi Tengah',
    title: 'Siswa Kelas 5 SD'
  },
  {
    id: 'usr-siswa-2',
    name: 'Siti Nabila Zahra',
    emailOrPhone: 'nabila@example.com',
    password: 'password123',
    role: 'siswa',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=240&auto=format&fit=crop&q=80',
    entityId: 'std-2',
    entityName: 'Kelas 8 • SMP Negeri 2 Cimahi',
    title: 'Siswa Kelas 8 SMP'
  },
  {
    id: 'usr-ortu-1',
    name: 'Bunda Aisyah',
    emailOrPhone: 'parent@example.com',
    password: 'password123',
    role: 'orang_tua',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=240&auto=format&fit=crop&q=80',
    entityId: 'par-1',
    entityName: 'Wali Murid (Ahmad Faiz & Siti Nabila)',
    title: 'Orang Tua / Pendamping Keluarga'
  },
  {
    id: 'usr-dkm-1',
    name: 'Ustadz DKM Al-Hidayah',
    emailOrPhone: 'dkm@example.com',
    password: 'password123',
    role: 'dkm',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=240&auto=format&fit=crop&q=80',
    entityId: 'msq-1',
    entityName: 'Masjid Al-Hidayah • Cimahi Utara',
    title: 'Ketua Pembina Maghrib Mengaji'
  },
  {
    id: 'usr-guru-1',
    name: 'Ustadz Rahman, S.Pd.I',
    emailOrPhone: 'teacher@example.com',
    password: 'password123',
    role: 'guru_agama',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=240&auto=format&fit=crop&q=80',
    entityId: 'tch-1',
    entityName: 'SMP Negeri 2 Cimahi',
    title: 'Guru PAI & Budi Pekerti'
  },
  {
    id: 'usr-admin-1',
    name: 'Admin Pemkot Cimahi',
    emailOrPhone: 'admin@example.com',
    password: 'password123',
    role: 'admin_pemkot',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=240&auto=format&fit=crop&q=80',
    entityId: 'pemkot',
    entityName: 'Pemerintah Kota Cimahi',
    title: 'Koordinator Ekosistem Kota'
  },
  {
    id: 'usr-superadmin-1',
    name: 'Super Administrator',
    emailOrPhone: 'superadmin@example.com',
    password: 'admin123',
    role: 'super_admin',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=240&auto=format&fit=crop&q=80',
    entityId: 'adm-root',
    entityName: 'Pusat Manajemen Sholeh Cendekia',
    title: 'Super Admin & Pengelola Sistem Utama'
  }
];

export const SEED_RECORDS: ActivityRecord[] = [
  {
    id: 'rec-101',
    studentId: 'std-1',
    studentName: 'Ahmad Faiz',
    schoolId: 'sch-1',
    schoolName: 'SDN Cimahi Tengah',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    date: TODAY,
    time: '04:45',
    category: 'subuh_berjamaah',
    title: 'Sholat Subuh Berjamaah di Masjid Al-Hidayah',
    description: 'Hadir tepat waktu sebelum iqomah bersama Ayah di shaf depan.',
    companion: 'Ayah',
    status: 'diverifikasi_dkm',
    notes: 'Alhamdulillah segar bangun pukul 04.15 WIB.',
    dkmVerified: true,
    dkmVerifierName: 'Ustadz DKM Al-Hidayah',
    dkmNote: 'Hadir tepat waktu dan ikut dzikir pagi.',
    dkmVerifiedAt: '05:20',
    parentConfirmed: true,
    parentNote: 'Barakallah nak, semoga istiqomah selalu.',
    parentConfirmedAt: '06:00'
  },
  {
    id: 'rec-102',
    studentId: 'std-1',
    studentName: 'Ahmad Faiz',
    schoolId: 'sch-1',
    schoolName: 'SDN Cimahi Tengah',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    date: TODAY,
    time: '18:20',
    category: 'maghrib_mengaji',
    title: 'Setoran Hafalan QS. An-Naba Ayat 1-20',
    description: 'Mengikuti halaqah Maghrib Mengaji dan perbaikan makhraj huruf.',
    companion: 'Guru Mengaji',
    status: 'dicatat',
    notes: 'Menunggu verifikasi Ustadz pembina.',
    dkmVerified: false,
    parentConfirmed: false
  },
  {
    id: 'rec-103',
    studentId: 'std-1',
    studentName: 'Ahmad Faiz',
    schoolId: 'sch-1',
    schoolName: 'SDN Cimahi Tengah',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    date: YESTERDAY,
    time: '19:30',
    category: 'tilawah_belajar',
    title: 'Tadarus Al-Mulk & Mengerjakan LKS Matematika Kelas 5',
    description: 'Membaca 15 ayat dan menyelesaikan latihan soal pecahan.',
    companion: 'Ibu',
    status: 'dikonfirmasi_ortu',
    dkmVerified: true,
    dkmVerifierName: 'Ustadz DKM Al-Hidayah',
    dkmVerifiedAt: '20:10',
    parentConfirmed: true,
    parentNote: 'Belajar dengan tekun tanpa main game.',
    parentConfirmedAt: '20:00'
  },
  {
    id: 'rec-104',
    studentId: 'std-1',
    studentName: 'Ahmad Faiz',
    schoolId: 'sch-1',
    schoolName: 'SDN Cimahi Tengah',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    date: YESTERDAY,
    time: '06:15',
    category: 'kebaikan_kepedulian',
    title: 'Merapikan Tempat Tidur & Infak Subuh',
    description: 'Membantu Ibu menyapu teras rumah dan mengisi kotak infak subuh.',
    companion: 'Orang Tua',
    status: 'diverifikasi_dkm',
    dkmVerified: true,
    dkmVerifierName: 'Ustadz DKM Al-Hidayah',
    dkmVerifiedAt: '07:00',
    parentConfirmed: true,
    parentNote: 'Terima kasih anak sholeh sudah meringankan tugas Bunda.',
    parentConfirmedAt: '06:40'
  },
  {
    id: 'rec-201',
    studentId: 'std-2',
    studentName: 'Siti Nabila Zahra',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    mosqueId: 'msq-2',
    mosqueName: 'Masjid Agung Cimahi',
    date: TODAY,
    time: '04:50',
    category: 'subuh_berjamaah',
    title: 'Sholat Subuh & Dzikir Pagi',
    description: 'Melaksanakan sholat subuh tepat waktu bersama keluarga.',
    companion: 'Orang Tua',
    status: 'dikonfirmasi_ortu',
    dkmVerified: true,
    dkmVerifierName: 'KH. Ahmad Syarif',
    dkmVerifiedAt: '05:30',
    parentConfirmed: true,
    parentNote: 'Alhamdulillah Kakak Nabila bangun paling pagi.',
    parentConfirmedAt: '05:45'
  },
  {
    id: 'rec-202',
    studentId: 'std-2',
    studentName: 'Siti Nabila Zahra',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    mosqueId: 'msq-2',
    mosqueName: 'Masjid Agung Cimahi',
    date: TODAY,
    time: '18:25',
    category: 'maghrib_mengaji',
    title: 'Tadarus Juz 29 & Kajian Tajwid Mad Wajib',
    description: 'Mengaji ba’da maghrib bersama remaja putri Masjid Agung.',
    companion: 'Guru Mengaji',
    status: 'dicatat',
    dkmVerified: false,
    parentConfirmed: false
  },
  {
    id: 'rec-203',
    studentId: 'std-2',
    studentName: 'Siti Nabila Zahra',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    mosqueId: 'msq-2',
    mosqueName: 'Masjid Agung Cimahi',
    date: TODAY,
    time: '16:10',
    category: 'tilawah_belajar',
    title: 'Menyelesaikan LKS Adab Pergaulan & Sains Kelas 8',
    description: 'Mengerjakan LKS digital di HP dan merangkum materi PAI.',
    companion: 'Mandiri',
    status: 'dikonfirmasi_ortu',
    dkmVerified: true,
    dkmVerifierName: 'KH. Ahmad Syarif',
    parentConfirmed: true,
    parentNote: 'Sudah Bunda periksa catatannya rapi sekali.',
    parentConfirmedAt: '17:00'
  },
  {
    id: 'rec-301',
    studentId: 'std-3',
    studentName: 'Muhammad Rizky Pratama',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    date: TODAY,
    time: '04:48',
    category: 'subuh_berjamaah',
    title: 'Sholat Subuh Berjamaah di Masjid Al-Hidayah',
    description: 'Hadir sholat subuh berjamaah bersama teman sebaya.',
    companion: 'Rekan Sebaya',
    status: 'dicatat',
    notes: 'Hadir di shaf kedua.',
    dkmVerified: false,
    parentConfirmed: true,
    parentNote: 'Berangkat ke masjid bersama ayah.',
    parentConfirmedAt: '05:30'
  },
  {
    id: 'rec-302',
    studentId: 'std-3',
    studentName: 'Muhammad Rizky Pratama',
    schoolId: 'sch-2',
    schoolName: 'SMP Negeri 2 Cimahi',
    mosqueId: 'msq-1',
    mosqueName: 'Masjid Al-Hidayah',
    date: TODAY,
    time: '18:30',
    category: 'maghrib_mengaji',
    title: 'Tahsin Surah Al-Kahfi Ayat 1-10',
    description: 'Setoran bacaan Al-Kahfi kepada Ustadz DKM Al-Hidayah.',
    companion: 'Guru Mengaji',
    status: 'dicatat',
    dkmVerified: false,
    parentConfirmed: false
  },
  {
    id: 'rec-401',
    studentId: 'std-4',
    studentName: 'Putri Aisyah Humaira',
    schoolId: 'sch-4',
    schoolName: 'SMAN 1 Cimahi',
    mosqueId: 'msq-3',
    mosqueName: 'Masjid Al-Ukhuwah Baros',
    date: TWO_DAYS_AGO,
    time: '04:42',
    category: 'subuh_berjamaah',
    title: 'Subuh Berjamaah & Kultum Remaja',
    description: 'Menyimak kultum subuh dan mencatat poin hikmah.',
    companion: 'Orang Tua',
    status: 'diverifikasi_dkm',
    dkmVerified: true,
    dkmVerifierName: 'Ustadz Ridwan Kamiludin',
    parentConfirmed: true
  }
];

export const SEED_OBSERVATIONS: ObservationNote[] = [
  {
    id: 'obs-1',
    studentId: 'std-1',
    studentName: 'Ahmad Faiz',
    schoolId: 'sch-1',
    mosqueId: 'msq-1',
    authorRole: 'dkm',
    authorName: 'Ustadz DKM Al-Hidayah',
    date: TODAY,
    aspect: 'Makhraj & Tilawah',
    content: 'Alhamdulillah bacaan hukum nun mati dan tanwin Ananda Faiz pada Juz 30 semakin fasih dan tartil. Pertahankan kehadiran Maghrib Mengaji.'
  },
  {
    id: 'obs-2',
    studentId: 'std-1',
    studentName: 'Ahmad Faiz',
    schoolId: 'sch-1',
    mosqueId: 'msq-1',
    authorRole: 'guru_agama',
    authorName: 'Ibu Hj. Siti Maryam, S.Ag',
    date: YESTERDAY,
    aspect: 'Adab & Karakter',
    content: 'Di kelas 5 sangat santun kepada guru, rajin memimpin doa sebelum belajar, dan ringan tangan membantu teman.'
  },
  {
    id: 'obs-3',
    studentId: 'std-2',
    studentName: 'Siti Nabila Zahra',
    schoolId: 'sch-2',
    mosqueId: 'msq-2',
    authorRole: 'guru_agama',
    authorName: 'Ustadz Rahman, S.Pd.I',
    date: TODAY,
    aspect: 'Sholat & Ibadah',
    content: 'Nabila menjadi teladan siswi kelas 8 SMPN 2 Cimahi dalam pelaksanaan sholat Dhuha dan ketertiban pengisian Buku Kendali.'
  },
  {
    id: 'obs-4',
    studentId: 'std-3',
    studentName: 'Muhammad Rizky Pratama',
    schoolId: 'sch-2',
    mosqueId: 'msq-1',
    authorRole: 'dkm',
    authorName: 'Ustadz DKM Al-Hidayah',
    date: YESTERDAY,
    aspect: 'Kepedulian Sosial',
    content: 'Rizky aktif membantu menata mukena dan sajadah Masjid Al-Hidayah selepas sholat berjamaah.'
  }
];

export const SEED_LEARNING_MATERIALS: LearningMaterial[] = [
  {
    id: 'lks-1',
    title: 'LKS Fiqih Sholat Berjamaah & Adab di Masjid',
    type: 'lks',
    jenjang: 'SD',
    kelas: 'Kelas 5',
    subject: 'PAI & Budi Pekerti',
    tema: 'Ibadah Harian',
    category: 'LKS Digital & Cetak',
    estimatedTime: '20 Menit',
    durationOrPages: '4 Halaman • 3 Soal',
    description: 'Lembar Kerja Siswa interaktif tentang keutamaan sholat Subuh berjamaah, tata cara makmum masbuq, serta adab menjaga ketenangan di masjid.',
    source: 'Tim Kurikulum PAI & DKM Kota Cimahi',
    thumbnail: 'https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?w=600&auto=format&fit=crop&q=80',
    digitalAvailable: true,
    pdfAvailable: true,
    summaryContent: 'Sholat berjamaah di masjid memiliki keutamaan 27 derajat dibandingkan sholat sendirian. Ketika memasuki masjid, dahulukan kaki kanan sambil membaca doa masuk masjid, menjaga ketenangan, dan merapatkan shaf.',
    mcQuestions: [
      {
        id: 'q1',
        question: 'Berapa derajat keutamaan sholat berjamaah dibandingkan sholat sendirian menurut hadits Nabi SAW?',
        options: ['10 derajat', '17 derajat', '27 derajat', '70 derajat'],
        correctIndex: 2
      },
      {
        id: 'q2',
        question: 'Apa yang harus dilakukan makmum jika datang terlambat (masbuq) saat imam sedang ruku?',
        options: [
          'Menunggu imam berdiri ke rakaat berikutnya',
          'Takbiratul ihram lalu segera mengikuti gerakan imam',
          'Membuat jamaah baru sendiri di belakang',
          'Berlari kencang di dalam masjid'
        ],
        correctIndex: 1
      },
      {
        id: 'q3',
        question: 'Manakah yang termasuk adab mulia seorang siswa ketika berada di dalam masjid?',
        options: [
          'Berbicara keras dan bercanda saat dzikir',
          'Melangkahi pundak jamaah lain',
          'Menjaga kebersihan, merapatkan shaf, dan menyimak pengajian',
          'Membiarkan Al-Qur’an terbuka di lantai'
        ],
        correctIndex: 2
      }
    ],
    shortAnswerPrompt: 'Tuliskan pengalamanmu mengikuti Subuh Berjamaah atau Maghrib Mengaji minggu ini di masjid dekat rumahmu!',
    checklistItems: [
      'Saya sudah menghafal doa masuk dan keluar masjid',
      'Saya merapikan sandal ketika tiba di masjid',
      'Saya menjaga ketenangan saat imam atau ustadz sedang berbicara'
    ]
  },
  {
    id: 'lks-2',
    title: 'LKS Matematika Kelas 5: Pecahan & Hitung Zakat/Sedekah',
    type: 'lks',
    jenjang: 'SD',
    kelas: 'Kelas 5',
    subject: 'Matematika',
    tema: 'Penalaran & Logika',
    category: 'LKS Digital & Cetak',
    estimatedTime: '25 Menit',
    durationOrPages: '6 Halaman • Soal Cerita',
    description: 'Belajar operasi pecahan dan persentase melalui studi kasus nyata perhitungan zakat fitrah, pembagian sedekah, dan tabungan kebaikan harian.',
    source: 'MGMP Matematika & Sholeh Cendekia Cimahi',
    thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80',
    digitalAvailable: true,
    pdfAvailable: true,
    summaryContent: 'Ilmu matematika sangat dekat dengan amal kebaikan sehari-hari. Melalui pecahan dan persentase, kita dapat menghitung penyisihan infak, zakat (2,5%), dan mengatur tabungan siswa dengan cermat.',
    mcQuestions: [
      {
        id: 'm1',
        question: 'Faiz menyisihkan uang saku Rp20.000 selama seminggu. Jika 1/4 bagiannya dimasukkan ke kotak infak Subuh, berapa rupiah yang diinfakkan Faiz?',
        options: ['Rp2.500', 'Rp4.000', 'Rp5.000', 'Rp10.000'],
        correctIndex: 2
      },
      {
        id: 'm2',
        question: 'Dalam satu pekan (7 hari), Ahmad hadir Subuh berjamaah di masjid selama 6 hari. Berapakah bentuk pecahan kehadiran Ahmad?',
        options: ['5/7', '6/7', '7/6', '1/7'],
        correctIndex: 1
      },
      {
        id: 'm3',
        question: 'Hasil penjumlahan pecahan 1/2 + 1/4 adalah...',
        options: ['2/6', '3/4', '2/4', '4/4'],
        correctIndex: 1
      }
    ],
    shortAnswerPrompt: 'Jika kamu memiliki uang tabungan Rp50.000, bagaimana rencanamu membaginya untuk keperluan sekolah, tabungan, dan sedekah?',
    checklistItems: [
      'Saya memahami cara menyamakan penyebut pada penjumlahan pecahan',
      'Saya dapat menghitung nilai pecahan dari jumlah uang rupiah',
      'Saya terbiasa menyisihkan sebagian uang saku untuk kebaikan'
    ]
  },
  {
    id: 'lks-3',
    title: 'LKS Adab Pergaulan Remaja & Literasi Digital Islami',
    type: 'lks',
    jenjang: 'SMP',
    kelas: 'Kelas 8',
    subject: 'Akhlak & Adab',
    tema: 'Adab Keluarga & Sosial',
    category: 'LKS Digital & Cetak',
    estimatedTime: '20 Menit',
    durationOrPages: '5 Halaman • Studi Kasus',
    description: 'Panduan praktis siswa SMP menjaga lisan di media sosial, birrul walidain (bakti orang tua), dan memilih pergaulan yang positif.',
    source: 'Forum Guru PAI SMP Kota Cimahi',
    thumbnail: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&auto=format&fit=crop&q=80',
    digitalAvailable: true,
    pdfAvailable: true,
    summaryContent: 'Seorang remaja muslim yang cerdas senantiasa menerapkan prinsip tabayyun (cek kebenaran informasi) sebelum menyebarkan kabar, menjaga kesantunan komentar di dunia maya, serta memuliakan orang tua dan guru.',
    mcQuestions: [
      {
        id: 'a1',
        question: 'Sikap memeriksa kebenaran suatu berita sebelum membagikannya di grup pesan disebut...',
        options: ['Takabur', 'Tabayyun', 'Tasamuh', 'Tawakal'],
        correctIndex: 1
      },
      {
        id: 'a2',
        question: 'Ketika orang tua meminta bantuan saat kita sedang memegang HP, sikap terbaik adalah...',
        options: [
          'Meminta orang tua menunggu sampai permainan selesai',
          'Segera meletakkan HP, menjawab dengan sopan, dan membantu',
          'Pura-pura tidak mendengar panggilan',
          'Menjawab dengan nada tinggi'
        ],
        correctIndex: 1
      }
    ],
    shortAnswerPrompt: 'Tuliskan satu komitmenmu untuk menggunakan HP dan waktu luang secara lebih bermanfaat di luar jam sekolah!',
    checklistItems: [
      'Saya membatasi waktu layar (screen time) malam hari agar bangun Subuh tepat waktu',
      'Saya selalu bertutur kata sopan di grup kelas maupun media sosial',
      'Saya meminta izin dan doa orang tua sebelum berangkat sekolah'
    ]
  },
  {
    id: 'lks-4',
    title: 'LKS Sains & Tadabbur Alam: Siklus Air & Pelestarian Lingkungan',
    type: 'lks',
    jenjang: 'SMP',
    kelas: 'Kelas 8',
    subject: 'Sains & Alam',
    tema: 'Tadabbur Alam',
    category: 'LKS Digital & Cetak',
    estimatedTime: '30 Menit',
    durationOrPages: '6 Halaman • Observasi',
    description: 'Mengintegrasikan ilmu IPA tentang siklus hidrologi dengan perintah menjaga kelestarian lingkungan dan berhemat air saat berwudhu.',
    source: 'Tim Sains Cendekia Kota Cimahi',
    thumbnail: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600&auto=format&fit=crop&q=80',
    digitalAvailable: true,
    pdfAvailable: true,
    summaryContent: 'Air adalah nikmat besar yang diatur melalui siklus evaporasi, kondensasi, dan presipitasi. Rasulullah SAW mencontohkan penghematan air saat berwudhu meskipun berada di tepi sungai yang mengalir.',
    mcQuestions: [
      {
        id: 's1',
        question: 'Proses penguapan air laut dan sungai karena panas matahari dalam siklus hidrologi disebut...',
        options: ['Kondensasi', 'Evaporasi', 'Presipitasi', 'Infiltrasi'],
        correctIndex: 1
      },
      {
        id: 's2',
        question: 'Bagaimana sikap siswa sholeh saat membuka keran air untuk berwudhu di masjid atau sekolah?',
        options: [
          'Membuka keran sebesar-besarnya agar cepat selesai',
          'Membuka keran secukupnya dan menutup rapat setelah selesai',
          'Membiarkan keran menetes setelah wudhu',
          'Bermain cipratan air bersama teman'
        ],
        correctIndex: 1
      }
    ],
    shortAnswerPrompt: 'Sebutkan 2 langkah nyata yang bisa kamu lakukan di sekolah dan di rumah untuk mengurangi sampah plastik!',
    checklistItems: [
      'Saya menggunakan air secukupnya saat berwudhu',
      'Saya membuang sampah pada tempatnya di lingkungan sekolah & masjid',
      'Saya membawa botol minum (tumbler) sendiri ke sekolah'
    ]
  },
  {
    id: 'lks-5',
    title: 'LKS Kepemimpinan Pemuda & Perencanaan Masa Depan (SMA)',
    type: 'lks',
    jenjang: 'SMA',
    kelas: 'Kelas 11',
    subject: 'PAI & Budi Pekerti',
    tema: 'Kepemimpinan & Karakter',
    category: 'LKS Digital & Cetak',
    estimatedTime: '25 Menit',
    durationOrPages: '5 Halaman • Refleksi',
    description: 'Modul latihan kepemimpinan remaja masjid dan OSIS, manajemen waktu belajar-ibadah, serta etika berorganisasi bagi siswa SMA/SMK.',
    source: 'ICMI Orda Cimahi & Disdik',
    thumbnail: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=600&auto=format&fit=crop&q=80',
    digitalAvailable: true,
    pdfAvailable: true,
    summaryContent: 'Pemuda yang tumbuh dalam ketaatan beribadah dan kedisiplinan ilmu adalah aset utama kemajuan bangsa. Manajemen waktu antara sholat tepat waktu, belajar akademik, dan kontribusi sosial melatih jiwa kepemimpinan sejati.',
    mcQuestions: [
      {
        id: 'k1',
        question: 'Sifat pemimpin yang dapat dipercaya dalam menjalankan tanggung jawab disebut...',
        options: ['Amanah', 'Khianat', 'Ghibah', 'Takabur'],
        correctIndex: 0
      },
      {
        id: 'k2',
        question: 'Prioritas utama ketika waktu sholat tiba di tengah rapat kegiatan siswa adalah...',
        options: [
          'Menunda sholat hingga rapat selesai larut malam',
          'Menghentikan sejenak rapat untuk sholat berjamaah tepat waktu',
          'Meninggalkan tanggung jawab tanpa izin',
          'Mengabaikan panggilan adzan'
        ],
        correctIndex: 1
      }
    ],
    shortAnswerPrompt: 'Tuliskan target prestasi akademik dan target ibadah yang ingin kamu capai pada semester ini!',
    checklistItems: [
      'Saya menyusun jadwal harian antara belajar, organisasi, dan ibadah',
      'Saya menjaga sholat 5 waktu tepat waktu',
      'Saya aktif berkontribusi positif di lingkungan sekolah atau remaja masjid'
    ]
  }
];

export const SEED_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach-1',
    title: 'Pejuang Fajar Cimahi',
    description: 'Melaksanakan Sholat Subuh Berjamaah di masjid selama 7 hari berturut-turut dengan verifikasi DKM.',
    category: 'Subuh Berjamaah',
    isUnlocked: true,
    unlockedDate: YESTERDAY,
    progressPercent: 100,
    criteria: '7 Hari Subuh Berjamaah'
  },
  {
    id: 'ach-2',
    title: 'Sahabat Al-Qur’an',
    description: 'Menyelesaikan target Maghrib Mengaji dan tilawah harian selama 14 hari tanpa putus.',
    category: 'Maghrib Mengaji',
    isUnlocked: true,
    unlockedDate: TWO_DAYS_AGO,
    progressPercent: 100,
    criteria: '14 Hari Maghrib Mengaji'
  },
  {
    id: 'ach-3',
    title: 'Bintang LKS Cendekia',
    description: 'Menyelesaikan minimal 5 Lembar Kerja Siswa (LKS) dengan nilai pemahaman di atas 85.',
    category: 'Tilawah & Belajar',
    isUnlocked: false,
    progressPercent: 80,
    criteria: '4 / 5 LKS Selesai'
  },
  {
    id: 'ach-4',
    title: 'Duta Akhlak & Bakti Orang Tua',
    description: 'Memperoleh 30 konfirmasi kegiatan Kebaikan & Kepedulian dari Orang Tua dan Guru Agama.',
    category: 'Kebaikan & Kepedulian',
    isUnlocked: false,
    progressPercent: 75,
    criteria: '23 / 30 Konfirmasi Kebaikan'
  }
];

export const SEED_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-task-1',
    title: 'Tugas Baru: LKS Tadarus & Makna Sholat',
    message: 'Ustadz Rahman telah menugaskan Lembar Kerja Siswa (LKS) Tadarus & Makna Bacaan Sholat untuk dikerjakan pekan ini.',
    date: TODAY,
    time: '07:15',
    category: 'tugas',
    targetRoles: ['siswa', 'orang_tua', 'guru_agama'],
    sender: 'Ustadz Rahman, S.Pd.I',
    senderRole: 'Guru Agama PAI',
    priority: 'high',
    actionTab: 'belajar',
    actionLabel: 'Kerjakan LKS',
    isRead: false
  },
  {
    id: 'notif-msg-1',
    title: 'Pesan dari Sekolah: Portofolio Karakter Bulan Ini',
    message: 'Laporan rekapitulasi amalan Subuh Berjamaah & Maghrib Mengaji ananda telah disahkan dan siap ditinjau oleh Orang Tua.',
    date: TODAY,
    time: '08:30',
    category: 'pesan_sekolah',
    targetRoles: ['orang_tua', 'siswa', 'guru_agama'],
    sender: 'Dinas Pendidikan & PAI SDN Cimahi Tengah',
    senderRole: 'Sekolah & Guru PAI',
    priority: 'normal',
    actionTab: 'buku_kendali',
    actionLabel: 'Lihat Portofolio',
    isRead: false
  },
  {
    id: 'notif-event-1',
    title: 'Agenda Akbar: Gerakan Subuh Berjamaah Serentak Kota Cimahi',
    message: 'Mengundang seluruh siswa, orang tua, dan DKM masjid se-Kota Cimahi untuk menghadiri Sholat Subuh Berjamaah & Tausiyah Akbar di Masjid Agung Cimahi.',
    date: TODAY,
    time: '09:00',
    category: 'agenda_karakter',
    targetRoles: ['siswa', 'orang_tua', 'dkm', 'guru_agama', 'admin_pemkot', 'super_admin'],
    sender: 'Bagian Kesra Pemkot & DMI Kota Cimahi',
    senderRole: 'Pemerintah Kota Cimahi',
    priority: 'high',
    eventDate: 'Ahad, 11 Oktober 2026 • 04.15 WIB',
    eventLocation: 'Masjid Agung Kota Cimahi (Alun-Alun Cimahi)',
    actionTab: 'beranda',
    actionLabel: 'Lihat Info Acara',
    isRead: false
  },
  {
    id: 'notif-msg-2',
    title: 'Pesan DKM: Pembinaan Tahsin Maghrib Mengaji',
    message: 'Jadwal bimbingan Makhraj & Tajwid santri binaan Masjid Al-Hidayah dimulai ba\'da Sholat Maghrib. Mohon hadir tepat waktu.',
    date: TODAY,
    time: '15:45',
    category: 'pesan_sekolah',
    targetRoles: ['siswa', 'orang_tua', 'dkm'],
    sender: 'Ustadz DKM Al-Hidayah',
    senderRole: 'DKM Masjid',
    priority: 'normal',
    actionTab: 'buku_kendali',
    actionLabel: 'Buka Buku Kendali',
    isRead: false
  },
  {
    id: 'notif-task-2',
    title: 'Tantangan 3 Kebaikan di Rumah',
    message: 'Catat minimal 1 amalan kebaikan (membantu orang tua / menjaga kebersihan / sedekah subuh) pada Buku Kendali hari ini.',
    date: TODAY,
    time: '16:00',
    category: 'tugas',
    targetRoles: ['siswa', 'orang_tua'],
    sender: 'Sistem Pembinaan Karakter',
    senderRole: 'Sholeh Cendekia',
    priority: 'normal',
    actionTab: 'buku_kendali',
    actionLabel: 'Catat Kebaikan',
    isRead: false
  },
  {
    id: 'notif-event-2',
    title: 'Festival Cendekia: Penyerahan Lencana Bintang Karakter',
    message: 'Apresiasi bagi santri & siswa dengan konsistensi 30 hari aktif pembiasaan ibadah tingkat Kecamatan Cimahi Utara & Tengah.',
    date: YESTERDAY,
    time: '11:00',
    category: 'agenda_karakter',
    targetRoles: ['siswa', 'orang_tua', 'dkm', 'guru_agama', 'admin_pemkot', 'super_admin'],
    sender: 'Disdik Kota Cimahi',
    senderRole: 'Pemerintah Kota',
    priority: 'normal',
    eventDate: 'Sabtu, 24 Oktober 2026 • 08.00 WIB',
    eventLocation: 'Aula Gedung Cimahi Technopark',
    actionTab: 'prestasi',
    actionLabel: 'Cek Kriteria Lencana',
    isRead: true
  }
];

export const SEED_PARTNERS: EcosystemPartner[] = [
  {
    name: 'ITEC & Masagi Cendekia Berkah',
    role: 'Pengembang Teknologi, Arsitektur Platform Digital & Modul Pembelajaran Interaktif',
    category: 'teknologi',
    description: 'Developer resmi platform Sholeh Cendekia Cimahi dan penyedia sistem pembelajaran digital mandiri & LKS.',
    badge: 'Official Developer'
  },
  {
    name: 'Pemerintah Kota Cimahi',
    role: 'Payung kebijakan daerah, koordinasi lintas instansi, dan pembina umum pembentukan karakter kota',
    category: 'pemerintah',
    description: 'Mendukung gerakan moral dan spiritual untuk mewujudkan generasi Cimahi yang sholeh dan berdaya saing.',
    badge: 'Kolaborator Utama'
  },
  {
    name: 'Dinas Pendidikan Kota Cimahi',
    role: 'Integrasi Buku Kendali dengan kurikulum PAI, pembinaan guru agama, dan portofolio siswa SD/SMP',
    category: 'pemerintah',
    description: 'Menyelaraskan pembiasaan ibadah harian siswa dengan capaian pembelajaran dan rapor sekolah.',
    badge: 'Kolaborator Pendidikan'
  },
  {
    name: 'Dinas Sosial Kota Cimahi',
    role: 'Sinergi pemberdayaan sosial, perlindungan anak, dan kepedulian bagi keluarga dhuafa',
    category: 'pemerintah',
    description: 'Memperkuat pilar kepedulian sosial, santunan yatim/dhuafa, dan inklusivitas pendidikan anak.',
    badge: 'Kolaborator Sosial'
  },
  {
    name: 'DMI (Dewan Masjid Indonesia) Kota Cimahi',
    role: 'Optimalisasi peran 342 DKM Masjid se-Cimahi sebagai pusat Subuh Berjamaah & Maghrib Mengaji',
    category: 'keagamaan',
    description: 'Menghubungkan jaringan masjid ramah anak dan verifikasi amalan jamaah santri berbasis wilayah.',
    badge: 'Kolaborator Masjid'
  },
  {
    name: 'MUI (Majelis Ulama Indonesia) Kota Cimahi',
    role: 'Pedoman syar\'i, standarisasi materi keagamaan, dan pembinaan akidah-akhlak generasi muda',
    category: 'keagamaan',
    description: 'Menjaga kemurnian ajaran Islam wasathiyah dan penguatan adab Islami santri/siswa.',
    badge: 'Kolaborator Keagamaan'
  },
  {
    name: 'BAZNAS Kota Cimahi',
    role: 'Tata kelola amanah, pendayagunaan dana zakat/infak, dan dukungan beasiswa/LKS santri prasejahtera',
    category: 'keagamaan',
    description: 'Memastikan transparansi dan akuntabilitas gerakan gotong royong pendidikan karakter umat.',
    badge: 'Kolaborator Akuntabilitas'
  },
  {
    name: 'ICMI Orda Cimahi',
    role: 'Perumusan konsep cendekia, riset dampak karakter, dan penguatan ekosistem keilmuan Islam',
    category: 'inisiator',
    description: 'Mengintegrasikan nilai kesholehan spiritual dengan kecendekiaan intelektual dan kemajuan sains-teknologi.',
    badge: 'Kolaborator Cendekia'
  }
];

export const SEED_CITY_METRICS = {
  officialPublicStats: {
    source: 'BPS Kota Cimahi & Dapodik Kemendikdasmen 2024/2025',
    sdSchools: 119,
    sdTeachers: 2069,
    sdStudents: 46636,
    smaSchools: 19,
    smaTeachers: 648,
    smaStudents: 12105,
    smkSchools: 22,
    smkTeachers: 861,
    smkStudents: 16409,
    kecamatanCount: 3
  },
  simulationMetricsNote: 'Data partisipasi & rekapitulasi di bawah merupakan Data Simulasi MVP untuk keperluan demonstrasi sistem.',
  coverage: {
    totalStudents: 28456,
    activeStudents: 22195,
    schoolsCount: 128,
    mosquesCount: 342,
    teachersCount: 520,
    parentsCount: 26800
  },
  participation: {
    subuhBerjamaah: 78,
    maghribMengaji: 74,
    tilawahBelajar: 71,
    kebaikanKepedulian: 83,
    overallRate: 78
  },
  areas: [
    {
      kecamatan: 'Cimahi Utara',
      participationRate: 82,
      students: 10240,
      mosques: 120,
      schools: 46
    },
    {
      kecamatan: 'Cimahi Tengah',
      participationRate: 77,
      students: 11450,
      mosques: 132,
      schools: 50
    },
    {
      kecamatan: 'Cimahi Selatan',
      participationRate: 71,
      students: 6766,
      mosques: 90,
      schools: 32
    }
  ],
  sustainability: {
    programName: 'Gerakan Cimahi Pintar 5.000',
    description: 'Partisipasi masyarakat untuk mendukung keberlanjutan ekosistem Sholeh Cendekia.',
    monthlyAmountPerCitizen: 5000,
    totalContributors: 1485,
    fundsCollected: 148500000,
    targetFunds: 200000000
  }
};

export const SEED_APP_SETTINGS: AppSettings = {
  appName: 'SHOLEH CENDEKIA',
  appBadge: 'CIMAHI',
  appTagline: 'Gerakan Pembentukan Karakter Siswa Kota Cimahi — Me-Ramadhan-kan 11 Bulan Lainnya',
  visionTitle: 'Setiap Orang Tua Mendambakan Anak Sholeh & Cendekia',
  visionSubtitle: 'Menjaga konsistensi sholat berjamaah, mengaji ba\'da Maghrib, ketekunan belajar, dan adab kepedulian sosial sepanjang tahun melalui kolaborasi 5 pilar ekosistem.',
  logoText: 'SC',
  logoImageUrl: '/pwa-512x512.png',
  primaryColor: '#047857',
  contactEmail: 'admin@sholehcendekia.cimahi.go.id',
  contactPhone: '022-6654321',

  // Public Website CMS Defaults
  defaultLandingMode: 'public',
  heroKicker: 'Gerakan Pembinaan Karakter Anak Kota Cimahi',
  heroHeadline: 'Setiap Orang Tua Mendambakan Anak Sholeh & Cendekia',
  heroSubquote: '“Me-Ramadhan-kan 11 Bulan Lainnya”',
  heroDescription: 'Menjaga konsistensi sholat Subuh berjamaah, mengaji ba’da Maghrib, ketekunan belajar mandiri, dan adab kepedulian sosial sepanjang tahun melalui kolaborasi erat rumah, masjid, sekolah, dan kota.',
  heroButtonText: 'Masuk ke Platform Ekosistem',
  statStudentsCount: '1.240+',
  statMosquesCount: '48',
  statSchoolsCount: '24',
  statVerificationRate: '92%',
  gerakan5000Headline: 'Partisipasi masyarakat untuk mendukung keberlanjutan ekosistem.',
  gerakan5000Description: 'Gotong royong sukarela Rp5.000 warga Kota Cimahi untuk memastikan seluruh modul LKS tetap dapat diakses gratis oleh siswa dan mendukung operasional para ustadz di 342 masjid Maghrib Mengaji.'
};

export const SEED_CAROUSEL_SLIDES: CarouselSlide[] = [
  {
    id: 'slide-1',
    kicker: 'GERAKAN CIMAHI PINTAR 5.000',
    headline: 'Gotong Royong Rp5.000: Menjaga Karakter Anak Sholeh Cimahi',
    content: 'Dukungan sukarela untuk memastikan modul LKS tetap gratis bagi ribuan anak, memuliakan guru ngaji, dan memperkuat masjid.',
    ctaLabel: 'Ikut Donasi / Infak Rp5.000',
    imageUrl: imgGerakan5000,
    actionType: 'gerakan_5000',
    bgClass: 'bg-emerald-950 text-white',
    accentClass: 'text-amber-300',
    isActive: true,
    order: 1
  },
  {
    id: 'slide-2',
    kicker: 'NASEHAT ANAK SHOLEH',
    headline: 'Anak Sholeh Dibentuk dari Kebiasaan Kecil',
    content: 'Subuh, mengaji, belajar, berbuat baik. Kebiasaan yang dilakukan terus-menerus akan menjadi karakter.',
    ctaLabel: 'Baca Selengkapnya',
    imageUrl: imgNasehatSholeh,
    actionType: 'article_nasehat',
    bgClass: 'bg-slate-950 text-white',
    accentClass: 'text-emerald-400',
    isActive: true,
    order: 2
  },
  {
    id: 'slide-3',
    kicker: 'TANTANGAN MINGGU INI',
    headline: '7 Hari Menjaga Kebiasaan Baik',
    content: 'Subuh Berjamaah · Maghrib Mengaji · Tilawah & Belajar · Kebaikan & Kepedulian',
    ctaLabel: 'Lihat Progress',
    imageUrl: imgTantangan,
    actionType: 'tab_progress',
    bgClass: 'bg-teal-950 text-white',
    accentClass: 'text-amber-300',
    isActive: true,
    order: 3
  },
  {
    id: 'slide-4',
    kicker: 'KABAR GERAKAN CIMAHI',
    headline: 'Kabar Sholeh Cendekia Cimahi',
    content: 'Masjid, sekolah, orang tua, dan siswa bergerak bersama membangun kebiasaan baik generasi penerus.',
    ctaLabel: 'Lihat Berita',
    imageUrl: imgKabarEkosistem,
    actionType: 'article_berita',
    bgClass: 'bg-indigo-950 text-white',
    accentClass: 'text-emerald-300',
    isActive: true,
    order: 4
  },
  {
    id: 'slide-5',
    kicker: 'LKS & BELAJAR CERDAS',
    headline: 'Belajar Lebih Mudah di Sholeh Cendekia',
    content: 'Kerjakan LKS langsung di HP atau download untuk dicetak tanpa biaya.',
    ctaLabel: 'Buka Pustaka LKS',
    imageUrl: imgLksBelajar,
    actionType: 'tab_belajar',
    bgClass: 'bg-slate-900 text-white',
    accentClass: 'text-amber-300',
    isActive: true,
    order: 5
  }
];

export const SEED_PILLARS_CONFIG: PillarConfig[] = [
  {
    category: 'subuh_berjamaah',
    title: 'Subuh Berjamaah',
    defaultTitle: 'Sholat Subuh Berjamaah di Masjid',
    schedule: '04.30 – 05.15 WIB',
    description: 'Membiasakan bangun pagi dan melangkahkan kaki ke masjid terdekat.',
    points: 25
  },
  {
    category: 'maghrib_mengaji',
    title: 'Maghrib Mengaji',
    defaultTitle: 'Mengaji Ba\'da Maghrib & Tahsin Al-Qur\'an',
    schedule: '18.15 – 19.15 WIB',
    description: 'Menghidupkan masjid di waktu senja dengan tadarus dan bimbingan tajwid.',
    points: 25
  },
  {
    category: 'tilawah_belajar',
    title: 'Tilawah & Belajar',
    defaultTitle: 'Tadarus Al-Qur’an & Belajar Mandiri LKS',
    schedule: 'Harian Pagi / Malam',
    description: 'Penyelesaian lembar kerja mandiri dan penambahan wawasan ilmu.',
    points: 25
  },
  {
    category: 'kebaikan_kepedulian',
    title: 'Kebaikan & Kepedulian',
    defaultTitle: 'Membantu Orang Tua & Infak Subuh',
    schedule: 'Sepanjang Hari',
    description: 'Berbakti kepada orang tua, membantu sesama, dan menjaga kebersihan.',
    points: 25
  }
];

export const SEED_GERAKAN_5000_CONFIG: Gerakan5000Config = {
  nominal: 5000,
  minNominal: 2000,
  qrisNmid: 'ID102026CIMAHIPINTAR',
  qrisMerchantName: 'SHOLEH CENDEKIA CIMAHI - BAZNAS & DMI',
  qrisImageUrl: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&auto=format&fit=crop&q=80',
  vaNumber: '8805 0822 5000 1234',
  bankName: 'Bank Syariah Indonesia (BSI)',
  bankCode: '451',
  bankAccountNumber: '7199 0500 0500',
  accountHolder: 'BAZNAS & SHOLEH CENDEKIA CIMAHI',
  secondaryBankName: 'Bank BJB Syariah',
  secondaryBankAccountNumber: '5220 2000 5000',
  secondaryBankAccountHolder: 'GERAKAN CIMAHI PINTAR 5000',
  donationInstruction: 'Dukungan infak & donasi gotong royong Rp5.000 (atau seikhlasnya) langsung disalurkan secara amanah untuk ketersediaan LKS gratis siswa, insentif guru ngaji masjid, dan apresiasi bintang karakter.',
  ortuTriggerHeadline: 'Investasi Akhlak & Kebiasaan Mulia untuk Buah Hati',
  ortuTriggerMessage: 'Hanya dengan Rp5.000/bulan, Bapak/Ibu turut memastikan modul LKS tetap gratis bagi ribuan anak Cimahi dan mendukung para ustadz di masjid.',
  siswaTriggerHeadline: 'Sedekah Subuh & Berbagi Kebaikan Hari Ini',
  siswaTriggerMessage: 'Yuk sisihkan uang jajan Rp1.000 - Rp5.000 untuk teman-teman santri dan kawan yang membutuhkan. Amalan kecil bernilai pahala besar!',
  targetFunds: 200000000,
  collectedFunds: 148500000,
  totalDonors: 1485
};

